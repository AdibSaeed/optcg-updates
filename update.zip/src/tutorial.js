// ============================================================================
// Tutorial mode: a scripted first game that teaches the basic rules.
// Decks and draws are stacked, the opponent follows a script, and the player
// may only perform the action each step teaches (anything else shows a hint).
// After the final step the game continues as free play against the bot.
//
// UI-agnostic: the caller supplies hooks, so the whole flow is testable
// headlessly (see test/tutorial.js).
// ============================================================================
'use strict';

const { createBot } = require('./bot.js');

const PLAYER_DECK = {
  leader: 'OP01-001', // Roronoa Zoro
  cards: [].concat(...['OP01-010', 'OP01-012', 'OP01-006', 'OP01-013', 'OP01-025', 'OP01-018',
    'OP01-023', 'OP01-016', 'OP01-022', 'OP01-014', 'OP01-029', 'OP01-008']
    .map((c) => [c, c, c, c]), ['OP01-120', 'OP01-120']),
};
const BOT_DECK = {
  leader: 'OP01-031', // Kouzuki Oden
  cards: [].concat(...['OP01-036', 'OP01-043', 'OP01-045', 'OP01-037', 'OP01-035', 'OP01-048',
    'OP01-033', 'OP01-046', 'OP01-052', 'OP01-053', 'OP01-032', 'OP01-040']
    .map((c) => [c, c, c, c]), ['OP01-051', 'OP01-051']),
};
// top-of-deck order: 5 hand cards, then 5 life cards, then the next draws
const PLAYER_STACK = ['OP01-010', 'OP01-006', 'OP01-013', 'OP01-025', 'OP01-012',
  'OP01-012', 'OP01-018', 'OP01-023', 'OP01-016', 'OP01-008', 'OP01-023', 'OP01-022'];
const BOT_STACK = ['OP01-036', 'OP01-037', 'OP01-035', 'OP01-046', 'OP01-033',
  'OP01-043', 'OP01-043', 'OP01-045', 'OP01-045', 'OP01-053', 'OP01-052', 'OP01-032'];

function createTutorial({ Game, DB, EFFECTS, playerName, toPlayer, showStep, hint, onFinish, botDelay = 700 }) {
  let view = null;         // player's latest view
  let lastAsk = null;      // player's pending ask
  let idx = 0;
  let finished = false;
  let heuristicBot = null;

  // ---- helpers for expectations
  const codeOf = (iid) => {
    if (!view) return null;
    const all = [view.you.leader, ...view.you.chars, ...(view.you.hand || []), view.opp.leader, ...view.opp.chars];
    const f = all.find((c) => c && c.iid === iid);
    return f ? f.code : null;
  };
  const isMyLeader = (iid) => view && view.you.leader.iid === iid;
  const counterOptionCode = (value) =>
    value && lastAsk && lastAsk.kind === 'counter'
      ? (lastAsk.options.find((o) => o.iid === value.iid) || {}).code : null;

  const expectPlay = (code, name) => (m) =>
    (m.t === 'action' && m.a === 'playCard' && codeOf(m.iid) === code) ||
    `Play ${name}: drag it from your hand onto your board.`;
  const expectEnd = (m) =>
    (m.t === 'action' && m.a === 'endTurn') || 'Click the End Turn button.';
  const expectDonLeader = (m) =>
    (m.t === 'action' && m.a === 'attachDon' && isMyLeader(m.iid)) ||
    'Drag a DON!! card (the black cards below your board) onto your LEADER — the bottom-left card.';
  const expectAttack = (atk, tgt, msg) => (m) => {
    if (m.t !== 'action' || m.a !== 'attack') return msg;
    const aOk = atk === 'leader' ? isMyLeader(m.iid) : codeOf(m.iid) === atk;
    const tOk = tgt === 'leader' ? m.targetIid === 'leader' : codeOf(m.targetIid) === tgt;
    return (aOk && tOk) || msg;
  };
  const expectKeepHand = (m) =>
    (m.t === 'choice' && m.value === true) || 'Click Yes to keep this hand (a "mulligan" would shuffle it back for a new 5).';
  const expectPass = (m) =>
    (m.t === 'choice' && m.value === null) || 'Click Pass for now.';
  const expectCounterCard = (code, name) => (m) =>
    (m.t === 'choice' && counterOptionCode(m.value) === code) || `Click the ${name} button to counter with it.`;

  const steps = [
    { next: true, text: `Ahoy, ${playerName}! Welcome to the One Piece Card Game. Your LEADER (Roronoa Zoro, bottom-left) starts with 5 LIFE. Attack your opponent's Leader to knock off their Life cards — when they have none left, one final hit wins you the game!` },
    { next: true, text: `The board: your Characters go in the middle row and your hand is at the bottom. The black cards below your board are your DON!! — the game's energy. You'll get more each turn, spend them to play cards, and can even give them to your attackers. Hover over anything to read it in the left panel. Ready?` },
    { text: `First, your opening hand. You may mulligan once per game, but this hand is good — click Yes to keep it.`, expect: expectKeepHand },
    { text: `Turn 1. The Refresh, Draw and DON!! phases ran automatically (going first: no draw and only 1 DON!! on turn 1 — it's 2 from then on). Spend your 1 DON!! to play Komachiyo: DRAG it from your hand onto your board.`, expect: expectPlay('OP01-010', 'Komachiyo (the dog, cost 1)') },
    { text: `Komachiyo is in play — but Characters can't attack the turn they arrive (unless they have [Rush]). Nothing else to do: click End Turn.`, expect: expectEnd },
    { text: `Your opponent's turn — they get 2 DON!!, play a Character and attack your Leader. Watch...`, waitAsk: 'counter' },
    { text: `You're being attacked — this is the COUNTER STEP. You may trash cards with a Counter value (shown on the card) from your hand to boost your defender. Their 5000 vs your 5000: ties favor the ATTACKER, so this will hit... but it's only 1 damage, and blocking early hits wastes cards. Click Pass.`, expect: expectPass },
    { text: `You took 1 damage: your top Life card moved into your hand — so taking a hit even gains you a card! You have 4 Life left. Wait for your turn...`, waitCanAct: true },
    { text: `Your turn — you drew a card and got 2 more DON!! (3 total). You can GIVE DON!! to boost attackers: DRAG one of your DON!! cards onto your Leader. (Zoro's Leader ability even gives all your Characters +1000 while he has a DON!!.)`, expect: expectDonLeader },
    { text: `Your Leader now swings at 6000 (+1000 per DON!! given, during your turn). ATTACK: press on your Leader and DRAG the arrow onto THEIR Leader at the top!`, expect: expectAttack('leader', 'leader', 'Press and hold on your Leader, then drag the arrow onto their Leader (top row).') },
    { text: `Direct hit — their Life drops to 4! Notice your Leader is now sideways: RESTED. Rested cards can't attack or block until your next Refresh phase. Now use your last 2 DON!! to play Sanji — drag him onto your board.`, expect: expectPlay('OP01-013', 'Sanji (cost 2)') },
    { text: `Komachiyo could attack, but their Leader defends at 5000 and an attack only succeeds when the attacker's power is EQUAL OR HIGHER. Also: enemy Characters can only be attacked while they're rested. Click End Turn.`, expect: expectEnd },
    { text: `Their turn again — they'll attack harder this time. Get ready to defend...`, waitAsk: 'counter' },
    { text: `Their Leader attacks your 5000 Leader with 5000 again — but this time, stop it! Otama in your hand has Counter +2000. Click the Otama button to trash her and boost your Leader to 7000.`, expect: expectCounterCard('OP01-006', 'Otama +2000') },
    { text: `Your Leader defends at 7000 — their 5000 attack will FAIL. No need to spend more: click Pass.`, expect: expectPass },
    { text: `They may try another attack with a weaker Character — it can't beat your Leader, so just Pass if asked. (Attacking with weak cards can still be useful: it rests them... but also exposes them, as you're about to see!)`, waitAsk: 'counter' },
    { text: `A 3000-power attack against your 5000 Leader can never succeed. Click Pass and let it bounce off.`, expect: expectPass },
    { text: `Well defended! Wait for your turn...`, waitCanAct: true },
    { text: `Turn 5 — you have 5 DON!!. Drag Roronoa Zoro (cost 3) onto your board: he has [RUSH], so he can attack immediately!`, expect: expectPlay('OP01-025', 'Roronoa Zoro (cost 3)') },
    { text: `Their Otsuru is RESTED from attacking last turn — rested Characters are fair game (see them pulse red as you drag). K.O. it: drag your Zoro onto Otsuru (5000 vs 3000)!`, expect: expectAttack('OP01-025', 'OP01-036', 'Press on your new Zoro and drag the arrow onto their rested Otsuru.') },
    { text: `Otsuru is K.O.'d — straight to the Trash! Trading your attacks into rested enemies is core strategy. Now pile on the power: drag your 2 remaining DON!! cards onto your Leader, one at a time.`, expect: expectDonLeader, times: 2 },
    { text: `Your Leader is at 7000 — drag your Leader onto theirs and smash them again!`, expect: expectAttack('leader', 'leader', 'Drag your Leader onto their Leader.') },
    { finish: true, text: `Tutorial complete! You know the core loop: DON!! up, build your board, attack rested targets and Leaders, counter what matters. In real games you'll also meet [Blocker] Characters (they redirect attacks), [Trigger] Life cards (bonus effects when revealed), and Event cards — the game always prompts you at the right moment. This match now continues as FREE PLAY against the bot — finish them off!` },
  ];

  function show() {
    const s = steps[idx];
    showStep({ text: s.text, next: !!s.next, finish: !!s.finish, idx: idx + 1, total: steps.length });
  }
  function advance() {
    if (idx < steps.length - 1) { idx++; show(); recheck(); }
  }
  function recheck() {
    const s = steps[idx];
    if (s.waitAsk && lastAsk && lastAsk.kind === s.waitAsk) advance();
    else if (s.waitCanAct && view && view.canAct) advance();
  }

  // ---- opponent script (turns 2 and 4), then the heuristic bot takes over
  let game = null;
  const botQueue = [
    { play: 'OP01-036' }, { attack: 'leader', target: 'leader' }, { end: true },
    { play: 'OP01-037' }, { attack: 'leader', target: 'leader' }, { attack: 'OP01-036', target: 'leader' }, { end: true },
  ];
  let botView = null;
  let botBusy = false;
  function botHandler(msg) {
    if (msg.t === 'state') {
      botView = msg.view;
      if (botQueue.length === 0) { if (heuristicBot) heuristicBot(msg); return; }
      if (msg.view.canAct && !botBusy) {
        botBusy = true;
        setTimeout(() => {
          botBusy = false;
          if (!botView.canAct || botQueue.length === 0) return;
          const step = botQueue.shift();
          if (step.end) return game.onMessage(1, { t: 'action', a: 'endTurn' });
          if (step.play) {
            const c = (botView.you.hand || []).find((x) => x.code === step.play);
            if (c) return game.onMessage(1, { t: 'action', a: 'playCard', iid: c.iid });
            return game.onMessage(1, { t: 'action', a: 'endTurn' });
          }
          if (step.attack) {
            const atk = step.attack === 'leader' ? botView.you.leader : botView.you.chars.find((x) => x.code === step.attack && !x.rested);
            if (atk && !atk.rested) return game.onMessage(1, { t: 'action', a: 'attack', iid: atk.iid, targetIid: step.target });
            return game.onMessage(1, { t: 'action', a: 'endTurn' });
          }
        }, botDelay);
      }
    } else if (msg.t === 'ask') {
      if (botQueue.length === 0 && heuristicBot) { heuristicBot(msg); return; }
      const req = msg.req;
      const v = { yesno: true, trigger: false, counter: null, targets: [], cards: [], number: req.min || 0, info: true }[req.kind];
      setTimeout(() => game.onMessage(1, { t: 'choice', id: req.id, value: v !== undefined ? v : null }), 250);
    } else if (msg.t === 'nope') {
      if (botQueue.length === 0 && heuristicBot) heuristicBot(msg);
    }
  }

  function playerIntercept(msg) {
    if (msg.t === 'state') { view = msg.view; if (!msg.view.canAct) { /* keep */ } }
    if (msg.t === 'ask') lastAsk = msg.req;
    if (msg.t === 'state' && lastAsk && !game.pendingReq) lastAsk = null;
    toPlayer(msg);
    recheck();
  }

  function stack(pid, codes) {
    const p = game.players[pid];
    const pre = [];
    for (const code of codes) {
      const i = p.deck.findIndex((c) => c.code === code && !pre.includes(c));
      if (i >= 0) pre.push(p.deck.splice(i, 1)[0]);
    }
    p.deck = [...pre, ...p.deck];
  }

  return {
    get game() { return game; },
    isFinished: () => finished,
    start() {
      game = new Game(DB, EFFECTS, [PLAYER_DECK, BOT_DECK], {
        send: (pid, msg) => (pid === 0 ? playerIntercept(msg) : botHandler(msg)),
        names: [playerName, 'Tutorial Bot'],
      });
      stack(0, PLAYER_STACK);
      stack(1, BOT_STACK);
      heuristicBot = createBot((m) => game.onMessage(1, m), { delay: botDelay });
      show();
      game.start(0).catch((e) => console.error('tutorial engine error:', e));
      return game;
    },
    /** UI clicked Next on an info step. */
    next() {
      const s = steps[idx];
      if (s.next) advance();
    },
    /** UI clicked the finish button. */
    finishFreePlay() {
      if (steps[idx].finish) { finished = true; onFinish('continue'); }
    },
    /** Gate player messages. Returns true to allow, or a hint string to block. */
    filterPlayerMsg(m) {
      if (finished) return true;
      if (m.t === 'concede') return 'Use "Exit tutorial" on the tutorial panel to leave.';
      const s = steps[idx];
      if (s.finish) { finished = true; onFinish('continue'); return true; }
      if (s.next) return 'Read the tutorial panel and click Next first.';
      if (s.waitAsk || s.waitCanAct) return 'Wait — watch what your opponent does.';
      const r = s.expect(m);
      if (r !== true) return r;
      // allowed: advance (handles multi-count steps)
      if (s.times && s.times > 1) { s.times--; return true; }
      advance();
      return true;
    },
  };
}

module.exports = { createTutorial, PLAYER_DECK, BOT_DECK };
