// ============================================================================
// In-app updates: checks UPDATE_URL/version.json, downloads update.zip and
// extracts it over the app folder (code + data only — the big image folders
// are never part of updates; missing card images load from the web instead).
// Publish updates with: node tools/make-update.js  (see SERVER.md)
// ============================================================================
'use strict';

const https = require('https');
const http = require('http');
const path = require('path');
const CONFIG = require('./config.js');

const APP_ROOT = path.join(__dirname, '..');
const localVersion = () => require(path.join(APP_ROOT, 'package.json')).version;

function fetchUrl(url, asBuffer = false) {
  return new Promise((resolve, reject) => {
    const mod = url.startsWith('https') ? https : http;
    mod.get(url, { headers: { 'User-Agent': 'optcg-updater' } }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return fetchUrl(res.headers.location, asBuffer).then(resolve, reject);
      }
      if (res.statusCode !== 200) return reject(new Error(`HTTP ${res.statusCode}`));
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => resolve(asBuffer ? Buffer.concat(chunks) : Buffer.concat(chunks).toString('utf8')));
      res.on('error', reject);
    }).on('error', reject);
  });
}

const newer = (a, b) => { // is a newer than b
  const pa = String(a).split('.').map(Number), pb = String(b).split('.').map(Number);
  for (let i = 0; i < 3; i++) { if ((pa[i] || 0) > (pb[i] || 0)) return true; if ((pa[i] || 0) < (pb[i] || 0)) return false; }
  return false;
};

/** Returns {version, notes} if an update is available, else null. */
async function checkForUpdate() {
  if (!CONFIG.UPDATE_URL) return null;
  const base = CONFIG.UPDATE_URL.replace(/\/$/, '');
  const info = JSON.parse(await fetchUrl(`${base}/version.json?t=${Date.now()}`));
  if (info.version && newer(info.version, localVersion())) return info;
  return null;
}

/** Downloads and installs the update. Returns true on success. */
async function installUpdate() {
  const base = CONFIG.UPDATE_URL.replace(/\/$/, '');
  const buf = await fetchUrl(`${base}/update.zip?t=${Date.now()}`, true);
  const AdmZip = require('adm-zip');
  new AdmZip(buf).extractAllTo(APP_ROOT, true);
  return true;
}

module.exports = { checkForUpdate, installUpdate, localVersion };
