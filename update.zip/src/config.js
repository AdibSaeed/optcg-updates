// ============================================================================
// Game configuration — set once before sharing the game with your friends.
//
// SERVER_URL: the address of your deployed relay/account server
// (server/relay.js). Examples:
//   'wss://your-app.onrender.com'      (hosted, recommended)
//   'ws://203.0.113.7:7460'            (your own VPS, no TLS)
// Leave '' to play offline only (LAN/VPN + bot + tutorial still work).
// ============================================================================
'use strict';

module.exports = {
  SERVER_URL: 'wss://optcg-server-92un.onrender.com',

  // Sets players can open packs from / build decks with.
  // Add more as you're ready to release them, e.g. ['OP01', 'OP02'].
  // Locked sets show as "Coming soon".
  UNLOCKED_SETS: ['OP01'],

  // Auto-updates: base URL of a folder containing version.json + update.zip
  // (see tools/make-update.js and SERVER.md). Leave '' to disable.
  UPDATE_URL: 'https://raw.githubusercontent.com/AdibSaeed/optcg-updates/main',
};
