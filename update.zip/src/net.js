// Networking: the host runs a WebSocket server; the guest connects to it.
// All game logic runs on the host — the guest only exchanges views/choices.
'use strict';

const WebSocket = require('ws');

const DEFAULT_PORT = 7457;

/** Host a game. handlers: { onGuestMessage(msg), onGuestConnected(name), onGuestLeft() } */
function host(port, handlers) {
  const server = new WebSocket.Server({ port });
  let guest = null;
  server.on('connection', (ws) => {
    if (guest) { ws.close(4000, 'Game is full'); return; }
    guest = ws;
    ws.on('message', (data) => {
      let msg;
      try { msg = JSON.parse(data.toString()); } catch { return; }
      handlers.onGuestMessage(msg);
    });
    ws.on('close', () => { guest = null; handlers.onGuestLeft(); });
    ws.on('error', () => {});
  });
  server.on('error', (e) => handlers.onError && handlers.onError(e));
  return {
    sendToGuest: (msg) => { if (guest && guest.readyState === WebSocket.OPEN) guest.send(JSON.stringify(msg)); },
    hasGuest: () => !!guest,
    close: () => { try { if (guest) guest.close(); server.close(); } catch {} },
  };
}

/** Join a hosted game. handlers: { onMessage(msg), onOpen(), onClose(reason), onError(e) } */
function join(address, port, handlers) {
  const ws = new WebSocket(`ws://${address}:${port}`);
  ws.on('open', () => handlers.onOpen());
  ws.on('message', (data) => {
    let msg;
    try { msg = JSON.parse(data.toString()); } catch { return; }
    handlers.onMessage(msg);
  });
  ws.on('close', (code, reason) => handlers.onClose(reason ? reason.toString() : ''));
  ws.on('error', (e) => handlers.onError && handlers.onError(e));
  return {
    send: (msg) => { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(msg)); },
    close: () => { try { ws.close(); } catch {} },
  };
}

/**
 * Host through a relay server (room codes — no IPs or port forwarding).
 * handlers: { onCode(code), onGuestMessage(msg), onGuestConnected(), onGuestLeft(), onError(e), onClose() }
 */
function hostViaRelay(url, handlers, username = null) {
  const ws = new WebSocket(url);
  let paired = false;
  ws.on('open', () => ws.send(JSON.stringify({ t: 'create', username })));
  ws.on('message', (data) => {
    let msg;
    try { msg = JSON.parse(data.toString()); } catch { return; }
    if (msg.t === 'room') handlers.onCode(msg.code);
    else if (msg.t === 'paired') { paired = true; handlers.onGuestConnected && handlers.onGuestConnected(); }
    else if (msg.t === 'peerLeft') { paired = false; handlers.onGuestLeft(); }
    else if (msg.t === 'roomError') handlers.onError && handlers.onError(new Error(msg.why));
    else handlers.onGuestMessage(msg);
  });
  ws.on('close', () => handlers.onClose && handlers.onClose());
  ws.on('error', (e) => handlers.onError && handlers.onError(e));
  return {
    sendToGuest: (msg) => { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(msg)); },
    hasGuest: () => paired,
    close: () => { try { ws.close(); } catch {} },
  };
}

/**
 * Join a relay room by code.
 * handlers: { onOpen(), onMessage(msg), onClose(reason), onError(e) } — onOpen fires when paired.
 */
function joinViaRelay(url, code, handlers, username = null) {
  const ws = new WebSocket(url);
  ws.on('open', () => ws.send(JSON.stringify({ t: 'joinRoom', code, username })));
  ws.on('message', (data) => {
    let msg;
    try { msg = JSON.parse(data.toString()); } catch { return; }
    if (msg.t === 'paired') handlers.onOpen();
    else if (msg.t === 'roomError') { handlers.onError && handlers.onError(new Error(msg.why)); try { ws.close(); } catch {} }
    else if (msg.t === 'peerLeft') handlers.onClose('Host left the room.');
    else handlers.onMessage(msg);
  });
  ws.on('close', (code2, reason) => handlers.onClose(reason ? reason.toString() : ''));
  ws.on('error', (e) => handlers.onError && handlers.onError(e));
  return {
    send: (msg) => { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(msg)); },
    close: () => { try { ws.close(); } catch {} },
  };
}

/** Best-effort list of local IPv4 addresses to show the host. */
function localIPs() {
  const os = require('os');
  const out = [];
  for (const [name, addrs] of Object.entries(os.networkInterfaces())) {
    for (const a of addrs || []) {
      if (a.family === 'IPv4' && !a.internal) out.push(`${a.address} (${name})`);
    }
  }
  return out;
}

module.exports = { host, join, hostViaRelay, joinViaRelay, localIPs, DEFAULT_PORT };
