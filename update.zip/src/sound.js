// ============================================================================
// Sound effects — synthesized with WebAudio (no audio files, no copyright).
// SND.play('name'), SND.toggle(), SND.muted
// ============================================================================
'use strict';

let ctx = null;
const AC = () => (ctx = ctx || new (window.AudioContext || window.webkitAudioContext)());

function tone(freq, dur, { type = 'sine', vol = 0.18, slide = null, delay = 0 } = {}) {
  const c = AC();
  const t0 = c.currentTime + delay;
  const o = c.createOscillator();
  const g = c.createGain();
  o.type = type;
  o.frequency.setValueAtTime(freq, t0);
  if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(20, slide), t0 + dur);
  g.gain.setValueAtTime(0, t0);
  g.gain.linearRampToValueAtTime(vol, t0 + 0.008);
  g.gain.exponentialRampToValueAtTime(0.0008, t0 + dur);
  o.connect(g).connect(c.destination);
  o.start(t0);
  o.stop(t0 + dur + 0.05);
}
function noise(dur, { vol = 0.16, low = 400, high = 6000, slideLow = null, delay = 0 } = {}) {
  const c = AC();
  const t0 = c.currentTime + delay;
  const len = Math.max(1, Math.floor(c.sampleRate * dur));
  const buf = c.createBuffer(1, len, c.sampleRate);
  const d = buf.getChannelData(0);
  for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
  const src = c.createBufferSource();
  src.buffer = buf;
  const hp = c.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = low;
  const lp = c.createBiquadFilter(); lp.type = 'lowpass';
  lp.frequency.setValueAtTime(high, t0);
  if (slideLow) lp.frequency.exponentialRampToValueAtTime(slideLow, t0 + dur);
  const g = c.createGain();
  g.gain.setValueAtTime(vol, t0);
  g.gain.exponentialRampToValueAtTime(0.0008, t0 + dur);
  src.connect(hp).connect(lp).connect(g).connect(c.destination);
  src.start(t0);
}

const FX = {
  draw: () => noise(0.14, { vol: 0.1, low: 900, high: 7000, slideLow: 1500 }),
  play: () => { tone(170, 0.14, { type: 'sine', slide: 62, vol: 0.24 }); noise(0.07, { vol: 0.07, low: 200, high: 1200 }); },
  don: () => tone(880, 0.16, { type: 'triangle', vol: 0.1, slide: 1240 }),
  clash: () => { noise(0.24, { vol: 0.24, low: 120, high: 3800, slideLow: 300 }); tone(90, 0.28, { type: 'sine', slide: 38, vol: 0.3 }); },
  damage: () => { tone(320, 0.3, { type: 'sawtooth', slide: 70, vol: 0.13 }); noise(0.12, { vol: 0.1, low: 300, high: 2000 }); },
  ko: () => { noise(0.4, { vol: 0.16, low: 90, high: 1600, slideLow: 160 }); tone(140, 0.4, { slide: 40, vol: 0.16 }); },
  flip: () => noise(0.05, { vol: 0.13, low: 1500, high: 9000 }),
  rip: () => noise(0.1, { vol: 0.2, low: 700, high: 9000, slideLow: 2500 }),
  ripEnd: () => { noise(0.28, { vol: 0.22, low: 400, high: 8000, slideLow: 900 }); },
  coin: () => { tone(1180, 0.09, { type: 'triangle', vol: 0.11 }); tone(1560, 0.18, { type: 'triangle', vol: 0.11, delay: 0.07 }); },
  rare: () => [523, 659, 784, 1047].forEach((f, i) => tone(f, 0.34, { type: 'triangle', vol: 0.1, delay: i * 0.06 })),
  win: () => [392, 523, 659, 784, 1047].forEach((f, i) => tone(f, 0.5, { type: 'triangle', vol: 0.12, delay: i * 0.13 })),
  lose: () => { tone(196, 0.7, { type: 'sine', vol: 0.14 }); tone(147, 0.9, { type: 'sine', vol: 0.14, delay: 0.35 }); },
  click: () => tone(600, 0.04, { type: 'square', vol: 0.04 }),
};

const SND = {
  get muted() { return localStorage.getItem('optcg_mute') === '1'; },
  toggle() { localStorage.setItem('optcg_mute', this.muted ? '0' : '1'); return this.muted; },
  play(name) {
    if (this.muted || !FX[name]) return;
    try { FX[name](); } catch {}
  },
};

if (typeof module !== 'undefined') module.exports = SND;
