// ============================================================================
// Automatic effect compiler for sets beyond OP-01.
//
// Keywords ([Blocker] [Rush] [Double Attack] [Banish]) and Counter values work
// for every card with no scripting. This module additionally compiles common
// effect templates into real engine handlers: K.O. / rest / bounce / debuff /
// buff / draw / DON!! ramp / discard / deck-top search / leader-type
// conditions / simple continuous power / [Activate: Main] with costs /
// [Trigger] effects.
//
// Anything it cannot fully parse stays un-automated and the card is flagged:
//   E.__flags[code] = 'scripted' | 'auto' | 'partial' | 'manual'
// ============================================================================
'use strict';

const TIMINGS = {
  'On Play': 'onPlay', 'When Attacking': 'whenAttacking', 'On K.O.': 'onKO',
  'On Block': 'onBlock', 'Main': 'main', 'Counter': 'counter', 'Trigger': 'trigger',
  'Activate: Main': 'activateMain', 'Activate:Main': 'activateMain',
};
const KEYWORD_TAGS = new Set(['Blocker', 'Rush', 'Double Attack', 'Banish']);

function splitAbilities(text) {
  const clean = text
    .replace(/\{([^}]+)\}/g, '"$1"')
    .replace(/Activate this card's \[(Main|Counter)\] effect/gi, 'Activate this card\u2019s \u00AB$1\u00BB effect')
    .replace(/\([^()]*\)/g, ' ').replace(/\s+/g, ' ').trim();
  const re = /\[([^\]]+)\]/g;
  const abilities = [];
  let cur = null;
  let idx = 0, m;
  const pushText = (t) => { if (cur) cur.body += t; };
  while ((m = re.exec(clean)) !== null) {
    pushText(clean.slice(idx, m.index));
    idx = re.lastIndex;
    const tag = m[1];
    // a name reference like [Nami] mid-sentence is body text, not an ability tag
    const isTag = TIMINGS[tag] || KEYWORD_TAGS.has(tag) || /^DON!! ?x\d$/i.test(tag)
      || ['Once Per Turn', 'Your Turn', "Opponent's Turn", 'End of Your Turn', 'Trigger'].includes(tag);
    if (!isTag) { pushText(`[${tag}]`); continue; }
    const sep = cur && (cur.body.trim() === '' || cur.body.trim() === '/');
    if (!sep) { if (cur) abilities.push(cur); cur = { tags: [], body: '' }; }
    else if (cur) cur.body = '';
    cur.tags.push(tag);
  }
  pushText(clean.slice(idx));
  if (cur) abilities.push(cur);
  return abilities.map((a) => ({ tags: a.tags, body: a.body.trim() }));
}

// ------------------------------------------------- card descriptor -> filter
// e.g. `red Character card with a cost of 3 or less other than [Uta]`
//      `"Whitebeard Pirates" type Character card`
function parseDescriptor(d) {
  let s = ` ${d.trim()} `;
  const out = { colors: [], typeTags: [], kind: null, costLE: null, costGE: null, powLE: null, notNames: [], names: [] };
  const eat = (re) => { const m = s.match(re); if (m) s = s.replace(re, ' '); return m; };
  let m;
  while ((m = eat(/ "([^"]+)" type /))) out.typeTags.push(m[1]);
  while ((m = eat(/ other than \[([^\]]+)\] /))) out.notNames.push(m[1]);
  while ((m = eat(/ \[([^\]]+)\] /))) out.names.push(m[1]);
  while ((m = eat(/ with a type including "([^"]+)" /))) out.typeTags.push(m[1]);
  if ((m = eat(/ with a cost of (\d+) or less /))) out.costLE = +m[1];
  if ((m = eat(/ with a cost of (\d+) or more /))) out.costGE = +m[1];
  if ((m = eat(/ with a cost of (\d+) /))) { out.costLE = +m[1]; out.costGE = +m[1]; }
  if ((m = eat(/ with (\d+) power or less /))) out.powLE = +m[1];
  while ((m = eat(/ (red|green|blue|purple|black|yellow) /i))) out.colors.push(m[1][0].toUpperCase() + m[1].slice(1).toLowerCase());
  if ((m = eat(/ (Character|Event|Stage) /))) out.kind = m[1];
  s = s.replace(/\b(cards?|card)\b/g, ' ').replace(/\s+/g, ' ').trim();
  if (s !== '') return null; // leftover words we don't understand
  return out;
}
function descriptorFilter(g, out) {
  return (inst) => {
    const c = g.card(inst);
    if (out.kind && c.type !== out.kind) return false;
    if (out.colors.length && !out.colors.some((col) => c.colors.includes(col))) return false;
    if (out.typeTags.length && !out.typeTags.every((t) => c.types.includes(t))) return false;
    if (out.costLE !== null && (c.cost || 0) > out.costLE) return false;
    if (out.costGE !== null && (c.cost || 0) < out.costGE) return false;
    if (out.powLE !== null && (c.power || 0) > out.powLE) return false;
    if (out.names.length && !out.names.includes(c.name)) return false;
    if (out.notNames.includes(c.name)) return false;
    return true;
  };
}

// ------------------------------------------------------------- action parts
function protectDots(s) { return s.replace(/K\.O\./g, 'K@O@'); }
function unprotect(s) { return s.replace(/K@O@/g, 'K.O.'); }

function parseAction(raw, def) {
  const s = unprotect(raw.trim().replace(/\.$/, ''));
  if (!s) return 'skip';
  let m;

  if (/^Play this card$/i.test(s) && def.type === 'Character') {
    return async (g, ctx) => { await g.playCharacter(ctx.pid, ctx.self); return 'played'; };
  }
  if (/^Play this card$/i.test(s) && def.type === 'Stage') {
    return async (g, ctx) => { g.playStage(ctx.pid, ctx.self); return 'played'; };
  }
  if (/^Shuffle your deck$/i.test(s)) {
    return async (g, ctx) => { g.shuffle(g.P(ctx.pid).deck); g.log(`${g.P(ctx.pid).name} shuffled their deck.`); g.pushState(); };
  }
  if ((m = s.match(/^K\.O\. up to (\d) of your opponent's (rested )?Characters?(?: with (?:a cost of (\d+) or less|(\d+) power or less))?$/i))) {
    const n = +m[1], rested = !!m[2], cost = m[3] ? +m[3] : null, pow = m[4] ? +m[4] : null;
    return async (g, ctx) => {
      const t = await g.pickTargets(ctx.pid, {
        side: 'opp', leaders: false, chars: true, min: 0, max: n,
        filter: (i) => (!rested || i.rested) && (cost === null || (g.card(i).cost || 0) <= cost) && (pow === null || (g.card(i).power || 0) <= pow),
        title: `K.O. up to ${n} of your opponent's ${rested ? 'rested ' : ''}Characters${cost !== null ? ` (cost ≤${cost})` : ''}${pow !== null ? ` (power ≤${pow})` : ''}`,
      });
      for (const i of t) await g.ko(i, { byBattle: false });
    };
  }
  if ((m = s.match(/^Rest up to (\d) of your opponent's Characters?(?: with a cost of (\d+) or less)?$/i))) {
    const n = +m[1], cost = m[2] ? +m[2] : null;
    return async (g, ctx) => {
      const t = await g.pickTargets(ctx.pid, {
        side: 'opp', leaders: false, chars: true, min: 0, max: n,
        filter: (i) => !i.rested && (cost === null || (g.card(i).cost || 0) <= cost),
        title: `Rest up to ${n} of your opponent's Characters${cost !== null ? ` (cost ≤${cost})` : ''}`,
      });
      for (const i of t) { i.rested = true; g.log(`${g.card(i).name} was rested.`); }
      g.pushState();
    };
  }
  if ((m = s.match(/^Return up to (\d) (?:of your opponent's )?Characters? with a cost of (\d+) or less to (?:its|the) owner's hand$/i))) {
    const n = +m[1], cost = +m[2], oppOnly = /opponent's/i.test(s);
    return async (g, ctx) => {
      const t = await g.pickTargets(ctx.pid, {
        side: oppOnly ? 'opp' : 'any', leaders: false, chars: true, min: 0, max: n,
        filter: (i) => (g.card(i).cost || 0) <= cost && i !== ctx.self,
        title: `Return up to ${n} Character${n > 1 ? 's' : ''} (cost ≤${cost}) to the owner's hand`,
      });
      for (const i of t) g.returnToHand(i);
    };
  }
  if ((m = s.match(/^Draw (\d) cards?$/i))) {
    const n = +m[1];
    return async (g, ctx) => { await g.draw(ctx.pid, n); };
  }
  if ((m = s.match(/^Give up to (\d) of your opponent's (Leader or Characters?|Characters?) ?(?:cards? )?[-−](\d+) power during this turn$/i))) {
    const n = +m[1], leaders = /Leader/i.test(m[2]), amt = +m[3];
    return async (g, ctx) => {
      const t = await g.pickTargets(ctx.pid, {
        side: 'opp', leaders, chars: true, min: 0, max: n,
        title: `Give up to ${n} of your opponent's ${leaders ? 'Leader or ' : ''}Characters −${amt} this turn`,
      });
      for (const i of t) g.addMod(i, -amt, 'turn');
    };
  }
  if ((m = s.match(/^Up to (\d) of your (Leader or Character|Character) cards? gains? \+(\d+) power during this (turn|battle)$/i))) {
    const n = +m[1], leaders = /Leader/i.test(m[2]), amt = +m[3], until = m[4].toLowerCase();
    return async (g, ctx) => {
      const t = await g.pickTargets(ctx.pid, {
        side: 'you', leaders, chars: true, min: 0, max: n,
        title: `Give up to ${n} of your ${leaders ? 'Leader or ' : ''}Characters +${amt} this ${until}`,
      });
      for (const i of t) g.addMod(i, amt, until);
    };
  }
  if ((m = s.match(/^This (?:Character|Leader) gains \+(\d+) power during this (turn|battle)$/i))) {
    const amt = +m[1], until = m[2].toLowerCase();
    return async (g, ctx) => { g.addMod(ctx.self, amt, until); g.log(`${g.card(ctx.self).name} gains +${amt} this ${until}.`); };
  }
  if ((m = s.match(/^Your opponent trashes (\d) cards? from their hand$/i))) {
    const n = +m[1];
    return async (g, ctx) => {
      const opid = g.oppOf(ctx.pid);
      for (let k = 0; k < n; k++) {
        const hand = g.P(opid).hand;
        if (!hand.length) return;
        const picked = await g.pickCards(opid, hand, { min: 1, max: 1, title: 'Choose 1 card from your hand to trash' });
        if (picked.length) g.trashFromHand(opid, picked[0]);
      }
    };
  }
  if ((m = s.match(/^Add up to (\d) DON!! cards? from your DON!! deck and (rest (?:it|them)|set (?:it|them) as active)$/i))) {
    const n = +m[1], rested = /rest/i.test(m[2]);
    return async (g, ctx) => { g.addDon(ctx.pid, n, { rested }); };
  }
  if ((m = s.match(/^Set up to (\d) of your DON!! cards? as active$/i))) {
    const n = +m[1];
    return async (g, ctx) => { g.setDonActive(ctx.pid, n); };
  }
  // Play up to 1 <descriptor> from your hand
  if ((m = s.match(/^Play up to 1 (.+?) from your hand(?: rested)?$/i))) {
    const desc = parseDescriptor(m[1]);
    if (!desc || (desc.kind && desc.kind !== 'Character')) return null;
    const rested = / rested$/i.test(s);
    return async (g, ctx) => {
      const flt = descriptorFilter(g, desc);
      const pool = g.P(ctx.pid).hand.filter((c) => g.card(c).type === 'Character' && flt(c));
      if (!pool.length) return;
      const picked = await g.pickCards(ctx.pid, pool, { min: 0, max: 1, title: `Play up to 1 ${unprotect(m[1])} from your hand` });
      if (picked.length) await g.playCharacter(ctx.pid, picked[0], { fromZone: g.P(ctx.pid).hand, rested });
    };
  }
  // Add up to 1 <descriptor> from your trash to your hand
  if ((m = s.match(/^Add up to 1 (.+?) from your trash to your hand$/i))) {
    const desc = parseDescriptor(m[1]);
    if (!desc) return null;
    return async (g, ctx) => {
      const p = g.P(ctx.pid);
      const flt = descriptorFilter(g, desc);
      const pool = p.trash.filter(flt);
      const picked = await g.pickCards(ctx.pid, pool, { min: 0, max: 1, title: `Add up to 1 ${unprotect(m[1])} from your trash to your hand`, zoneLabel: 'Trash' });
      if (picked.length) {
        p.trash.splice(p.trash.indexOf(picked[0]), 1);
        p.hand.push(picked[0]);
        g.log(`${g.P(ctx.pid).name} returned ${g.card(picked[0]).name} from the trash to hand.`);
      }
    };
  }
  return null;
}

// whole-body patterns (must run before sentence splitting)
function parseWholeBody(bodyRaw, def) {
  const body = unprotect(bodyRaw.trim().replace(/\.$/, ''));
  let m;
  // Look at N cards from the top of your deck; reveal up to 1 X and add it to
  // your hand. Then, place the rest at the bottom of your deck in any order.
  if ((m = body.match(/^Look at (?:up to )?(\d) cards? from the top of your deck; reveal up to 1 (.+?) and add it to your hand\.? Then,? place the rest at the bottom of your deck in any order$/i))) {
    const n = +m[1];
    const desc = parseDescriptor(m[2]);
    if (!desc) return null;
    const what = m[2];
    return async (g, ctx) => {
      const p = g.P(ctx.pid);
      const looked = p.deck.splice(0, Math.min(n, p.deck.length));
      if (!looked.length) return;
      const flt = descriptorFilter(g, desc);
      const matching = looked.filter(flt);
      if (matching.length) {
        const picked = await g.pickCards(ctx.pid, matching, { min: 0, max: 1, title: `Choose up to 1 ${what} to add to your hand` });
        if (picked.length) {
          looked.splice(looked.indexOf(picked[0]), 1);
          p.hand.push(picked[0]);
          g.log(`${p.name} revealed ${g.card(picked[0]).name} and added it to their hand.`);
        }
      }
      if (looked.length) {
        const order = await g.ask(ctx.pid, {
          kind: 'order', title: 'Place these at the bottom of your deck',
          cards: looked.map((c) => ({ iid: c.iid, code: c.code })),
        });
        const ordered = [];
        for (const iid of order || []) { const inst = looked.find((c) => c.iid === iid); if (inst && !ordered.includes(inst)) ordered.push(inst); }
        for (const c of looked) if (!ordered.includes(c)) ordered.push(c);
        p.deck.push(...ordered);
      }
      g.pushState();
    };
  }
  if ((m = body.match(/^Look at (\d) cards? from the top of your deck and place them at the top or bottom of the deck in any order$/i))) {
    const n = +m[1];
    return async (g, ctx) => {
      const p = g.P(ctx.pid);
      const looked = p.deck.splice(0, Math.min(n, p.deck.length));
      if (!looked.length) return;
      const res = await g.ask(ctx.pid, {
        kind: 'arrange', title: `Place these ${looked.length} cards at the top or bottom of your deck`,
        cards: looked.map((c) => ({ iid: c.iid, code: c.code })),
      });
      const byIid = (iid) => looked.find((c) => c.iid === iid);
      const top = ((res && res.top) || []).map(byIid).filter(Boolean);
      const bottom = ((res && res.bottom) || []).map(byIid).filter(Boolean);
      for (const c of looked) if (!top.includes(c) && !bottom.includes(c)) top.push(c);
      p.deck.unshift(...top);
      p.deck.push(...bottom);
      g.pushState();
    };
  }
  return null;
}

// cost prefixes
function parseCost(costStr, def) {
  const c = unprotect(costStr.trim());
  let m;
  if ((m = c.match(/^You may trash (\d) cards? from your hand$/i))) {
    return async (g, ctx) => {
      const pool = g.P(ctx.pid).hand;
      if (!pool.length) return false;
      const picked = await g.pickCards(ctx.pid, pool, { min: 0, max: 1, title: `Trash 1 card from your hand for ${def.name}'s effect?` });
      if (!picked.length) return false;
      g.trashFromHand(ctx.pid, picked[0]);
      return true;
    };
  }
  if ((m = c.match(/^DON!! ?[-−](\d)$/i))) {
    const n = +m[1];
    return async (g, ctx) => {
      if (!g.canReturnDon(ctx.pid, n)) return false;
      if (!(await g.yesno(ctx.pid, `DON!! −${n}: return ${n} DON!! for ${def.name}'s effect?`))) return false;
      g.returnDon(ctx.pid, n);
      return true;
    };
  }
  if ((m = c.match(/^\((\d)\)$/))) {
    const n = +m[1];
    return async (g, ctx) => {
      if (g.P(ctx.pid).donActive < n) return false;
      if (!(await g.yesno(ctx.pid, `Pay ${n} DON!! for ${def.name}'s effect?`))) return false;
      g.payDon(ctx.pid, n);
      return true;
    };
  }
  if (/^You may rest this Character$/i.test(c)) {
    return async (g, ctx) => {
      if (ctx.self.rested) return false;
      if (!(await g.yesno(ctx.pid, `Rest ${def.name} to activate its effect?`))) return false;
      ctx.self.rested = true;
      g.pushState();
      return true;
    };
  }
  return null;
}

// leading conditions we can evaluate
function parseCondition(body) {
  let m;
  if ((m = body.match(/^If your Leader(?:'s type includes|(?: card)? has the) "([^"]+)"(?: type)?, ?(.+)$/i))) {
    const tag = m[1];
    return { rest: m[2], check: (g, ctx) => g.card(g.P(ctx.pid).leader).types.includes(tag) };
  }
  if ((m = body.match(/^If your Leader is \[([^\]]+)\], ?(.+)$/i))) {
    const name = m[1];
    return { rest: m[2], check: (g, ctx) => g.card(g.P(ctx.pid).leader).name === name };
  }
  return null;
}

// ------------------------------------------------------------- compile one
function compileCard(def) {
  const fx = {};
  let parsedAny = false, failedAny = false;

  for (const ab of splitAbilities(def.text)) {
    const kwOnly = ab.tags.every((t) => KEYWORD_TAGS.has(t)) && !ab.body;
    if (kwOnly) continue;
    const timingTag = ab.tags.find((t) => TIMINGS[t]);
    const timing = timingTag && TIMINGS[timingTag];
    const donx = (() => { const t = ab.tags.find((x) => /^DON!! ?x(\d)$/i.test(x)); return t ? +t.match(/(\d)/)[1] : 0; })();
    const opt = ab.tags.includes('Once Per Turn');
    const yourTurn = ab.tags.includes('Your Turn');
    const oppTurn = ab.tags.includes("Opponent's Turn");

    // continuous: "[DON!! xN] ([Your Turn]) This Character gains +X power" / can-attack-active
    if (!timing) {
      let m;
      if ((m = ab.body.match(/^This Character gains \+(\d+) power\.?$/i))) {
        const amt = +m[1];
        fx.contPower = (g, src, sp, t) => (t === src && src.don >= donx && (!yourTurn || g.turn.pid === sp) && (!oppTurn || g.turn.pid !== sp)) ? amt : 0;
        parsedAny = true;
        continue;
      }
      if (/^This Character can also attack your opponent's active Characters\.?$/i.test(ab.body)) {
        fx.contCanAttackActive = (g, inst) => inst.don >= donx;
        parsedAny = true;
        continue;
      }
      failedAny = true;
      continue;
    }
    if (yourTurn || oppTurn) { failedAny = true; continue; }

    let body = protectDots(ab.body);
    // Trigger: "Activate this card's [Main]/[Counter] effect." — resolved later
    if (timing === 'trigger' && /^Activate this card\u2019s \u00AB(Main|Counter)\u00BB effect$/i.test(unprotect(body).replace(/\.$/, ''))) {
      fx.__triggerCopies = unprotect(body).match(/Main/i) ? 'main' : 'counter';
      parsedAny = true;
      continue;
    }

    // condition prefix
    let condition = null;
    const cond = parseCondition(unprotect(body));
    if (cond) { condition = cond.check; body = protectDots(cond.rest); }
    if (/^If |^You cannot|While |cannot be|^When /i.test(unprotect(body))) { failedAny = true; continue; }

    // optional cost "X: Y"
    let cost = null;
    const ci = body.indexOf(':');
    if (ci > 0) {
      cost = parseCost(unprotect(body.slice(0, ci)), def);
      if (!cost) { failedAny = true; continue; }
      body = body.slice(ci + 1).trim();
    }
    // activateMain requires an explicit cost or is free-with-confirm — require cost to avoid misfires
    if (timing === 'activateMain' && !cost) { failedAny = true; continue; }

    let steps = [];
    const whole = parseWholeBody(body, def);
    if (whole) steps = [whole];
    else {
      let ok = true;
      for (const part of body.split(/\.\s+/).map((x) => x.trim()).filter(Boolean)) {
        const step = parseAction(part.replace(/^Then,?\s*/i, ''), def);
        if (step === 'skip') continue;
        if (!step) { ok = false; break; }
        steps.push(step);
      }
      if (!ok || steps.length === 0) { failedAny = true; continue; }
    }

    const optKey = `auto_${timing}`;
    const handler = async (g, ctx) => {
      if (donx && ctx.self.don < donx) {
        if (['whenAttacking', 'onBlock'].includes(timing)) {
          g.log(`(${def.name}'s [DON!! x${donx}] ability did not activate — it needs ${donx} DON!! attached, it has ${ctx.self.don}.)`);
        }
        return timing === 'activateMain' ? false : undefined;
      }
      if (opt && ctx.self.optUsed && ctx.self.optUsed[optKey] === g.turn.n) return timing === 'activateMain' ? false : undefined;
      if (condition && !condition(g, ctx)) return timing === 'activateMain' ? false : undefined;
      if (cost && !(await cost(g, ctx))) return timing === 'activateMain' ? false : undefined;
      if (opt && ctx.self.optUsed) ctx.self.optUsed[optKey] = g.turn.n;
      let res;
      for (const st of steps) res = await st(g, ctx);
      return res;
    };
    for (const t of ab.tags) { if (TIMINGS[t]) fx[TIMINGS[t]] = handler; }
    if (timing === 'activateMain' && opt) fx.activateOncePerTurn = true;
    parsedAny = true;
  }

  if (fx.__triggerCopies) {
    const src = fx[fx.__triggerCopies];
    if (src) fx.trigger = src; else failedAny = true;
    delete fx.__triggerCopies;
  }
  const flag = failedAny ? (parsedAny ? 'partial' : 'manual') : 'auto';
  return { fx, flag, hasHandlers: Object.keys(fx).some((k) => k !== 'activateOncePerTurn') };
}

/** Merged registry: handwritten scripts win, everything else compiled. */
function buildRegistry(db, manual) {
  const E = {};
  const flags = {};
  for (const def of db) {
    if (manual[def.code]) { E[def.code] = manual[def.code]; flags[def.code] = 'scripted'; continue; }
    if (!def.text) { flags[def.code] = 'auto'; continue; }
    const { fx, flag, hasHandlers } = compileCard(def);
    flags[def.code] = flag;
    if (hasHandlers) E[def.code] = fx;
  }
  Object.defineProperty(E, '__flags', { value: flags, enumerable: false });
  return E;
}

module.exports = { buildRegistry, compileCard };
