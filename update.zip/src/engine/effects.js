// ============================================================================
// Scripted effects for every OP-01 Romance Dawn card (errata'd text).
// Each entry can define:
//   onPlay(g, ctx)            [On Play]
//   whenAttacking(g, ctx)     [When Attacking]   (ctx.battle available)
//   onBlock(g, ctx)           [On Block]
//   onKO(g, ctx)              [On K.O.]
//   main(g, ctx)              [Main] event effect
//   counter(g, ctx)           [Counter] event effect (ctx.battle available)
//   trigger(g, ctx)           [Trigger]; return 'played' if the card was played
//   activateMain(g, ctx)      [Activate: Main]; return false if cancelled
//     + activateOncePerTurn / activateDonx
//   contPower(g, src, srcPid, target, targetPid) -> power delta (continuous)
//   contKeywords(g, inst, pid) -> ['Double Attack', ...]
//   contCost(g, src, srcPid, card, forPid) -> cost delta
//   contCanAttackActive(g, inst, pid)
//   koProtect(g, src, srcPid, target, attacker) -> true to prevent battle KO
//   attackRestriction(g, inst, pid) -> true if opponent may only attack this
//   onEventActivated(g, {pid, self, byPid})
//   onOppCharKOd(g, {pid, self, koInst})
// ctx = { pid, self, battle? }
// ============================================================================
'use strict';

const E = {};

// -------------------------------------------------------------- tiny helpers
const card = (g, i) => g.card(i);
const isChar = (g, i) => card(g, i).type === 'Character';
const costLE = (g, n) => (i) => (card(g, i).cost || 0) <= n;
const powLE = (g, n) => (i) => (card(g, i).power || 0) <= n;
const hasType = (g, i, t) => card(g, i).types.includes(t);
// OP01-121 Yamato: "Also treat this card's name as [Kouzuki Oden]".
const hasName = (g, i, name) => card(g, i).name === name || (i.code === 'OP01-121' && name === 'Kouzuki Oden');
const leaderIs = (g, pid, name) => hasName(g, g.P(pid).leader, name);
const leaderHasType = (g, pid, t) => hasType(g, g.P(pid).leader, t);
const myTurn = (g, pid) => g.turn.pid === pid;

async function buffTargets(g, ctx, { side = 'opp', leaders = false, amount, max = 1, until = 'turn', filter, title }) {
  const t = await g.pickTargets(ctx.pid, { side, leaders, chars: true, min: 0, max, filter, title });
  for (const inst of t) g.addMod(inst, amount, until);
  if (t.length) g.log(`${t.map((i) => card(g, i).name).join(', ')}: ${amount > 0 ? '+' : ''}${amount} power (${until === 'battle' ? 'this battle' : 'this turn'}).`);
  return t;
}
async function koOpp(g, ctx, { max = 1, filter, title }) {
  const t = await g.pickTargets(ctx.pid, { side: 'opp', leaders: false, chars: true, min: 0, max, filter, title });
  for (const inst of t) await g.ko(inst, { byBattle: false });
  return t;
}
async function restOpp(g, ctx, { max = 1, filter, title }) {
  const t = await g.pickTargets(ctx.pid, {
    side: 'opp', leaders: false, chars: true, min: 0, max, title,
    filter: (i, p) => !i.rested && (!filter || filter(i, p)),
  });
  for (const inst of t) { inst.rested = true; g.log(`${card(g, inst).name} was rested.`); }
  g.pushState();
  return t;
}
async function setActiveMine(g, ctx, { max = 1, filter, title }) {
  const t = await g.pickTargets(ctx.pid, {
    side: 'you', leaders: false, chars: true, min: 0, max, title,
    filter: (i, p) => i.rested && (!filter || filter(i, p)),
  });
  for (const inst of t) { inst.rested = false; g.log(`${card(g, inst).name} was set active.`); }
  g.pushState();
  return t;
}
/** "You may trash 1 card from your hand: ..." — returns true if paid. */
async function mayTrashHand(g, ctx, { filter, title }) {
  const pool = g.P(ctx.pid).hand.filter((c) => !filter || filter(c));
  if (pool.length === 0) return false;
  const picked = await g.pickCards(ctx.pid, pool, { min: 0, max: 1, title });
  if (picked.length === 0) return false;
  g.trashFromHand(ctx.pid, picked[0]);
  return true;
}
/** Look at top n; optionally add up to 1 matching card to hand; rest to bottom (ordered). */
async function lookRevealAdd(g, ctx, { n = 5, filter, what, playInstead = false, playRested = false }) {
  const p = g.P(ctx.pid);
  const looked = p.deck.splice(0, Math.min(n, p.deck.length));
  if (looked.length === 0) return;
  const matching = filter ? looked.filter(filter) : looked;
  let taken = null;
  if (matching.length > 0) {
    const picked = await g.pickCards(ctx.pid, matching, { min: 0, max: 1, title: `Choose up to 1 ${what} ${playInstead ? 'to play' : 'to add to your hand'}` });
    if (picked.length) {
      taken = picked[0];
      looked.splice(looked.indexOf(taken), 1);
      if (playInstead) {
        g.log(`${p.name} plays ${card(g, taken).name} from the top of the deck.`);
        await g.playCharacter(ctx.pid, taken, { rested: playRested });
      } else {
        p.hand.push(taken);
        g.log(`${p.name} revealed ${card(g, taken).name} and added it to their hand.`);
      }
    }
  }
  if (looked.length > 0) {
    const order = await g.ask(ctx.pid, {
      kind: 'order', title: 'Place these at the bottom of your deck (top of list goes first)',
      cards: looked.map((c) => ({ iid: c.iid, code: c.code })),
    });
    const ordered = [];
    for (const iid of order || []) {
      const inst = looked.find((c) => c.iid === iid);
      if (inst && !ordered.includes(inst)) ordered.push(inst);
    }
    for (const c of looked) if (!ordered.includes(c)) ordered.push(c);
    p.deck.push(...ordered);
  }
  g.pushState();
}
/** Look at top n, place each at top or bottom in any order (Perona / Doflamingo 073). */
async function lookTopBottom(g, ctx, n) {
  const p = g.P(ctx.pid);
  const looked = p.deck.splice(0, Math.min(n, p.deck.length));
  if (looked.length === 0) return;
  const res = await g.ask(ctx.pid, {
    kind: 'arrange', title: `Place these ${looked.length} cards at the top or bottom of your deck`,
    cards: looked.map((c) => ({ iid: c.iid, code: c.code })),
  });
  const byIid = (iid) => looked.find((c) => c.iid === iid);
  const top = ((res && res.top) || []).map(byIid).filter(Boolean);
  const bottom = ((res && res.bottom) || []).map(byIid).filter(Boolean);
  for (const c of looked) if (!top.includes(c) && !bottom.includes(c)) top.push(c);
  p.deck.unshift(...top);
  p.deck.push(...bottom);
  g.pushState();
}
/** Play up to 1 character from hand matching filter. Returns played inst or null. */
async function mayPlayFromHand(g, ctx, { filter, title, free = true }) {
  const pool = g.P(ctx.pid).hand.filter((c) => isChar(g, c) && (!filter || filter(c)));
  if (pool.length === 0) return null;
  const picked = await g.pickCards(ctx.pid, pool, { min: 0, max: 1, title });
  if (picked.length === 0) return null;
  await g.playCharacter(ctx.pid, picked[0], { fromZone: g.P(ctx.pid).hand });
  return picked[0];
}
/** Opponent discards 1 card of their choice (Jack / X.Drake 114). */
async function oppTrashes(g, ctx) {
  const opid = g.oppOf(ctx.pid);
  const hand = g.P(opid).hand;
  if (hand.length === 0) return;
  const picked = await g.pickCards(opid, hand, { min: 1, max: 1, title: 'Choose 1 card from your hand to trash' });
  if (picked.length) g.trashFromHand(opid, picked[0]);
}
/** DON!! −n confirm+pay. Returns true if paid. */
async function payDonMinus(g, ctx, n, what) {
  if (!g.canReturnDon(ctx.pid, n)) return false;
  const ok = await g.yesno(ctx.pid, `DON!! −${n}: return ${n} DON!! to your DON!! deck to ${what}?`);
  if (!ok) return false;
  g.returnDon(ctx.pid, n);
  return true;
}
const oncePerTurn = (g, inst, key) => {
  if (inst.optUsed[key] === g.turn.n) return false;
  inst.optUsed[key] = g.turn.n;
  return true;
};
/** [DON!! xN] gate — logs a hint when the ability is skipped so players learn why. */
const needDon = (g, ctx, n) => {
  if (ctx.self.don >= n) return true;
  g.log(`(${card(g, ctx.self).name}'s [DON!! x${n}] ability did not activate — it needs ${n} DON!! attached, it has ${ctx.self.don}.)`);
  return false;
};

// ============================================================ RED ==========

// OP01-001 Roronoa Zoro (Leader): [DON!!x1][Your Turn] all your Characters +1000.
E['OP01-001'] = {
  contPower: (g, src, sp, t, tp) => (sp === tp && myTurn(g, sp) && src.don >= 1 && !g.isLeader(t)) ? 1000 : 0,
};

// OP01-002 Trafalgar Law (Leader)
E['OP01-002'] = {
  activateOncePerTurn: true,
  activateMain: async (g, ctx) => {
    const p = g.P(ctx.pid);
    if (p.chars.length !== 5) throw new Error('You need 5 Characters in play.');
    if (p.donActive < 2) throw new Error('Needs 2 active DON!! to rest.');
    const ret = await g.pickTargets(ctx.pid, { side: 'you', leaders: false, min: 0, max: 1, title: 'Return 1 of your Characters to your hand' });
    if (ret.length === 0) return false;
    g.payDon(ctx.pid, 2);
    const retColors = card(g, ret[0]).colors;
    g.returnToHand(ret[0]);
    await mayPlayFromHand(g, ctx, {
      filter: (c) => (card(g, c).cost || 0) <= 5 && !card(g, c).colors.some((col) => retColors.includes(col)),
      title: 'Play up to 1 Character (cost ≤5) of a different color than the returned Character',
    });
  },
};

// OP01-003 Monkey.D.Luffy (Leader)
E['OP01-003'] = {
  activateOncePerTurn: true,
  activateMain: async (g, ctx) => {
    if (g.P(ctx.pid).donActive < 4) throw new Error('Needs 4 active DON!! to rest.');
    const t = await g.pickTargets(ctx.pid, {
      side: 'you', leaders: false, min: 0, max: 1,
      filter: (i) => i.rested && (card(g, i).cost || 0) <= 5 && (hasType(g, i, 'Supernovas') || hasType(g, i, 'Straw Hat Crew')),
      title: 'Set a "Supernovas"/"Straw Hat Crew" Character (cost ≤5) active; it gains +1000 this turn',
    });
    if (t.length === 0) return false;
    g.payDon(ctx.pid, 4);
    t[0].rested = false;
    g.addMod(t[0], 1000, 'turn');
    g.log(`${card(g, t[0]).name} is set active and gains +1000 power.`);
  },
};

// OP01-004 Usopp: [DON!!x1][Your Turn][Once Per Turn] draw when opponent activates an Event.
E['OP01-004'] = {
  onEventActivated: async (g, { pid, self, byPid }) => {
    if (byPid === pid || !myTurn(g, pid) || self.don < 1) return;
    if (!oncePerTurn(g, self, 'usopp')) return;
    g.log('Usopp: opponent activated an Event — draw 1 card.');
    await g.draw(pid, 1);
  },
};

// OP01-005 Uta: [On Play] add red Character (not Uta, cost ≤3) from trash to hand.
E['OP01-005'] = {
  onPlay: async (g, ctx) => {
    const pool = g.P(ctx.pid).trash.filter((c) => isChar(g, c) && card(g, c).colors.includes('Red') && (card(g, c).cost || 0) <= 3 && !hasName(g, c, 'Uta'));
    const picked = await g.pickCards(ctx.pid, pool, { min: 0, max: 1, title: 'Add a red Character (cost ≤3) from your trash to your hand', zoneLabel: 'Trash' });
    if (picked.length) {
      const p = g.P(ctx.pid);
      p.trash.splice(p.trash.indexOf(picked[0]), 1);
      p.hand.push(picked[0]);
      g.log(`${card(g, picked[0]).name} returned from the trash to hand.`);
    }
  },
};

// OP01-006 Otama: [On Play] up to 1 opp Character −2000 this turn.
E['OP01-006'] = { onPlay: (g, ctx) => buffTargets(g, ctx, { amount: -2000, title: "Give an opponent's Character −2000 this turn" }) };

// OP01-007 Caribou: [On K.O.] K.O. up to 1 opp Character with 4000 power or less.
E['OP01-007'] = { onKO: (g, ctx) => koOpp(g, ctx, { filter: powLE(g, 4000), title: "K.O. an opponent's Character with ≤4000 power" }) };

// OP01-008 Cavendish: [On Play] may take 1 Life to hand: gain [Rush] this turn.
E['OP01-008'] = {
  onPlay: async (g, ctx) => {
    if (g.P(ctx.pid).life.length === 0) return;
    if (await g.yesno(ctx.pid, 'Add the top card of your Life to your hand so Cavendish gains [Rush] this turn?')) {
      g.lifeToHand(ctx.pid);
      g.grantKw(ctx.self, 'Rush', 'turn');
      g.log('Cavendish gains [Rush]!');
    }
  },
};

// OP01-009 Carrot: [Trigger] Play this card.
E['OP01-009'] = { trigger: async (g, ctx) => { await g.playCharacter(ctx.pid, ctx.self); return 'played'; } };

// OP01-011 Gordon: [On Play] may bottom-deck 1 from hand: draw 1.
E['OP01-011'] = {
  onPlay: async (g, ctx) => {
    const p = g.P(ctx.pid);
    const picked = await g.pickCards(ctx.pid, p.hand, { min: 0, max: 1, title: 'Place 1 card from your hand at the bottom of your deck to draw 1' });
    if (picked.length) {
      p.hand.splice(p.hand.indexOf(picked[0]), 1);
      p.deck.push(picked[0]);
      await g.draw(ctx.pid, 1);
    }
  },
};

// OP01-013 Sanji: [Activate:Main][Once Per Turn] life→hand: +2000 this turn, then give up to 2 rested DON!!.
E['OP01-013'] = {
  activateOncePerTurn: true,
  activateMain: async (g, ctx) => {
    const p = g.P(ctx.pid);
    if (p.life.length === 0) throw new Error('No Life cards left.');
    if (!(await g.yesno(ctx.pid, 'Add the top card of your Life to your hand? (Sanji +2000 this turn, then attach up to 2 rested DON!!)'))) return false;
    g.lifeToHand(ctx.pid);
    g.addMod(ctx.self, 2000, 'turn');
    const n = Math.min(2, p.donRested);
    if (n > 0) {
      const give = await g.ask(ctx.pid, { kind: 'number', title: `Give Sanji how many rested DON!!? (0–${n})`, min: 0, max: n });
      const k = Math.max(0, Math.min(n, give | 0));
      p.donRested -= k; ctx.self.don += k;
      if (k) g.log(`Sanji was given ${k} rested DON!!.`);
    }
  },
};

// OP01-014 Jinbe: [Blocker] [DON!!x1][On Block] play red Character cost ≤2 from hand.
E['OP01-014'] = {
  onBlock: async (g, ctx) => {
    if (!needDon(g, ctx, 1)) return;
    await mayPlayFromHand(g, ctx, { filter: (c) => card(g, c).colors.includes('Red') && (card(g, c).cost || 0) <= 2, title: 'Play a red Character (cost ≤2) from your hand' });
  },
};

// OP01-015 Tony Tony.Chopper: [DON!!x1][When Attacking] may trash 1: SHC char (not Chopper, cost ≤4) trash→hand.
E['OP01-015'] = {
  whenAttacking: async (g, ctx) => {
    if (!needDon(g, ctx, 1)) return;
    if (!(await mayTrashHand(g, ctx, { title: 'Trash 1 card from your hand to salvage a Straw Hat Crew Character?' }))) return;
    const p = g.P(ctx.pid);
    const pool = p.trash.filter((c) => isChar(g, c) && hasType(g, c, 'Straw Hat Crew') && (card(g, c).cost || 0) <= 4 && !hasName(g, c, 'Tony Tony.Chopper'));
    const picked = await g.pickCards(ctx.pid, pool, { min: 0, max: 1, title: 'Add a "Straw Hat Crew" Character (cost ≤4) from your trash to your hand', zoneLabel: 'Trash' });
    if (picked.length) {
      p.trash.splice(p.trash.indexOf(picked[0]), 1);
      p.hand.push(picked[0]);
      g.log(`${card(g, picked[0]).name} returned from the trash to hand.`);
    }
  },
};

// OP01-016 Nami: [On Play] look 5, reveal SHC char (not Nami) → hand, rest to bottom.
E['OP01-016'] = {
  onPlay: (g, ctx) => lookRevealAdd(g, ctx, {
    filter: (c) => isChar(g, c) && hasType(g, c, 'Straw Hat Crew') && !hasName(g, c, 'Nami'),
    what: '"Straw Hat Crew" Character (not Nami)',
  }),
};

// OP01-017 Nico Robin: [DON!!x1][When Attacking] K.O. opp char ≤3000 power.
E['OP01-017'] = {
  whenAttacking: async (g, ctx) => {
    if (!needDon(g, ctx, 1)) return;
    await koOpp(g, ctx, { filter: powLE(g, 3000), title: "K.O. an opponent's Character with ≤3000 power" });
  },
};

// OP01-019 Bartolomeo: [Blocker] [DON!!x2][Opponent's Turn] +3000.
E['OP01-019'] = { contPower: (g, src, sp, t) => (t === src && src.don >= 2 && !myTurn(g, sp)) ? 3000 : 0 };

// OP01-020 Hyogoro: [Activate:Main] may rest this: leader/char +2000 this turn.
E['OP01-020'] = {
  activateMain: async (g, ctx) => {
    if (ctx.self.rested) throw new Error('Hyogoro is already rested.');
    const t = await g.pickTargets(ctx.pid, { side: 'you', leaders: true, min: 0, max: 1, title: 'Rest Hyogoro: give a Leader or Character +2000 this turn' });
    if (t.length === 0) return false;
    ctx.self.rested = true;
    g.addMod(t[0], 2000, 'turn');
    g.log(`${card(g, t[0]).name} gains +2000 power this turn.`);
  },
};

// OP01-021 Franky: [DON!!x1] can also attack active Characters.
E['OP01-021'] = { contCanAttackActive: (g, inst) => inst.don >= 1 };

// OP01-022 Brook: [DON!!x1][When Attacking] up to 2 opp chars −2000 this turn.
E['OP01-022'] = {
  whenAttacking: async (g, ctx) => {
    if (!needDon(g, ctx, 1)) return;
    await buffTargets(g, ctx, { amount: -2000, max: 2, title: "Give up to 2 opponent's Characters −2000 this turn" });
  },
};

// OP01-024 Monkey.D.Luffy: [DON!!x2] can't be battle-KO'd by Strike attackers; [Activate:Main][OPT] give up to 2 rested DON!!.
E['OP01-024'] = {
  koProtect: (g, src, sp, target, attacker) =>
    target === src && src.don >= 2 && attacker && card(g, attacker).attribute === 'Strike',
  activateOncePerTurn: true,
  activateMain: async (g, ctx) => {
    const p = g.P(ctx.pid);
    const n = Math.min(2, p.donRested);
    if (n === 0) throw new Error('No rested DON!! in your cost area.');
    const give = await g.ask(ctx.pid, { kind: 'number', title: `Give Luffy how many rested DON!!? (0–${n})`, min: 0, max: n });
    const k = Math.max(0, Math.min(n, give | 0));
    if (k === 0) return false;
    p.donRested -= k; ctx.self.don += k;
    g.log(`Luffy was given ${k} rested DON!!.`);
  },
};

// OP01-025 Roronoa Zoro: [Rush] (keyword only)

// OP01-026 Gum-Gum Fire-Fist Pistol Red Hawk (Event)
E['OP01-026'] = {
  counter: async (g, ctx) => {
    await buffTargets(g, ctx, { side: 'you', leaders: true, amount: 4000, until: 'battle', title: 'Give a Leader or Character +4000 this battle' });
    await koOpp(g, ctx, { filter: powLE(g, 4000), title: "K.O. an opponent's Character with ≤4000 power" });
  },
  trigger: async (g, ctx) => {
    await buffTargets(g, ctx, { side: 'opp', leaders: true, amount: -10000, title: "Give an opponent's Leader or Character −10000 this turn" });
  },
};

// OP01-027 Round Table (Event): [Main] opp char −10000 this turn.
E['OP01-027'] = { main: (g, ctx) => buffTargets(g, ctx, { amount: -10000, title: "Give an opponent's Character −10000 this turn" }) };

// OP01-028 Green Star Rafflesia (Event)
E['OP01-028'] = {
  counter: (g, ctx) => buffTargets(g, ctx, { side: 'opp', leaders: true, amount: -2000, title: "Give an opponent's Leader or Character −2000 this turn" }),
  trigger: (g, ctx) => E['OP01-028'].counter(g, ctx),
};

// OP01-029 Radical Beam!! (Event)
E['OP01-029'] = {
  counter: async (g, ctx) => {
    const bonus = g.P(ctx.pid).life.length <= 2 ? 4000 : 2000;
    await buffTargets(g, ctx, { side: 'you', leaders: true, amount: bonus, until: 'battle', title: `Give a Leader or Character +${bonus} this battle` });
  },
};

// OP01-030 In Two Years!! At the Sabaody Archipelago!! (Event)
E['OP01-030'] = {
  main: (g, ctx) => lookRevealAdd(g, ctx, { filter: (c) => isChar(g, c) && hasType(g, c, 'Straw Hat Crew'), what: '"Straw Hat Crew" Character' }),
  trigger: (g, ctx) => E['OP01-030'].main(g, ctx),
};

// ========================================================== GREEN ==========

// OP01-031 Kouzuki Oden (Leader): [Activate:Main][OPT] trash a Wano card: set up to 2 DON!! active.
E['OP01-031'] = {
  activateOncePerTurn: true,
  activateMain: async (g, ctx) => {
    if (g.P(ctx.pid).donRested === 0) throw new Error('No rested DON!! to set active.');
    if (!(await mayTrashHand(g, ctx, { filter: (c) => hasType(g, c, 'Land of Wano'), title: 'Trash a "Land of Wano" card to set up to 2 DON!! active' }))) return false;
    g.setDonActive(ctx.pid, 2);
  },
};

// OP01-032 Ashura Doji: [DON!!x1] +2000 if opponent has 2+ rested Characters.
E['OP01-032'] = {
  contPower: (g, src, sp, t) => (t === src && src.don >= 1 && g.P(g.oppOf(sp)).chars.filter((c) => c.rested).length >= 2) ? 2000 : 0,
};

// OP01-033 Izo: [On Play] rest opp char cost ≤4.
E['OP01-033'] = { onPlay: (g, ctx) => restOpp(g, ctx, { filter: costLE(g, 4), title: "Rest an opponent's Character (cost ≤4)" }) };

// OP01-034 Inuarashi: [DON!!x2][When Attacking] set 1 DON!! active.
E['OP01-034'] = { whenAttacking: async (g, ctx) => { if (needDon(g, ctx, 2)) g.setDonActive(ctx.pid, 1); } };

// OP01-035 Okiku: [DON!!x1][When Attacking][OPT] rest opp char cost ≤5.
E['OP01-035'] = {
  whenAttacking: async (g, ctx) => {
    if (!needDon(g, ctx, 1) || ctx.self.optUsed['okiku'] === g.turn.n) return;
    const t = await restOpp(g, ctx, { filter: costLE(g, 5), title: "Rest an opponent's Character (cost ≤5)" });
    if (t.length) ctx.self.optUsed['okiku'] = g.turn.n;
  },
};

// OP01-037 Kawamatsu: [Trigger] Play this card.
E['OP01-037'] = { trigger: async (g, ctx) => { await g.playCharacter(ctx.pid, ctx.self); return 'played'; } };

// OP01-038 Kanjuro
E['OP01-038'] = {
  whenAttacking: async (g, ctx) => {
    if (!needDon(g, ctx, 1)) return;
    await koOpp(g, ctx, { filter: (i) => i.rested && (card(g, i).cost || 0) <= 2, title: "K.O. an opponent's rested Character (cost ≤2)" });
  },
  onKO: async (g, ctx) => {
    const opid = g.oppOf(ctx.pid);
    const hand = g.P(ctx.pid).hand;
    if (hand.length === 0) return;
    const idx = await g.ask(opid, { kind: 'pickIndex', title: `Kanjuro: choose 1 of ${g.names[ctx.pid]}'s ${hand.length} hand cards to trash (face down)`, count: hand.length });
    const i = Math.max(0, Math.min(hand.length - 1, idx | 0));
    g.trashFromHand(ctx.pid, hand[i]);
  },
};

// OP01-039 Killer: [Blocker] [DON!!x1][On Block] if 3+ Characters, draw 1.
E['OP01-039'] = {
  onBlock: async (g, ctx) => {
    if (needDon(g, ctx, 1) && g.P(ctx.pid).chars.length >= 3) await g.draw(ctx.pid, 1);
  },
};

// OP01-040 Kin'emon
E['OP01-040'] = {
  onPlay: async (g, ctx) => {
    if (!leaderIs(g, ctx.pid, 'Kouzuki Oden')) return;
    await mayPlayFromHand(g, ctx, { filter: (c) => hasType(g, c, 'The Akazaya Nine') && (card(g, c).cost || 0) <= 3, title: 'Play a "The Akazaya Nine" Character (cost ≤3) from your hand' });
  },
  whenAttacking: async (g, ctx) => {
    if (!needDon(g, ctx, 1) || ctx.self.optUsed['kinemon'] === g.turn.n) return;
    const t = await setActiveMine(g, ctx, { filter: (i) => hasType(g, i, 'The Akazaya Nine') && (card(g, i).cost || 0) <= 3, title: 'Set a "The Akazaya Nine" Character (cost ≤3) active' });
    if (t.length) ctx.self.optUsed['kinemon'] = g.turn.n;
  },
};

// OP01-041 Kouzuki Momonosuke: [Activate:Main] (1) + rest this: look 5 reveal Wano card → hand.
E['OP01-041'] = {
  activateMain: async (g, ctx) => {
    if (ctx.self.rested) throw new Error('Momonosuke is already rested.');
    if (g.P(ctx.pid).donActive < 1) throw new Error('Needs 1 active DON!! to rest.');
    if (!(await g.yesno(ctx.pid, 'Pay ① and rest Momonosuke to look at the top 5 cards?'))) return false;
    g.payDon(ctx.pid, 1);
    ctx.self.rested = true;
    await lookRevealAdd(g, ctx, { filter: (c) => hasType(g, c, 'Land of Wano'), what: '"Land of Wano" card' });
  },
};

// OP01-042 Komurasaki: [On Play] (3): if leader Oden, set a Wano char cost ≤3 active.
E['OP01-042'] = {
  onPlay: async (g, ctx) => {
    if (g.P(ctx.pid).donActive < 3) return;
    if (!(await g.yesno(ctx.pid, 'Pay ③ for Komurasaki\'s effect?'))) return;
    g.payDon(ctx.pid, 3);
    if (!leaderIs(g, ctx.pid, 'Kouzuki Oden')) return;
    await setActiveMine(g, ctx, { filter: (i) => hasType(g, i, 'Land of Wano') && (card(g, i).cost || 0) <= 3, title: 'Set a "Land of Wano" Character (cost ≤3) active' });
  },
};

// OP01-044 Shachi: [Blocker] [On Play] if you don't have Penguin, play a Penguin from hand.
E['OP01-044'] = {
  onPlay: async (g, ctx) => {
    if (g.P(ctx.pid).chars.some((c) => hasName(g, c, 'Penguin'))) return;
    await mayPlayFromHand(g, ctx, { filter: (c) => hasName(g, c, 'Penguin'), title: 'Play a [Penguin] from your hand' });
  },
};

// OP01-046 Denjiro: [DON!!x1][When Attacking] if leader Oden, set up to 2 DON!! active.
E['OP01-046'] = {
  whenAttacking: async (g, ctx) => {
    if (needDon(g, ctx, 1) && leaderIs(g, ctx.pid, 'Kouzuki Oden')) g.setDonActive(ctx.pid, 2);
  },
};

// OP01-047 Trafalgar Law: [Blocker] [On Play] may return 1 your char to hand: play char cost ≤3 from hand.
E['OP01-047'] = {
  onPlay: async (g, ctx) => {
    const t = await g.pickTargets(ctx.pid, { side: 'you', leaders: false, min: 0, max: 1, title: 'Return 1 of your Characters to hand to play a Character (cost ≤3)' });
    if (t.length === 0) return;
    g.returnToHand(t[0]);
    await mayPlayFromHand(g, ctx, { filter: (c) => (card(g, c).cost || 0) <= 3, title: 'Play a Character (cost ≤3) from your hand' });
  },
};

// OP01-048 Nekomamushi: [On Play] rest opp char cost ≤3.
E['OP01-048'] = { onPlay: (g, ctx) => restOpp(g, ctx, { filter: costLE(g, 3), title: "Rest an opponent's Character (cost ≤3)" }) };

// OP01-049 Bepo: [DON!!x1][When Attacking] play a Heart Pirates card (not Bepo, cost ≤4) from hand.
E['OP01-049'] = {
  whenAttacking: async (g, ctx) => {
    if (!needDon(g, ctx, 1)) return;
    await mayPlayFromHand(g, ctx, { filter: (c) => hasType(g, c, 'Heart Pirates') && (card(g, c).cost || 0) <= 4 && !hasName(g, c, 'Bepo'), title: 'Play a "Heart Pirates" Character (cost ≤4) from your hand' });
  },
};

// OP01-050 Penguin: [Blocker] [On Play] if you don't have Shachi, play a Shachi from hand.
E['OP01-050'] = {
  onPlay: async (g, ctx) => {
    if (g.P(ctx.pid).chars.some((c) => hasName(g, c, 'Shachi'))) return;
    await mayPlayFromHand(g, ctx, { filter: (c) => hasName(g, c, 'Shachi'), title: 'Play a [Shachi] from your hand' });
  },
};

// OP01-051 Eustass"Captain"Kid
E['OP01-051'] = {
  attackRestriction: (g, inst, pid) => inst.rested && inst.don >= 1 && !myTurn(g, pid),
  activateOncePerTurn: true,
  activateMain: async (g, ctx) => {
    if (ctx.self.rested) throw new Error('Kid is already rested.');
    if (!(await g.yesno(ctx.pid, 'Rest Kid to play a Character (cost ≤3) from your hand?'))) return false;
    ctx.self.rested = true;
    g.pushState();
    await mayPlayFromHand(g, ctx, { filter: (c) => (card(g, c).cost || 0) <= 3, title: 'Play a Character (cost ≤3) from your hand' });
  },
};

// OP01-052 Raizo: [When Attacking][OPT] if you have 2+ rested Characters, draw 1.
E['OP01-052'] = {
  whenAttacking: async (g, ctx) => {
    if (ctx.self.optUsed['raizo'] === g.turn.n) return;
    if (g.P(ctx.pid).chars.filter((c) => c.rested).length >= 2) {
      ctx.self.optUsed['raizo'] = g.turn.n;
      await g.draw(ctx.pid, 1);
    }
  },
};

// OP01-054 X.Drake: [On Play] K.O. opp rested char cost ≤4.
E['OP01-054'] = {
  onPlay: (g, ctx) => koOpp(g, ctx, { filter: (i) => i.rested && (card(g, i).cost || 0) <= 4, title: "K.O. an opponent's rested Character (cost ≤4)" }),
};

// OP01-055 You Can Be My Samurai!! (Event): [Main] may rest 2 of your chars: draw 2.
E['OP01-055'] = {
  main: async (g, ctx) => {
    const pool = g.P(ctx.pid).chars.filter((c) => !c.rested);
    if (pool.length < 2) { g.log('Not enough active Characters to rest — no effect.'); return; }
    const t = await g.pickTargets(ctx.pid, { side: 'you', leaders: false, min: 0, max: 2, filter: (i) => !i.rested, title: 'Rest 2 of your Characters to draw 2 cards' });
    if (t.length !== 2) { g.log('Effect cancelled.'); return; }
    for (const i of t) i.rested = true;
    await g.draw(ctx.pid, 2);
  },
};

// OP01-056 Demon Face (Event): [Main] K.O. up to 2 opp rested chars cost ≤5.
E['OP01-056'] = {
  main: (g, ctx) => koOpp(g, ctx, { max: 2, filter: (i) => i.rested && (card(g, i).cost || 0) <= 5, title: "K.O. up to 2 of your opponent's rested Characters (cost ≤5)" }),
};

// OP01-057 Paradise Waterfall (Event)
E['OP01-057'] = {
  counter: async (g, ctx) => {
    await buffTargets(g, ctx, { side: 'you', leaders: true, amount: 2000, until: 'battle', title: 'Give a Leader or Character +2000 this battle' });
    await setActiveMine(g, ctx, { title: 'Set up to 1 of your Characters active' });
  },
  trigger: (g, ctx) => koOpp(g, ctx, { filter: (i) => i.rested && (card(g, i).cost || 0) <= 4, title: "K.O. an opponent's rested Character (cost ≤4)" }),
};

// OP01-058 Punk Gibson (Event)
E['OP01-058'] = {
  counter: async (g, ctx) => {
    await buffTargets(g, ctx, { side: 'you', leaders: true, amount: 4000, until: 'battle', title: 'Give a Leader or Character +4000 this battle' });
    await restOpp(g, ctx, { filter: costLE(g, 4), title: "Rest an opponent's Character (cost ≤4)" });
  },
  trigger: (g, ctx) => restOpp(g, ctx, { title: "Rest an opponent's Character" }),
};

// OP01-059 BE-BENG!! (Event)
E['OP01-059'] = {
  main: async (g, ctx) => {
    if (!(await mayTrashHand(g, ctx, { filter: (c) => hasType(g, c, 'Land of Wano'), title: 'Trash a "Land of Wano" card from your hand' }))) return;
    await setActiveMine(g, ctx, { filter: (i) => hasType(g, i, 'Land of Wano') && (card(g, i).cost || 0) <= 3, title: 'Set a "Land of Wano" Character (cost ≤3) active' });
  },
};

// =========================================================== BLUE ==========

// OP01-060 Donquixote Doflamingo (Leader)
E['OP01-060'] = {
  whenAttacking: async (g, ctx) => {
    if (!needDon(g, ctx, 2) || g.P(ctx.pid).donActive < 1) return;
    if (!(await g.yesno(ctx.pid, 'Pay ① to reveal the top card of your deck? (Warlords Character cost ≤4 may be played rested)'))) return;
    g.payDon(ctx.pid, 1);
    const p = g.P(ctx.pid);
    if (p.deck.length === 0) return;
    const top = p.deck[0];
    g.log(`${p.name} revealed ${card(g, top).name} from the top of the deck.`);
    if (isChar(g, top) && hasType(g, top, 'The Seven Warlords of the Sea') && (card(g, top).cost || 0) <= 4) {
      if (await g.yesno(ctx.pid, `Play ${card(g, top).name} rested?`)) {
        p.deck.shift();
        await g.playCharacter(ctx.pid, top, { rested: true });
      }
    }
  },
};

// OP01-061 Kaido (Leader): [DON!!x1][Your Turn][OPT] when opp char KO'd, add 1 DON!! active.
E['OP01-061'] = {
  onOppCharKOd: async (g, { pid, self }) => {
    if (self.don < 1 || !myTurn(g, pid)) return;
    if (!oncePerTurn(g, self, 'kaidoL')) return;
    g.log('Kaido: a Character was K.O.\'d — adding 1 DON!!.');
    g.addDon(pid, 1);
  },
};

// OP01-062 Crocodile (Leader): [DON!!x1] on your Event, draw if hand ≤4 (once per turn).
E['OP01-062'] = {
  onEventActivated: async (g, { pid, self, byPid }) => {
    if (byPid !== pid || self.don < 1) return;
    if (g.P(pid).hand.length > 4) return;
    if (self.optUsed['crocL'] === g.turn.n) return;
    if (!(await g.yesno(pid, 'Crocodile: draw 1 card?'))) return;
    self.optUsed['crocL'] = g.turn.n;
    await g.draw(pid, 1);
  },
};

// OP01-063 Arlong
E['OP01-063'] = {
  activateMain: async (g, ctx) => {
    if (ctx.self.don < 1) throw new Error('Needs 1 DON!! attached.');
    if (ctx.self.rested) throw new Error('Arlong is already rested.');
    const opid = g.oppOf(ctx.pid);
    const ohand = g.P(opid).hand;
    if (ohand.length === 0) throw new Error('Opponent has no cards in hand.');
    if (!(await g.yesno(ctx.pid, "Rest Arlong to peek at 1 card of your opponent's hand?"))) return false;
    ctx.self.rested = true;
    const idx = await g.ask(ctx.pid, { kind: 'pickIndex', title: `Choose 1 of your opponent's ${ohand.length} hand cards to reveal`, count: ohand.length });
    const chosen = ohand[Math.max(0, Math.min(ohand.length - 1, idx | 0))];
    g.log(`${g.names[opid]} revealed ${card(g, chosen).name}!`);
    await g.ask(ctx.pid, { kind: 'info', title: 'Revealed card', cards: [{ code: chosen.code }] });
    if (card(g, chosen).type === 'Event') {
      const o = g.P(opid);
      if (o.life.length > 0 && (await g.yesno(ctx.pid, "Place the top card of your opponent's Life at the bottom of their deck?"))) {
        const lc = o.life.shift();
        o.deck.push(lc);
        g.log(`The top card of ${o.name}'s Life was placed at the bottom of their deck. (${o.life.length} life left)`);
        g.pushState();
      }
    }
  },
};

// OP01-064 Alvida: [DON!!x1][When Attacking] may trash 1: return opp char cost ≤3 to hand.
E['OP01-064'] = {
  whenAttacking: async (g, ctx) => {
    if (!needDon(g, ctx, 1)) return;
    if (!(await mayTrashHand(g, ctx, { title: "Trash 1 card from your hand to bounce an opponent's Character (cost ≤3)?" }))) return;
    const t = await g.pickTargets(ctx.pid, { side: 'opp', leaders: false, min: 0, max: 1, filter: costLE(g, 3), title: "Return an opponent's Character (cost ≤3) to their hand" });
    if (t.length) g.returnToHand(t[0]);
  },
};

// OP01-067 Crocodile: [Banish] [DON!!x1] blue Events in your hand −1 cost.
E['OP01-067'] = {
  contCost: (g, src, srcPid, cardDef, forPid) =>
    (srcPid === forPid && src.don >= 1 && cardDef.type === 'Event' && cardDef.colors.includes('Blue')) ? -1 : 0,
};

// OP01-068 Gecko Moria: [Your Turn] gains [Double Attack] with 5+ cards in hand.
E['OP01-068'] = {
  contKeywords: (g, inst, pid) => (myTurn(g, pid) && g.P(pid).hand.length >= 5) ? ['Double Attack'] : [],
};

// OP01-069 Caesar Clown: [On K.O.] play a [Smiley] from your deck, shuffle.
E['OP01-069'] = {
  onKO: async (g, ctx) => {
    const p = g.P(ctx.pid);
    const found = p.deck.find((c) => hasName(g, c, 'Smiley'));
    if (!found) { g.shuffle(p.deck); return; }
    if (await g.yesno(ctx.pid, 'Play a [Smiley] from your deck?')) {
      p.deck.splice(p.deck.indexOf(found), 1);
      await g.playCharacter(ctx.pid, found);
    }
    g.shuffle(p.deck);
    g.log(`${p.name} shuffled their deck.`);
  },
};

// OP01-070 Dracule Mihawk: [On Play] bottom-deck a Character cost ≤7 (either side).
E['OP01-070'] = {
  onPlay: async (g, ctx) => {
    const t = await g.pickTargets(ctx.pid, { side: 'any', leaders: false, min: 0, max: 1, filter: (i) => costLE(g, 7)(i) && i !== ctx.self, title: 'Place a Character (cost ≤7) at the bottom of its owner\'s deck' });
    if (t.length) g.bottomDeck(t[0]);
  },
};

// OP01-071 Jinbe: [On Play] bottom-deck a Character cost ≤3. [Trigger] Play this card.
E['OP01-071'] = {
  onPlay: async (g, ctx) => {
    const t = await g.pickTargets(ctx.pid, { side: 'any', leaders: false, min: 0, max: 1, filter: (i) => costLE(g, 3)(i) && i !== ctx.self, title: 'Place a Character (cost ≤3) at the bottom of its owner\'s deck' });
    if (t.length) g.bottomDeck(t[0]);
  },
  trigger: async (g, ctx) => { await g.playCharacter(ctx.pid, ctx.self); return 'played'; },
};

// OP01-072 Smiley: [DON!!x1][Your Turn] +1000 for every card in your hand.
E['OP01-072'] = {
  contPower: (g, src, sp, t) => (t === src && src.don >= 1 && myTurn(g, sp)) ? g.P(sp).hand.length * 1000 : 0,
};

// OP01-073 Donquixote Doflamingo: [Blocker] [On Play] look 5 top/bottom.
E['OP01-073'] = { onPlay: (g, ctx) => lookTopBottom(g, ctx, 5) };

// OP01-074 Bartholomew Kuma: [Blocker] [On K.O.] play a Pacifista cost ≤4 from hand.
E['OP01-074'] = {
  onKO: async (g, ctx) => {
    await mayPlayFromHand(g, ctx, { filter: (c) => hasName(g, c, 'Pacifista') && (card(g, c).cost || 0) <= 4, title: 'Play a [Pacifista] (cost ≤4) from your hand' });
  },
};

// OP01-075 Pacifista: [Blocker]; any number allowed in deck (handled in deck validation)

// OP01-077 Perona: [On Play] look 5 top/bottom.
E['OP01-077'] = { onPlay: (g, ctx) => lookTopBottom(g, ctx, 5) };

// OP01-078 Boa Hancock: [Blocker] [DON!!x1][When Attacking]/[On Block] draw if hand ≤5.
E['OP01-078'] = {
  whenAttacking: async (g, ctx) => { if (needDon(g, ctx, 1) && g.P(ctx.pid).hand.length <= 5) await g.draw(ctx.pid, 1); },
  onBlock: async (g, ctx) => { if (needDon(g, ctx, 1) && g.P(ctx.pid).hand.length <= 5) await g.draw(ctx.pid, 1); },
};

// OP01-079 Ms. All Sunday: [Blocker] [On K.O.] if leader Baroque Works: Event trash→hand.
E['OP01-079'] = {
  onKO: async (g, ctx) => {
    if (!leaderHasType(g, ctx.pid, 'Baroque Works')) return;
    const p = g.P(ctx.pid);
    const pool = p.trash.filter((c) => card(g, c).type === 'Event');
    const picked = await g.pickCards(ctx.pid, pool, { min: 0, max: 1, title: 'Add an Event from your trash to your hand', zoneLabel: 'Trash' });
    if (picked.length) {
      p.trash.splice(p.trash.indexOf(picked[0]), 1);
      p.hand.push(picked[0]);
      g.log(`${card(g, picked[0]).name} returned from the trash to hand.`);
    }
  },
};

// OP01-080 Miss Doublefinger(Zala): [On K.O.] draw a card.
E['OP01-080'] = { onKO: (g, ctx) => g.draw(ctx.pid, 1) };

// OP01-082 Monet: [Trigger] Play this card.
E['OP01-082'] = { trigger: async (g, ctx) => { await g.playCharacter(ctx.pid, ctx.self); return 'played'; } };

// OP01-083 Mr.1: [DON!!x1][Your Turn] if leader BW: +1000 per 2 Events in your trash.
E['OP01-083'] = {
  contPower: (g, src, sp, t) => {
    if (t !== src || src.don < 1 || !myTurn(g, sp) || !leaderHasType(g, sp, 'Baroque Works')) return 0;
    return Math.floor(g.P(sp).trash.filter((c) => card(g, c).type === 'Event').length / 2) * 1000;
  },
};

// OP01-084 Mr.2.Bon.Kurei: [DON!!x1][When Attacking] look 5 reveal BW Event → hand.
E['OP01-084'] = {
  whenAttacking: async (g, ctx) => {
    if (!needDon(g, ctx, 1)) return;
    await lookRevealAdd(g, ctx, { filter: (c) => card(g, c).type === 'Event' && hasType(g, c, 'Baroque Works'), what: '"Baroque Works" Event' });
  },
};

// OP01-085 Mr.3: [On Play] if leader BW: opp char cost ≤4 can't attack until end of opp's next turn.
E['OP01-085'] = {
  onPlay: async (g, ctx) => {
    if (!leaderHasType(g, ctx.pid, 'Baroque Works')) return;
    const t = await g.pickTargets(ctx.pid, { side: 'opp', leaders: false, min: 0, max: 1, filter: costLE(g, 4), title: "Select an opponent's Character (cost ≤4) — it cannot attack until the end of their next turn" });
    if (t.length) {
      t[0].cannotAttackUntilTurn = g.turn.n + 1; // opponent's next turn
      g.log(`${card(g, t[0]).name} cannot attack until the end of ${g.names[g.oppOf(ctx.pid)]}'s next turn.`);
    }
  },
};

// OP01-086 Overheat (Event)
E['OP01-086'] = {
  counter: async (g, ctx) => {
    await buffTargets(g, ctx, { side: 'you', leaders: true, amount: 4000, until: 'battle', title: 'Give a Leader or Character +4000 this battle' });
    const t = await g.pickTargets(ctx.pid, { side: 'any', leaders: false, min: 0, max: 1, filter: (i) => !i.rested && costLE(g, 3)(i), title: 'Return an active Character (cost ≤3) to its owner\'s hand' });
    if (t.length) g.returnToHand(t[0]);
  },
  trigger: async (g, ctx) => {
    const t = await g.pickTargets(ctx.pid, { side: 'any', leaders: false, min: 0, max: 1, filter: costLE(g, 4), title: 'Return a Character (cost ≤4) to its owner\'s hand' });
    if (t.length) g.returnToHand(t[0]);
  },
};

// OP01-087 Officer Agents (Event): [Counter] play a BW card cost ≤3 from hand.
E['OP01-087'] = {
  counter: async (g, ctx) => {
    await mayPlayFromHand(g, ctx, { filter: (c) => hasType(g, c, 'Baroque Works') && (card(g, c).cost || 0) <= 3, title: 'Play a "Baroque Works" Character (cost ≤3) from your hand' });
  },
};

// OP01-088 Desert Spada (Event)
E['OP01-088'] = {
  counter: async (g, ctx) => {
    await buffTargets(g, ctx, { side: 'you', leaders: true, amount: 2000, until: 'battle', title: 'Give a Leader or Character +2000 this battle' });
    await lookTopBottom(g, ctx, 3);
  },
};

// OP01-089 Crescent Cutlass (Event)
E['OP01-089'] = {
  counterCanUse: (g, pid) => leaderHasType(g, pid, 'The Seven Warlords of the Sea'),
  counter: async (g, ctx) => {
    const t = await g.pickTargets(ctx.pid, { side: 'any', leaders: false, min: 0, max: 1, filter: costLE(g, 5), title: 'Return a Character (cost ≤5) to its owner\'s hand' });
    if (t.length) g.returnToHand(t[0]);
  },
};

// OP01-090 Baroque Works (Event): [Main] look 5 reveal BW card (not [Baroque Works]) → hand.
E['OP01-090'] = {
  main: (g, ctx) => lookRevealAdd(g, ctx, {
    filter: (c) => hasType(g, c, 'Baroque Works') && card(g, c).name !== 'Baroque Works',
    what: '"Baroque Works" card',
  }),
};

// ========================================================= PURPLE ==========

// OP01-091 King (Leader): [Your Turn] if 10 DON!! on your field, all opp Characters −1000.
E['OP01-091'] = {
  contPower: (g, src, sp, t, tp) => (sp !== tp && myTurn(g, sp) && !g.isLeader(t) && g.donOnField(sp) >= 10) ? -1000 : 0,
};

// OP01-093 Ulti: [On Play] (1): add 1 DON!! rested.
E['OP01-093'] = {
  onPlay: async (g, ctx) => {
    if (g.P(ctx.pid).donActive < 1 || g.P(ctx.pid).donDeck < 1) return;
    if (!(await g.yesno(ctx.pid, "Pay ① for Ulti's effect? (add 1 DON!! rested)"))) return;
    g.payDon(ctx.pid, 1);
    g.addDon(ctx.pid, 1, { rested: true });
  },
};

// OP01-094 Kaido: [On Play] DON!!−6: if leader AKP, K.O. ALL other Characters.
E['OP01-094'] = {
  onPlay: async (g, ctx) => {
    if (!leaderHasType(g, ctx.pid, 'Animal Kingdom Pirates')) return;
    if (!(await payDonMinus(g, ctx, 6, 'K.O. ALL Characters other than Kaido'))) return;
    for (const p of g.players) {
      for (const c of [...p.chars]) {
        if (c !== ctx.self) await g.ko(c, { byBattle: false });
      }
    }
  },
};

// OP01-095 Kyoshirou: [On Play] draw 1 if you have 8+ DON!! on your field.
E['OP01-095'] = { onPlay: async (g, ctx) => { if (g.donOnField(ctx.pid) >= 8) await g.draw(ctx.pid, 1); } };

// OP01-096 King: [On Play] DON!!−2: K.O. opp char cost ≤3 and opp char cost ≤2.
E['OP01-096'] = {
  onPlay: async (g, ctx) => {
    if (!(await payDonMinus(g, ctx, 2, "K.O. an opponent's Character (cost ≤3) and one (cost ≤2)"))) return;
    const first = await koOpp(g, ctx, { filter: costLE(g, 3), title: "K.O. an opponent's Character (cost ≤3)" });
    await koOpp(g, ctx, { filter: (i) => costLE(g, 2)(i) && !first.includes(i), title: "K.O. an opponent's Character (cost ≤2)" });
  },
};

// OP01-097 Queen: [On Play] DON!!−1: gain [Rush]; opp char −2000 this turn.
E['OP01-097'] = {
  onPlay: async (g, ctx) => {
    if (!(await payDonMinus(g, ctx, 1, 'give Queen [Rush] and an opponent −2000'))) return;
    g.grantKw(ctx.self, 'Rush', 'turn');
    g.log('Queen gains [Rush]!');
    await buffTargets(g, ctx, { amount: -2000, title: "Give an opponent's Character −2000 this turn" });
  },
};

// OP01-098 Kurozumi Orochi: [On Play] reveal an Artificial Devil Fruit SMILE from deck → hand.
E['OP01-098'] = {
  onPlay: async (g, ctx) => {
    const p = g.P(ctx.pid);
    const found = p.deck.find((c) => card(g, c).name === 'Artificial Devil Fruit SMILE');
    if (found && (await g.yesno(ctx.pid, 'Add an [Artificial Devil Fruit SMILE] from your deck to your hand?'))) {
      p.deck.splice(p.deck.indexOf(found), 1);
      p.hand.push(found);
      g.log(`${p.name} revealed Artificial Devil Fruit SMILE and added it to hand.`);
    }
    g.shuffle(p.deck);
    g.log(`${p.name} shuffled their deck.`);
    g.pushState();
  },
};

// OP01-099 Kurozumi Semimaru: other Kurozumi Clan characters can't be battle-KO'd.
E['OP01-099'] = {
  koProtect: (g, src, srcPid, target) =>
    target !== src && g.ownerOf(target) === srcPid && hasType(g, target, 'Kurozumi Clan'),
};

// OP01-101 Sasaki: [DON!!x1][When Attacking] may trash 1: add 1 DON!! rested.
E['OP01-101'] = {
  whenAttacking: async (g, ctx) => {
    if (!needDon(g, ctx, 1) || g.P(ctx.pid).donDeck < 1) return;
    if (await mayTrashHand(g, ctx, { title: 'Trash 1 card from your hand to add 1 DON!! (rested)?' })) {
      g.addDon(ctx.pid, 1, { rested: true });
    }
  },
};

// OP01-102 Jack: [When Attacking] DON!!−1: opponent trashes 1 card.
E['OP01-102'] = {
  whenAttacking: async (g, ctx) => {
    if (!(await payDonMinus(g, ctx, 1, 'make your opponent trash 1 card'))) return;
    await oppTrashes(g, ctx);
  },
};

// OP01-105 Bao Huang: [On Play] choose 2 cards from opponent's hand; they reveal them.
E['OP01-105'] = {
  onPlay: async (g, ctx) => {
    const opid = g.oppOf(ctx.pid);
    const ohand = g.P(opid).hand;
    if (ohand.length === 0) return;
    const n = Math.min(2, ohand.length);
    const picked = new Set();
    for (let k = 0; k < n; k++) {
      const idx = await g.ask(ctx.pid, { kind: 'pickIndex', title: `Choose card ${k + 1}/${n} from your opponent's ${ohand.length} hand cards to reveal`, count: ohand.length, exclude: [...picked] });
      picked.add(Math.max(0, Math.min(ohand.length - 1, idx | 0)));
    }
    const cards = [...picked].map((i) => ohand[i]);
    g.log(`${g.names[opid]} revealed: ${cards.map((c) => card(g, c).name).join(', ')}.`);
    await g.ask(ctx.pid, { kind: 'info', title: 'Revealed cards', cards: cards.map((c) => ({ code: c.code })) });
  },
};

// OP01-106 Basil Hawkins: [On Play] add 1 DON!! rested. [Trigger] Play this card.
E['OP01-106'] = {
  onPlay: async (g, ctx) => { g.addDon(ctx.pid, 1, { rested: true }); },
  trigger: async (g, ctx) => { await g.playCharacter(ctx.pid, ctx.self); return 'played'; },
};

// OP01-104 Speed: [Trigger] Play this card.
E['OP01-104'] = { trigger: async (g, ctx) => { await g.playCharacter(ctx.pid, ctx.self); return 'played'; } };

// OP01-108 Hitokiri Kamazo: [On K.O.] DON!!−1: K.O. opp char cost ≤5.
E['OP01-108'] = {
  onKO: async (g, ctx) => {
    if (!(await payDonMinus(g, ctx, 1, "K.O. an opponent's Character (cost ≤5)"))) return;
    await koOpp(g, ctx, { filter: costLE(g, 5), title: "K.O. an opponent's Character (cost ≤5)" });
  },
};

// OP01-109 Who's.Who: [DON!!x1][Your Turn] +1000 if 8+ DON!! on your field.
E['OP01-109'] = {
  contPower: (g, src, sp, t) => (t === src && src.don >= 1 && myTurn(g, sp) && g.donOnField(sp) >= 8) ? 1000 : 0,
};

// OP01-111 Black Maria: [Blocker] [On Block] DON!!−1: +1000 this turn.
E['OP01-111'] = {
  onBlock: async (g, ctx) => {
    if (!(await payDonMinus(g, ctx, 1, 'give Black Maria +1000 this turn'))) return;
    g.addMod(ctx.self, 1000, 'turn');
    g.log('Black Maria gains +1000 power this turn.');
  },
};

// OP01-112 Page One: [Activate:Main][OPT] DON!!−1: can attack active Characters this turn.
E['OP01-112'] = {
  activateOncePerTurn: true,
  activateMain: async (g, ctx) => {
    if (!(await payDonMinus(g, ctx, 1, 'let Page One attack active Characters this turn'))) return false;
    g.grantKw(ctx.self, 'CanAttackActive', 'turn');
    g.log('Page One can attack active Characters this turn.');
  },
};

// OP01-113 Holedem: [On K.O.] add 1 DON!! rested.
E['OP01-113'] = { onKO: async (g, ctx) => { g.addDon(ctx.pid, 1, { rested: true }); } };

// OP01-114 X.Drake: [On Play] DON!!−1: opponent trashes 1 card.
E['OP01-114'] = {
  onPlay: async (g, ctx) => {
    if (!(await payDonMinus(g, ctx, 1, 'make your opponent trash 1 card'))) return;
    await oppTrashes(g, ctx);
  },
};

// OP01-115 Elephant's Marchoo (Event)
E['OP01-115'] = {
  main: async (g, ctx) => {
    await koOpp(g, ctx, { filter: costLE(g, 2), title: "K.O. an opponent's Character (cost ≤2)" });
    g.addDon(ctx.pid, 1);
  },
  trigger: (g, ctx) => E['OP01-115'].main(g, ctx),
};

// OP01-116 Artificial Devil Fruit SMILE (Event): [Main] look 5; play a SMILE char cost ≤3.
E['OP01-116'] = {
  main: (g, ctx) => lookRevealAdd(g, ctx, {
    filter: (c) => isChar(g, c) && hasType(g, c, 'SMILE') && (card(g, c).cost || 0) <= 3,
    what: '"SMILE" Character (cost ≤3)', playInstead: true,
  }),
};

// OP01-117 Sheep's Horn (Event): [Main] DON!!−1: rest opp char cost ≤6.
E['OP01-117'] = {
  main: async (g, ctx) => {
    if (!(await payDonMinus(g, ctx, 1, "rest an opponent's Character (cost ≤6)"))) return;
    await restOpp(g, ctx, { filter: costLE(g, 6), title: "Rest an opponent's Character (cost ≤6)" });
  },
};

// OP01-118 Ulti-Mortar (Event)
E['OP01-118'] = {
  counterCanUse: (g, pid) => g.canReturnDon(pid, 2),
  counter: async (g, ctx) => {
    if (!(await payDonMinus(g, ctx, 2, 'give +2000 this battle and draw 1'))) return;
    await buffTargets(g, ctx, { side: 'you', leaders: true, amount: 2000, until: 'battle', title: 'Give a Leader or Character +2000 this battle' });
    await g.draw(ctx.pid, 1);
  },
  trigger: async (g, ctx) => { g.addDon(ctx.pid, 1); },
};

// OP01-119 Thunder Bagua (Event)
E['OP01-119'] = {
  counter: async (g, ctx) => {
    await buffTargets(g, ctx, { side: 'you', leaders: true, amount: 4000, until: 'battle', title: 'Give a Leader or Character +4000 this battle' });
    if (g.P(ctx.pid).life.length <= 2) g.addDon(ctx.pid, 1, { rested: true });
  },
  trigger: async (g, ctx) => { g.addDon(ctx.pid, 1); },
};

// OP01-120 Shanks: [Rush] [When Attacking] opponent can't block with ≤2000-power Blockers.
E['OP01-120'] = {
  whenAttacking: async (g, ctx) => {
    ctx.battle.noBlockUnderPower = 2000;
    g.log('Shanks: Blockers with 2000 power or less cannot be activated this battle!');
  },
};

// OP01-121 Yamato: [Double Attack] [Banish] + name alias (keywords parsed from text; alias in hasName)

if (typeof module !== 'undefined') module.exports = E;
