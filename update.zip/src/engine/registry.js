// Merged effect registry: OP-01 is fully hand-scripted (effects.js); every
// other set gets template-compiled handlers where the text parses cleanly
// (autofx.js). E.__flags[code] = 'scripted' | 'auto' | 'partial' | 'manual'.
'use strict';

const fs = require('fs');
const path = require('path');
const manual = require('./effects.js');
const { buildRegistry } = require('./autofx.js');

const db = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'data', 'cards.json'), 'utf8'));
module.exports = buildRegistry(db, manual);
