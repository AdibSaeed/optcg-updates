// ============================================================================
// One Piece Card Game — authoritative rules engine (OP-01 Romance Dawn).
// Runs on the hosting player's machine (and headless in tests). No DOM.
//
// The engine is fully server-authoritative: clients only ever send high-level
// actions ("play card 3", "attack with X targeting Y") and answers to choice
// requests. All hidden information (hands, decks, life cards) stays here and
// each player receives a redacted view.
// ============================================================================
'use strict';

// ---------------------------------------------------------------- utilities
function mulberry32(seed) {
  let a = seed >>> 0;
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const KW_RE = { Blocker: /\[Blocker\]/, Rush: /\[Rush\]/, 'Double Attack': /\[Double Attack\]/, Banish: /\[Banish\]/ };

class GameError extends Error {}

// ---------------------------------------------------------------- deck rules
function validateDeck(db, deck) {
  const byCode = (c) => db.find((x) => x.code === c);
  const leader = byCode(deck.leader);
  if (!leader || leader.type !== 'Leader') return 'Deck must have a valid Leader card.';
  if (!Array.isArray(deck.cards) || deck.cards.length !== 50) return `Deck must contain exactly 50 cards (has ${(deck.cards || []).length}).`;
  const counts = {};
  for (const code of deck.cards) {
    const c = byCode(code);
    if (!c) return `Unknown card: ${code}`;
    if (c.type === 'Leader') return `${c.name} is a Leader and cannot be in the 50-card deck.`;
    if (!c.colors.every((col) => leader.colors.includes(col))) return `${c.name} (${c.colors.join('/')}) does not match your Leader's colors (${leader.colors.join('/')}).`;
    counts[code] = (counts[code] || 0) + 1;
    // OP01-075 Pacifista: "you may have any number of this card in your deck."
    if (counts[code] > 4 && code !== 'OP01-075') return `More than 4 copies of ${c.name}.`;
  }
  return null;
}

// ---------------------------------------------------------------- the game
class Game {
  /**
   * @param db      card database (array from cards.json)
   * @param effects effect-script registry keyed by card code
   * @param decks   [{leader, cards:[codes]}, {leader, cards}]
   * @param opts    { seed, send(pid, msg), names:[..] }
   */
  constructor(db, effects, decks, opts = {}) {
    this.db = db;
    this.byCode = {};
    for (const c of db) this.byCode[c.code] = c;
    this.E = effects;
    this.rand = mulberry32(opts.seed ?? (Date.now() & 0xffffffff));
    this.sendFn = opts.send || (() => {});
    this.names = opts.names || ['Player 1', 'Player 2'];
    this.iidSeq = 0;
    this.reqSeq = 0;
    this.pendingReq = null;   // {id, pid, resolve, req}
    this.busy = false;
    this.over = false;
    this.battle = null;
    this.turn = { n: 0, pid: 0, phase: 'setup' };
    this.logLines = [];

    for (const d of decks) {
      const err = validateDeck(db, d);
      if (err) throw new GameError(err);
    }
    this.players = decks.map((d, pid) => {
      const leaderCard = this.byCode[d.leader];
      return {
        pid,
        name: this.names[pid],
        leader: this.mkInst(d.leader),
        chars: [],
        stage: null,
        hand: [],
        deck: this.shuffle(d.cards.map((c) => this.mkInst(c))),
        trash: [],
        life: [],
        lifeMax: leaderCard.life,
        donDeck: 10,
        donActive: 0,
        donRested: 0,
        leaderEffectFlags: {}, // per-turn bookkeeping for leader effects
      };
    });
  }

  // ------------------------------------------------------------- primitives
  mkInst(code) {
    return {
      iid: ++this.iidSeq, code, rested: false, don: 0,
      mods: [],            // {power, until:'turn'|'battle'}
      kws: [],             // granted keywords {kw, until}
      optUsed: {},         // once-per-turn ability keys -> turn number
      playedTurn: -1,
      cannotAttackUntilTurn: -1,
    };
  }
  card(inst) { return this.byCode[inst.code]; }
  shuffle(arr) {
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(this.rand() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  }
  P(pid) { return this.players[pid]; }
  oppOf(pid) { return 1 - pid; }
  log(msg) {
    this.logLines.push(msg);
    this.sendFn(0, { t: 'log', msg });
    this.sendFn(1, { t: 'log', msg });
  }
  /** Visual effect event for both clients (clash, toTrash, play...). */
  fx(data) {
    this.sendFn(0, { t: 'fx', ...data });
    this.sendFn(1, { t: 'fx', ...data });
  }
  send(pid, msg) { this.sendFn(pid, msg); }

  findInst(pid, iid) {
    const p = this.P(pid);
    if (p.leader.iid === iid) return p.leader;
    return p.chars.find((c) => c.iid === iid) || null;
  }
  ownerOf(inst) {
    for (const p of this.players) {
      if (p.leader === inst || p.chars.includes(inst)) return p.pid;
    }
    return -1;
  }
  isLeader(inst) { return this.players.some((p) => p.leader === inst); }

  // Total DON!! on a player's field (cost area + given), for King/Who's Who/Kyoshirou.
  donOnField(pid) {
    const p = this.P(pid);
    let n = p.donActive + p.donRested + p.leader.don;
    for (const c of p.chars) n += c.don;
    return n;
  }

  // --------------------------------------------------------------- keywords
  hasKw(inst, kw) {
    const card = this.card(inst);
    if (KW_RE[kw] && KW_RE[kw].test(card.text)) return true;
    if (inst.kws.some((k) => k.kw === kw)) return true;
    // continuous keyword grants from effect scripts (e.g. Gecko Moria)
    const fx = this.E[inst.code];
    if (fx && fx.contKeywords) {
      const owner = this.ownerOf(inst);
      if (owner >= 0 && fx.contKeywords(this, inst, owner).includes(kw)) return true;
    }
    return false;
  }

  // ------------------------------------------------------------------ power
  power(inst) {
    const owner = this.ownerOf(inst);
    if (owner < 0) return this.card(inst).power || 0;
    let pow = this.card(inst).power || 0;
    // Given DON!! grant +1000 each during the owner's turn.
    if (this.turn.pid === owner) pow += inst.don * 1000;
    for (const m of inst.mods) pow += m.power;
    // Continuous effects from every leader/character in play (both sides).
    for (const p of this.players) {
      for (const src of [p.leader, ...p.chars]) {
        const fx = this.E[src.code];
        if (fx && fx.contPower) pow += fx.contPower(this, src, p.pid, inst, owner);
      }
    }
    return Math.max(0, pow);
  }

  addMod(inst, power, until) {
    inst.mods.push({ power, until });
    this.pushState();
  }
  grantKw(inst, kw, until) { inst.kws.push({ kw, until }); }

  expire(scope) {
    for (const p of this.players) {
      for (const inst of [p.leader, ...p.chars]) {
        inst.mods = inst.mods.filter((m) => m.until !== scope);
        inst.kws = inst.kws.filter((k) => k.until !== scope);
      }
    }
  }

  // ------------------------------------------------------------- ask/answer
  ask(pid, req) {
    if (this.over) return Promise.resolve(null);
    req.id = ++this.reqSeq;
    return new Promise((resolve) => {
      this.pendingReq = { id: req.id, pid, resolve, req };
      this.send(pid, { t: 'ask', req });
      this.send(this.oppOf(pid), { t: 'waiting', for: this.names[pid], title: req.publicTitle || null });
    });
  }
  answer(pid, id, value) {
    const pr = this.pendingReq;
    if (!pr || pr.id !== id || pr.pid !== pid) return;
    this.pendingReq = null;
    this.send(this.oppOf(pid), { t: 'waiting', for: null });
    pr.resolve(value);
  }

  async yesno(pid, title) {
    const v = await this.ask(pid, { kind: 'yesno', title });
    return v === true || v === 'yes';
  }

  /**
   * Ask `pid` to select leader/character targets.
   * spec: { side:'you'|'opp'|'any', leaders:bool, chars:bool, filter(inst, ownerPid), min, max, title }
   * Returns array of insts (possibly empty when min is 0).
   */
  async pickTargets(pid, spec) {
    const opts = [];
    for (const p of this.players) {
      const rel = p.pid === pid ? 'you' : 'opp';
      if (spec.side && spec.side !== 'any' && spec.side !== rel) continue;
      const pool = [];
      if (spec.leaders) pool.push(p.leader);
      if (spec.chars !== false) pool.push(...p.chars);
      for (const inst of pool) {
        if (spec.filter && !spec.filter(inst, p.pid)) continue;
        opts.push({ iid: inst.iid, pid: p.pid });
      }
    }
    const min = spec.min ?? 0, max = spec.max ?? 1;
    if (opts.length === 0) return [];
    if (opts.length <= min && spec.autoIfForced) {
      return opts.map((o) => this.findInst(o.pid, o.iid));
    }
    const picked = await this.ask(pid, {
      kind: 'targets', title: spec.title, options: opts,
      min: Math.min(min, opts.length), max,
      tag: spec.tag, meta: spec.meta,
    });
    const insts = [];
    for (const iid of picked || []) {
      const o = opts.find((x) => x.iid === iid);
      if (o && !insts.some((i) => i.iid === iid)) insts.push(this.findInst(o.pid, o.iid));
    }
    return insts.slice(0, max).filter(Boolean);
  }

  /** Ask pid to pick cards from an explicit list of insts (hand, looked-at cards...). */
  async pickCards(pid, insts, { min = 0, max = 1, title, zoneLabel } = {}) {
    if (insts.length === 0) return [];
    const picked = await this.ask(pid, {
      kind: 'cards', title, zoneLabel,
      cards: insts.map((i) => ({ iid: i.iid, code: i.code })),
      min: Math.min(min, insts.length), max,
    });
    const out = [];
    for (const iid of picked || []) {
      const inst = insts.find((i) => i.iid === iid);
      if (inst && !out.includes(inst)) out.push(inst);
    }
    return out.slice(0, max);
  }

  // ------------------------------------------------------------- zone moves
  async draw(pid, n) {
    const p = this.P(pid);
    for (let i = 0; i < n; i++) {
      if (p.deck.length === 0) { await this.gameOver(this.oppOf(pid), `${p.name} has no cards left to draw`); return; }
      p.hand.push(p.deck.shift());
    }
    this.fx({ kind: 'draw', pid, n });
    this.log(`${p.name} drew ${n} card${n > 1 ? 's' : ''}.`);
    this.pushState();
  }

  trashFromHand(pid, inst) {
    const p = this.P(pid);
    const i = p.hand.indexOf(inst);
    if (i >= 0) { p.hand.splice(i, 1); p.trash.push(inst); }
    this.log(`${p.name} trashed ${this.card(inst).name} from hand.`);
  }

  addDon(pid, n, { rested = false } = {}) {
    const p = this.P(pid);
    const take = Math.min(n, p.donDeck);
    p.donDeck -= take;
    if (rested) p.donRested += take; else p.donActive += take;
    if (take > 0) this.log(`${p.name} added ${take} DON!! (${rested ? 'rested' : 'active'}).`);
    this.pushState();
    return take;
  }

  setDonActive(pid, n) {
    const p = this.P(pid);
    const take = Math.min(n, p.donRested);
    p.donRested -= take; p.donActive += take;
    if (take > 0) this.log(`${p.name} set ${take} DON!! as active.`);
    this.pushState();
    return take;
  }

  /** Pay a cost by resting n active DON!!. Returns false if not affordable. */
  payDon(pid, n) {
    const p = this.P(pid);
    if (p.donActive < n) return false;
    p.donActive -= n; p.donRested += n;
    this.pushState();
    return true;
  }

  /** DON!! −X : return n DON!! from the field to the DON!! deck. */
  returnDon(pid, n) {
    const p = this.P(pid);
    let need = n;
    const fromRested = Math.min(need, p.donRested); p.donRested -= fromRested; need -= fromRested;
    const fromActive = Math.min(need, p.donActive); p.donActive -= fromActive; need -= fromActive;
    // then from given DON!! (leader first, then characters with the most)
    const holders = [p.leader, ...[...p.chars].sort((a, b) => b.don - a.don)];
    for (const h of holders) {
      if (need <= 0) break;
      const take = Math.min(need, h.don); h.don -= take; need -= take;
    }
    p.donDeck += n - need;
    this.log(`${p.name} returned ${n - need} DON!! to their DON!! deck.`);
    this.pushState();
    return need === 0;
  }
  canReturnDon(pid, n) { return this.donOnField(pid) >= n; }

  /** Move a character card (or leader-target no) back to its owner's hand. */
  returnToHand(inst) {
    const pid = this.ownerOf(inst);
    if (pid < 0) return;
    const p = this.P(pid);
    const i = p.chars.indexOf(inst);
    if (i < 0) return; // leaders can't return to hand
    p.chars.splice(i, 1);
    this.releaseDon(p, inst);
    this.resetInst(inst);
    p.hand.push(inst);
    this.log(`${this.card(inst).name} returned to ${p.name}'s hand.`);
    this.pushState();
  }

  bottomDeck(inst) {
    const pid = this.ownerOf(inst);
    if (pid < 0) return;
    const p = this.P(pid);
    const i = p.chars.indexOf(inst);
    if (i < 0) return;
    p.chars.splice(i, 1);
    this.releaseDon(p, inst);
    this.resetInst(inst);
    p.deck.push(inst);
    this.log(`${this.card(inst).name} was placed at the bottom of ${p.name}'s deck.`);
    this.pushState();
  }

  releaseDon(p, inst) {
    // Given DON!! return to the cost area rested when the character leaves play.
    p.donRested += inst.don; inst.don = 0;
  }
  resetInst(inst) {
    inst.rested = false; inst.mods = []; inst.kws = []; inst.optUsed = {};
    inst.playedTurn = -1; inst.cannotAttackUntilTurn = -1;
  }

  /** K.O. a character. Applies battle-KO protections and fires [On K.O.] hooks. */
  async ko(inst, { byBattle = false, byAttacker = null } = {}) {
    const pid = this.ownerOf(inst);
    if (pid < 0) return false;
    const p = this.P(pid);
    if (!p.chars.includes(inst)) return false;

    if (byBattle) {
      // Battle-KO protections (Luffy OP01-024, Kurozumi Semimaru).
      for (const src of [p.leader, ...p.chars]) {
        const fx = this.E[src.code];
        if (fx && fx.koProtect && fx.koProtect(this, src, pid, inst, byAttacker)) {
          this.log(`${this.card(inst).name} cannot be K.O.'d in this battle!`);
          return false;
        }
      }
    }

    // fx first, while both clients' DOM still shows the card
    this.fx({ kind: 'toTrash', iid: inst.iid, pid, delay: byBattle ? 300 : 60 });
    p.chars.splice(p.chars.indexOf(inst), 1);
    this.releaseDon(p, inst);
    this.log(`${this.card(inst).name} was K.O.'d!`);
    p.trash.push(inst);
    this.pushState();

    // [On K.O.] of the card itself
    const fx = this.E[inst.code];
    if (fx && fx.onKO) await fx.onKO(this, { pid, self: inst });

    // other cards reacting to a KO (Kaido leader OP01-061)
    for (const pl of this.players) {
      for (const src of [pl.leader]) {
        const rfx = this.E[src.code];
        if (rfx && rfx.onOppCharKOd && pl.pid !== pid) {
          await rfx.onOppCharKOd(this, { pid: pl.pid, self: src, koInst: inst });
        }
      }
    }
    this.resetInst(inst);
    return true;
  }

  /**
   * Play a character/event/etc. `inst` for player pid.
   * source: 'hand' | 'trash' | 'deckSearch' | 'effect' (already removed from zones by caller when not hand/trash)
   */
  async playCharacter(pid, inst, { rested = false, fromZone = null } = {}) {
    const p = this.P(pid);
    if (fromZone) {
      const i = fromZone.indexOf(inst);
      if (i >= 0) fromZone.splice(i, 1);
    }
    // Character area holds 5. When full you must trash one of yours first.
    if (p.chars.length >= 5) {
      const toTrash = await this.pickTargets(pid, {
        side: 'you', chars: true, leaders: false, min: 1, max: 1, autoIfForced: false,
        title: 'Character area is full — choose a Character to trash',
      });
      if (toTrash.length === 0) { // shouldn't happen (min 1), safety: trash first
        toTrash.push(p.chars[0]);
      }
      const t = toTrash[0];
      p.chars.splice(p.chars.indexOf(t), 1);
      this.releaseDon(p, t);
      this.resetInst(t);
      p.trash.push(t);
      this.log(`${p.name} trashed ${this.card(t).name} to make room.`);
    }
    this.resetInst(inst);
    inst.rested = rested;
    inst.playedTurn = this.turn.n;
    p.chars.push(inst);
    this.log(`${p.name} played ${this.card(inst).name}${rested ? ' (rested)' : ''}.`);
    const flag = this.E.__flags && this.E.__flags[inst.code];
    if (flag === 'manual') this.log(`(Note: ${this.card(inst).name}'s text is not automated yet — treat it as printed stats and keywords.)`);
    else if (flag === 'partial') this.log(`(Note: some of ${this.card(inst).name}'s text is not automated yet.)`);
    this.fx({ kind: 'play', iid: inst.iid });
    this.pushState();
    const fx = this.E[inst.code];
    if (fx && fx.onPlay) await fx.onPlay(this, { pid, self: inst });
    // opponent reactions to plays: none in OP-01
    this.pushState();
  }

  /** Play or replace a Stage card. */
  playStage(pid, inst, { fromZone = null } = {}) {
    const p = this.P(pid);
    if (fromZone) { const i = fromZone.indexOf(inst); if (i >= 0) fromZone.splice(i, 1); }
    if (p.stage) {
      const old = p.stage;
      this.resetInst(old);
      p.trash.push(old);
      this.log(`${p.name}'s Stage ${this.card(old).name} was replaced and trashed.`);
    }
    this.resetInst(inst);
    p.stage = inst;
    this.log(`${p.name} played the Stage ${this.card(inst).name}.`);
    this.fx({ kind: 'play', iid: inst.iid });
    this.pushState();
  }

  /** Take the top card of your Life area into your hand (Cavendish/Sanji cost). */
  lifeToHand(pid) {
    const p = this.P(pid);
    if (p.life.length === 0) return null;
    const c = p.life.shift();
    p.hand.push(c);
    this.log(`${p.name} added the top card of their Life to their hand. (${p.life.length} life left)`);
    this.pushState();
    return c;
  }

  // ------------------------------------------------------------- life/damage
  async damage(pid, n, { banish = false } = {}) {
    const p = this.P(pid);
    for (let i = 0; i < n; i++) {
      if (this.over) return;
      if (p.life.length === 0) {
        await this.gameOver(this.oppOf(pid), `${p.name} took damage with no Life left`);
        return;
      }
      this.fx({ kind: 'damage', pid, banish });
      const card = p.life.shift();
      if (banish) {
        p.trash.push(card);
        this.log(`${p.name} took 1 damage — the Life card was banished to the trash! (${p.life.length} life left)`);
        this.pushState();
        continue;
      }
      const def = this.card(card);
      const fx = this.E[card.code];
      const hasTrigger = /\[Trigger\]/.test(def.text) && fx && fx.trigger;
      this.log(`${p.name} took 1 damage! (${p.life.length} life left)`);
      let activated = false;
      if (hasTrigger) {
        const want = await this.ask(pid, {
          kind: 'trigger', title: `Life card: ${def.name} — activate its [Trigger]?`,
          card: { code: card.code },
        });
        if (want === true || want === 'yes') {
          this.log(`${p.name} activated the [Trigger] of ${def.name}!`);
          const res = await fx.trigger(this, { pid, self: card });
          if (res !== 'played') p.trash.push(card);
          activated = true;
        }
      }
      if (!activated) p.hand.push(card);
      this.pushState();
    }
  }

  async gameOver(winnerPid, reason) {
    if (this.over) return;
    this.over = true;
    this.log(`GAME OVER — ${this.names[winnerPid]} wins! (${reason})`);
    this.send(0, { t: 'gameover', winner: winnerPid, reason, turns: this.turn.n });
    this.send(1, { t: 'gameover', winner: winnerPid, reason, turns: this.turn.n });
  }

  // ------------------------------------------------------------------ setup
  async start(firstPid = null) {
    this.firstPid = firstPid === null ? (this.rand() < 0.5 ? 0 : 1) : firstPid;
    this.log(`${this.names[this.firstPid]} goes first!`);
    // draw 5, one mulligan each
    for (const p of this.players) {
      p.hand = p.deck.splice(0, 5);
      this.pushState();
      const redraw = await this.yesno(p.pid, 'Keep this hand? Choose No to mulligan (shuffle back and draw 5 new cards — once only).');
      if (!redraw) {
        p.deck.push(...p.hand); p.hand = [];
        this.shuffle(p.deck);
        p.hand = p.deck.splice(0, 5);
        this.log(`${p.name} took a mulligan.`);
      } else {
        this.log(`${p.name} kept their hand.`);
      }
      this.pushState();
    }
    // place life
    for (const p of this.players) {
      p.life = p.deck.splice(0, p.lifeMax);
      this.log(`${p.name} placed ${p.lifeMax} Life cards.`);
    }
    this.turn = { n: 0, pid: this.oppOf(this.firstPid), phase: 'setup' };
    this.pushState();
    await this.startTurn();
  }

  async startTurn() {
    if (this.over) return;
    this.turn.n += 1;
    this.turn.pid = this.oppOf(this.turn.pid);
    const p = this.P(this.turn.pid);
    this.turn.phase = 'refresh';
    // Refresh: given DON!! return to cost area, everything becomes active.
    p.donActive += p.donRested; p.donRested = 0;
    for (const inst of [p.leader, ...p.chars]) {
      p.donActive += inst.don; inst.don = 0;
      inst.rested = false;
    }
    // expire lingering effects whose duration was "until end of opponent's next turn" etc.
    this.log(`—— Turn ${this.turn.n}: ${p.name} ——`);

    // Draw phase (the player going first skips their first draw)
    this.turn.phase = 'draw';
    if (this.turn.n > 1) await this.draw(this.turn.pid, 1);
    if (this.over) return;

    // DON!! phase
    this.turn.phase = 'don';
    this.addDon(this.turn.pid, this.turn.n === 1 ? 1 : 2);

    this.turn.phase = 'main';
    p.leaderEffectFlags = {};
    this.pushState();
  }

  async endTurn() {
    this.expire('turn');
    this.turn.phase = 'end';
    this.pushState();
    await this.startTurn();
  }

  // ----------------------------------------------------------------- actions
  /** Entry point for client messages. */
  onMessage(pid, msg) {
    if (this.over) return;
    if (msg.t === 'choice') { this.answer(pid, msg.id, msg.value); return; }
    if (msg.t === 'concede') { this.gameOver(this.oppOf(pid), `${this.names[pid]} conceded`); return; }
    if (msg.t !== 'action') return;
    if (this.busy || this.pendingReq) { this.send(pid, { t: 'nope', why: 'Resolving another effect — wait for it to finish.' }); return; }
    if (this.turn.phase !== 'main' || this.turn.pid !== pid) { this.send(pid, { t: 'nope', why: 'Not your main phase.' }); return; }
    this.busy = true;
    this.runAction(pid, msg)
      .catch((e) => { this.send(pid, { t: 'nope', why: e.message }); })
      .finally(() => { this.busy = false; this.pushState(); });
  }

  async runAction(pid, msg) {
    switch (msg.a) {
      case 'endTurn': this.log(`${this.names[pid]} ended their turn.`); await this.endTurn(); break;
      case 'playCard': await this.actPlayCard(pid, msg.iid); break;
      case 'attachDon': await this.actAttachDon(pid, msg.iid); break;
      case 'attack': await this.actAttack(pid, msg.iid, msg.targetIid); break;
      case 'activate': await this.actActivate(pid, msg.iid); break;
      default: throw new GameError('Unknown action');
    }
  }

  effectiveCost(pid, card) {
    let cost = card.cost || 0;
    // continuous cost modifiers (Crocodile OP01-067: blue events −1)
    for (const p of this.players) {
      for (const src of [p.leader, ...p.chars]) {
        const fx = this.E[src.code];
        if (fx && fx.contCost) cost += fx.contCost(this, src, p.pid, card, pid);
      }
    }
    return Math.max(0, cost);
  }

  async actPlayCard(pid, iid) {
    const p = this.P(pid);
    const inst = p.hand.find((c) => c.iid === iid);
    if (!inst) throw new GameError('Card not in hand.');
    const card = this.card(inst);
    const cost = this.effectiveCost(pid, card);
    if (p.donActive < cost) throw new GameError(`Not enough active DON!! (need ${cost}).`);

    if (card.type === 'Character') {
      this.payDon(pid, cost);
      p.hand.splice(p.hand.indexOf(inst), 1);
      await this.playCharacter(pid, inst);
    } else if (card.type === 'Stage') {
      this.payDon(pid, cost);
      p.hand.splice(p.hand.indexOf(inst), 1);
      this.playStage(pid, inst);
      const fx = this.E[inst.code];
      if (fx && fx.onPlay) await fx.onPlay(this, { pid, self: inst });
      this.pushState();
    } else if (card.type === 'Event') {
      const fx = this.E[inst.code];
      if (!fx || !fx.main) throw new GameError('This Event has no [Main] effect — it can only be used as a Counter during battles.');
      this.payDon(pid, cost);
      p.hand.splice(p.hand.indexOf(inst), 1);
      this.log(`${p.name} played the Event ${card.name}.`);
      this.pushState();
      await fx.main(this, { pid, self: inst });
      p.trash.push(inst);
      await this.fireEventActivated(pid);
    } else {
      throw new GameError('Cannot play that card type.');
    }
  }

  async fireEventActivated(byPid) {
    // Usopp OP01-004 (opponent's events), Crocodile leader OP01-062 (your events)
    for (const p of this.players) {
      for (const src of [p.leader, ...p.chars]) {
        const fx = this.E[src.code];
        if (fx && fx.onEventActivated) await fx.onEventActivated(this, { pid: p.pid, self: src, byPid });
      }
    }
    this.pushState();
  }

  async actAttachDon(pid, iid) {
    const p = this.P(pid);
    if (p.donActive < 1) throw new GameError('No active DON!! to give.');
    const inst = this.findInst(pid, iid);
    if (!inst) throw new GameError('Give DON!! to your own Leader or a Character.');
    p.donActive -= 1;
    inst.don += 1;
    this.log(`${p.name} gave 1 DON!! to ${this.card(inst).name} (total ${inst.don}).`);
    this.pushState();
  }

  canAttackActive(attacker, pid) {
    if (attacker.kws.some((k) => k.kw === 'CanAttackActive')) return true;
    const fx = this.E[attacker.code];
    return !!(fx && fx.contCanAttackActive && fx.contCanAttackActive(this, attacker, pid));
  }

  async actAttack(pid, iid, targetIid) {
    const p = this.P(pid), o = this.P(this.oppOf(pid));
    const attacker = this.findInst(pid, iid);
    if (!attacker) throw new GameError('No such attacker.');
    if (attacker.rested) throw new GameError('That card is rested.');
    const isLeader = this.isLeader(attacker);
    if (!isLeader) {
      if (attacker.playedTurn === this.turn.n && !this.hasKw(attacker, 'Rush')) throw new GameError('Characters cannot attack the turn they are played (unless they have [Rush]).');
      if (this.turn.n <= attacker.cannotAttackUntilTurn) throw new GameError('This Character cannot attack right now.');
    }
    if ((this.card(attacker).power ?? null) === null) throw new GameError('This card cannot attack.');

    // valid targets: opponent leader, opponent rested characters (or active if allowed)
    let target = null;
    if (targetIid === 'leader') target = o.leader;
    else {
      target = o.chars.find((c) => c.iid === targetIid);
      if (!target) throw new GameError('No such target.');
      if (!target.rested && !this.canAttackActive(attacker, pid)) throw new GameError('You can only attack rested Characters.');
    }
    // Eustass Kid OP01-051 restriction
    for (const c of o.chars) {
      const fx = this.E[c.code];
      if (fx && fx.attackRestriction && fx.attackRestriction(this, c, o.pid) && target !== c) {
        throw new GameError(`You can only attack ${this.card(c).name} right now.`);
      }
    }

    attacker.rested = true;
    this.battle = { attacker, attackerPid: pid, target, targetPid: o.pid, blocked: false, noBlockUnderPower: -1 };
    this.log(`${p.name}'s ${this.card(attacker).name} (${this.power(attacker)}) attacks ${target === o.leader ? o.name + "'s Leader " : ''}${this.card(target).name}!`);
    this.pushState();

    // [When Attacking] effects
    const fx = this.E[attacker.code];
    if (fx && fx.whenAttacking) await fx.whenAttacking(this, { pid, self: attacker, battle: this.battle });
    if (this.over) { this.battle = null; return; }

    // Block step
    const blockers = o.chars.filter((c) => !c.rested && c !== this.battle.target && this.hasKw(c, 'Blocker')
      && this.power(c) > this.battle.noBlockUnderPower);
    if (blockers.length > 0) {
      const picked = await this.pickTargets(o.pid, {
        side: 'you', chars: true, leaders: false, min: 0, max: 1,
        filter: (inst) => blockers.includes(inst),
        title: `${this.card(attacker).name} is attacking with ${this.power(attacker)} power — activate a [Blocker]?`,
        tag: 'block',
        meta: { atk: this.power(attacker), targetIsLeader: this.isLeader(this.battle.target), targetCode: this.battle.target.code },
      });
      if (picked.length === 1) {
        const blocker = picked[0];
        blocker.rested = true;
        this.battle.target = blocker;
        this.battle.blocked = true;
        this.log(`${o.name}'s ${this.card(blocker).name} blocks!`);
        this.pushState();
        const bfx = this.E[blocker.code];
        if (bfx && bfx.onBlock) await bfx.onBlock(this, { pid: o.pid, self: blocker, battle: this.battle });
      }
    }
    if (this.over) { this.battle = null; return; }

    // Counter step — defender may use any number of counters
    await this.counterStep(o.pid);
    if (this.over) { this.battle = null; return; }

    // Damage step
    const atk = this.power(this.battle.attacker);
    const def = this.power(this.battle.target);
    this.log(`Battle: ${this.card(this.battle.attacker).name} ${atk} vs ${this.card(this.battle.target).name} ${def}.`);
    this.fx({ kind: 'clash', attackerIid: this.battle.attacker.iid, targetIid: this.battle.target.iid, hit: atk >= def });
    if (atk >= def) {
      if (this.isLeader(this.battle.target)) {
        const dmg = this.hasKw(this.battle.attacker, 'Double Attack') ? 2 : 1;
        const banish = this.hasKw(this.battle.attacker, 'Banish');
        await this.damage(this.battle.targetPid, dmg, { banish });
      } else {
        await this.ko(this.battle.target, { byBattle: true, byAttacker: this.battle.attacker });
      }
    } else {
      this.log('The attack was repelled!');
    }
    this.expire('battle');
    this.battle = null;
    this.pushState();
  }

  async counterStep(defPid) {
    const p = this.P(defPid);
    for (;;) {
      if (this.over) return;
      const options = [];
      for (const c of p.hand) {
        const card = this.card(c);
        if (card.counter > 0) options.push({ iid: c.iid, code: c.code, use: 'counter', label: `+${card.counter}` });
        const fx = this.E[c.code];
        if (card.type === 'Event' && fx && fx.counter) {
          const cost = this.effectiveCost(defPid, card);
          if (p.donActive >= cost && (!fx.counterCanUse || fx.counterCanUse(this, defPid))) {
            options.push({ iid: c.iid, code: c.code, use: 'event', label: `Event (cost ${cost})` });
          }
        }
      }
      if (options.length === 0) return;
      const pick = await this.ask(defPid, {
        kind: 'counter',
        title: `Counter step — ${this.card(this.battle.attacker).name} ${this.power(this.battle.attacker)} vs ${this.card(this.battle.target).name} ${this.power(this.battle.target)}`,
        options,
        meta: {
          atk: this.power(this.battle.attacker), def: this.power(this.battle.target),
          targetIsLeader: this.isLeader(this.battle.target), targetCode: this.battle.target.code,
        },
      });
      if (!pick) return;
      const opt = options.find((x) => x.iid === pick.iid && x.use === pick.use);
      if (!opt) continue;
      const inst = p.hand.find((c) => c.iid === opt.iid);
      if (!inst) continue;
      if (opt.use === 'counter') {
        p.hand.splice(p.hand.indexOf(inst), 1);
        p.trash.push(inst);
        this.addMod(this.battle.target, this.card(inst).counter, 'battle');
        this.log(`${p.name} countered with ${this.card(inst).name} (+${this.card(inst).counter} to ${this.card(this.battle.target).name}).`);
      } else {
        const card = this.card(inst);
        const fx = this.E[inst.code];
        this.payDon(defPid, this.effectiveCost(defPid, card));
        p.hand.splice(p.hand.indexOf(inst), 1);
        this.log(`${p.name} activated the Counter Event ${card.name}!`);
        this.pushState();
        await fx.counter(this, { pid: defPid, self: inst, battle: this.battle });
        p.trash.push(inst);
        await this.fireEventActivated(defPid);
      }
      this.pushState();
    }
  }

  async actActivate(pid, iid) {
    const inst = this.findInst(pid, iid);
    if (!inst) throw new GameError('No such card.');
    const fx = this.E[inst.code];
    if (!fx || !fx.activateMain) throw new GameError('That card has no [Activate: Main] ability.');
    if (fx.activateOncePerTurn && inst.optUsed['activate'] === this.turn.n) throw new GameError('Already used this turn.');
    if (fx.activateDonx && inst.don < fx.activateDonx) throw new GameError(`Needs ${fx.activateDonx} DON!! attached.`);
    const ok = await fx.activateMain(this, { pid, self: inst });
    if (ok !== false && fx.activateOncePerTurn) inst.optUsed['activate'] = this.turn.n;
    this.pushState();
  }

  // ---------------------------------------------------------------- views
  serializeInst(inst, ownerPid) {
    return {
      iid: inst.iid, code: inst.code, rested: inst.rested, don: inst.don,
      power: this.ownerOf(inst) >= 0 ? this.power(inst) : (this.card(inst).power || 0),
      basePower: this.card(inst).power,
      kws: ['Blocker', 'Rush', 'Double Attack', 'Banish'].filter((k) => {
        try { return this.hasKw(inst, k); } catch { return false; }
      }),
      playedTurn: inst.playedTurn,
      cannotAttack: this.turn.n <= inst.cannotAttackUntilTurn,
      hasActivate: !!(this.E[inst.code] && this.E[inst.code].activateMain),
    };
  }

  view(pid) {
    const me = this.P(pid), op = this.P(this.oppOf(pid));
    const side = (p, mine) => ({
      name: p.name,
      leader: this.serializeInst(p.leader, p.pid),
      chars: p.chars.map((c) => this.serializeInst(c, p.pid)),
      stage: p.stage ? this.serializeInst(p.stage, p.pid) : null,
      hand: mine ? p.hand.map((c) => ({
        iid: c.iid, code: c.code, cost: this.effectiveCost(p.pid, this.card(c)),
        // counter-only Events can't be played in the main phase
        playable: ['Character', 'Stage'].includes(this.card(c).type) || (this.card(c).type === 'Event' && !!(this.E[c.code] && this.E[c.code].main)),
      })) : undefined,
      handCount: p.hand.length,
      deckCount: p.deck.length,
      trash: p.trash.map((c) => ({ iid: c.iid, code: c.code })),
      lifeCount: p.life.length,
      donActive: p.donActive, donRested: p.donRested, donDeck: p.donDeck,
    });
    return {
      you: side(me, true), opp: side(op, false),
      turn: { ...this.turn },
      yourTurn: this.turn.pid === pid,
      canAct: this.turn.pid === pid && this.turn.phase === 'main' && !this.busy && !this.pendingReq && !this.over,
      battle: this.battle ? {
        attackerIid: this.battle.attacker.iid, targetIid: this.battle.target.iid,
        attackerPower: this.power(this.battle.attacker), targetPower: this.power(this.battle.target),
      } : null,
      over: this.over,
    };
  }

  pushState() {
    if (!this.players) return;
    this.send(0, { t: 'state', view: this.view(0) });
    this.send(1, { t: 'state', view: this.view(1) });
  }
}

if (typeof module !== 'undefined') module.exports = { Game, validateDeck, GameError };
