// ============================================================================
// Card collection + daily booster packs (stored per account, locally).
// A real One Piece booster holds 12 cards; we mirror the feel:
//   7 Commons, 3 Uncommons, 1 Rare, and 1 "hit" slot (R/SR/L/SEC weighted).
// Players start by choosing an OP-01 Leader and receiving its full
// recommended deck, then get DAILY_PACKS free packs every day.
// ============================================================================
'use strict';

const DAILY_PACKS = 3;
const PACK_SIZE = 12;
const PACK_COST = 100;   // Berries per extra pack
const PITY_AT = 10;      // an SR-or-better is guaranteed within this many packs
const SETS = [
  { id: 'OP01', name: 'Romance Dawn' },
  { id: 'OP02', name: 'Paramount War' },
  { id: 'OP03', name: 'Pillars of Strength' },
  { id: 'OP04', name: 'Kingdoms of Intrigue' },
  { id: 'OP05', name: 'Awakening of the New Era' },
  { id: 'OP06', name: 'Wings of the Captain' },
  { id: 'OP07', name: '500 Years in the Future' },
  { id: 'OP08', name: 'Two Legends' },
  { id: 'EB01', name: 'Memorial Collection' },
  { id: 'EB02', name: 'Anime 25th Collection' },
  { id: 'EB03', name: 'Heroines Edition' },
];

function createCollection(DB) {
  const bySet = {};
  for (const c of DB) (bySet[c.set] = bySet[c.set] || []).push(c);

  const key = () => `optcg_coll_${localStorage.getItem('optcg_user') || 'guest'}`;
  function load() {
    try { return JSON.parse(localStorage.getItem(key())) || {}; } catch { return {}; }
  }
  function save(d) { localStorage.setItem(key(), JSON.stringify(d)); }
  function data() {
    const d = load();
    d.owned = d.owned || {};
    return d;
  }
  const today = () => new Date().toISOString().slice(0, 10);

  let onChange = null;
  function notify() { if (onChange) onChange(); }

  function grant(codes) {
    const d = data();
    for (const c of codes) d.owned[c] = (d.owned[c] || 0) + 1;
    save(d);
    notify();
  }

  const HIT = new Set(['SR', 'L', 'SEC']);
  function rollPack(setId, pity, rand = Math.random) {
    const pool = bySet[setId] || [];
    const byRarity = {};
    for (const c of pool) (byRarity[c.rarity] = byRarity[c.rarity] || []).push(c);
    const pick = (rarities) => {
      for (const r of rarities) {
        const p = byRarity[r];
        if (p && p.length) return p[Math.floor(rand() * p.length)].code;
      }
      return pool[Math.floor(rand() * pool.length)].code;
    };
    const cards = [];
    for (let i = 0; i < 7; i++) cards.push(pick(['C', 'UC']));
    for (let i = 0; i < 3; i++) cards.push(pick(['UC', 'C']));
    cards.push(pick(['R', 'UC']));
    const roll = rand();
    let hitSlot;
    if (pity >= PITY_AT - 1) hitSlot = pick(['SR', 'L', 'SEC', 'R']);      // pity: guaranteed hit
    else if (roll < 0.08) hitSlot = pick(['SEC', 'SR', 'L', 'R']);
    else if (roll < 0.23) hitSlot = pick(['L', 'SR', 'R']);
    else if (roll < 0.55) hitSlot = pick(['SR', 'R']);
    else hitSlot = pick(['R', 'UC']);
    cards.push(hitSlot);
    const gotHit = cards.some((code) => { const c = pool.find((x) => x.code === code); return c && HIT.has(c.rarity); });
    return { cards, gotHit };
  }

  return {
    SETS, DAILY_PACKS, PACK_COST, PITY_AT,
    setOnChange(fn) { onChange = fn; },
    exportData() { return data(); },
    importData(d) { if (d && typeof d === 'object') save(d); },
    berries() { return data().berries || 0; },
    addBerries(n) { const d = data(); d.berries = (d.berries || 0) + n; save(d); notify(); },
    pity() { return data().pity || 0; },
    owned(code) { return data().owned[code] || 0; },
    ownedMap() { return data().owned; },
    totalOwned() { return Object.values(data().owned).reduce((a, b) => a + b, 0); },
    starterChosen() { return !!data().starter; },
    chooseStarter(leaderCode, deckCards) {
      const d = data();
      if (d.starter) return false;
      d.starter = leaderCode;
      d.owned = d.owned || {};
      d.berries = (d.berries || 0) + 200; // welcome bonus
      for (const c of [leaderCode, ...deckCards]) d.owned[c] = (d.owned[c] || 0) + 1;
      save(d);
      notify();
      return true;
    },
    packsLeftToday() {
      const d = data();
      if (d.lastDaily !== today()) return DAILY_PACKS;
      return Math.max(0, DAILY_PACKS - (d.openedToday || 0));
    },
    openPack(setId, { paid = false } = {}) {
      const d = data();
      if (d.lastDaily !== today()) { d.lastDaily = today(); d.openedToday = 0; }
      if (paid) {
        if ((d.berries || 0) < PACK_COST) return { err: 'berries' };
        d.berries -= PACK_COST;
      } else {
        if ((d.openedToday || 0) >= DAILY_PACKS) return { err: 'daily' };
        d.openedToday = (d.openedToday || 0) + 1;
      }
      const { cards, gotHit } = rollPack(setId, d.pity || 0);
      d.pity = gotHit ? 0 : (d.pity || 0) + 1;
      d.owned = d.owned || {};
      const newOnes = [];
      const hits = [];
      for (const c of cards) {
        if (!d.owned[c]) newOnes.push(c);
        d.owned[c] = (d.owned[c] || 0) + 1;
        const def = DB.find((x) => x.code === c);
        if (def && HIT.has(def.rarity)) hits.push(c);
      }
      save(d);
      notify();
      return { cards, newOnes, hits };
    },
  };
}

if (typeof module !== 'undefined') module.exports = { createCollection, SETS, DAILY_PACKS, PACK_SIZE };
