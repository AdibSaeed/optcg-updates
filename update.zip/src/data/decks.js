// Recommended decks — one for every OP-01 Leader, all legal
// (50 cards, ≤4 copies, colors match the Leader).
'use strict';

function x(n, code) { return Array(n).fill(code); }

const SAMPLE_DECKS = [
  {
    name: 'Straw Hat Aggro (Red — Zoro)',
    leader: 'OP01-001',
    cards: [
      ...x(4, 'OP01-016'), ...x(4, 'OP01-006'), ...x(4, 'OP01-013'), ...x(4, 'OP01-024'),
      ...x(4, 'OP01-025'), ...x(4, 'OP01-017'), ...x(4, 'OP01-015'), ...x(4, 'OP01-014'),
      ...x(4, 'OP01-008'), ...x(4, 'OP01-022'), ...x(2, 'OP01-120'),
      ...x(4, 'OP01-029'), ...x(4, 'OP01-026'),
    ],
  },
  {
    name: 'Heart of the Board (Green/Red — Law)',
    leader: 'OP01-002',
    cards: [
      ...x(4, 'OP01-025'), ...x(4, 'OP01-016'), ...x(4, 'OP01-006'), ...x(4, 'OP01-013'),
      ...x(4, 'OP01-017'), ...x(4, 'OP01-047'), ...x(4, 'OP01-035'), ...x(4, 'OP01-048'),
      ...x(4, 'OP01-054'), ...x(4, 'OP01-121'), ...x(2, 'OP01-051'),
      ...x(4, 'OP01-029'), ...x(4, 'OP01-026'),
    ],
  },
  {
    name: 'Gear Second (Green/Red — Luffy)',
    leader: 'OP01-003',
    cards: [
      ...x(4, 'OP01-025'), ...x(4, 'OP01-024'), ...x(4, 'OP01-016'), ...x(4, 'OP01-013'),
      ...x(4, 'OP01-015'), ...x(4, 'OP01-014'), ...x(4, 'OP01-022'), ...x(4, 'OP01-035'),
      ...x(4, 'OP01-052'), ...x(4, 'OP01-121'), ...x(4, 'OP01-029'), ...x(4, 'OP01-026'),
      ...x(2, 'OP01-008'),
    ],
  },
  {
    name: 'Land of Wano (Green — Oden)',
    leader: 'OP01-031',
    cards: [
      ...x(4, 'OP01-041'), ...x(4, 'OP01-036'), ...x(4, 'OP01-048'), ...x(4, 'OP01-037'),
      ...x(4, 'OP01-038'), ...x(4, 'OP01-035'), ...x(4, 'OP01-034'), ...x(4, 'OP01-052'),
      ...x(4, 'OP01-046'), ...x(4, 'OP01-040'), ...x(4, 'OP01-121'),
      ...x(2, 'OP01-057'), ...x(4, 'OP01-055'),
    ],
  },
  {
    name: 'Seven Warlords (Blue — Doflamingo)',
    leader: 'OP01-060',
    cards: [
      ...x(4, 'OP01-077'), ...x(4, 'OP01-064'), ...x(4, 'OP01-073'), ...x(4, 'OP01-078'),
      ...x(4, 'OP01-074'), ...x(4, 'OP01-075'), ...x(4, 'OP01-068'), ...x(4, 'OP01-071'),
      ...x(2, 'OP01-070'), ...x(4, 'OP01-065'),
      ...x(4, 'OP01-086'), ...x(4, 'OP01-088'), ...x(4, 'OP01-089'),
    ],
  },
  {
    name: 'Animal Kingdom (Blue/Purple — Kaido)',
    leader: 'OP01-061',
    cards: [
      ...x(4, 'OP01-093'), ...x(4, 'OP01-105'), ...x(4, 'OP01-102'), ...x(4, 'OP01-113'),
      ...x(4, 'OP01-101'), ...x(4, 'OP01-109'), ...x(4, 'OP01-103'), ...x(4, 'OP01-095'),
      ...x(4, 'OP01-097'), ...x(2, 'OP01-096'), ...x(2, 'OP01-094'), ...x(2, 'OP01-110'),
      ...x(4, 'OP01-119'), ...x(4, 'OP01-115'),
    ],
  },
  {
    name: 'Baroque Works (Blue/Purple — Crocodile)',
    leader: 'OP01-062',
    cards: [
      ...x(4, 'OP01-083'), ...x(4, 'OP01-085'), ...x(4, 'OP01-084'), ...x(4, 'OP01-080'),
      ...x(4, 'OP01-079'), ...x(4, 'OP01-077'), ...x(4, 'OP01-073'), ...x(4, 'OP01-090'),
      ...x(4, 'OP01-087'), ...x(4, 'OP01-088'), ...x(4, 'OP01-089'),
      ...x(2, 'OP01-067'), ...x(4, 'OP01-086'),
    ],
  },
  {
    name: 'Ten DON!! Dominance (Purple — King)',
    leader: 'OP01-091',
    cards: [
      ...x(4, 'OP01-093'), ...x(4, 'OP01-101'), ...x(4, 'OP01-102'), ...x(4, 'OP01-105'),
      ...x(4, 'OP01-109'), ...x(4, 'OP01-111'), ...x(4, 'OP01-112'), ...x(4, 'OP01-113'),
      ...x(4, 'OP01-097'), ...x(4, 'OP01-119'), ...x(4, 'OP01-118'),
      ...x(2, 'OP01-096'), ...x(2, 'OP01-094'), ...x(2, 'OP01-107'),
    ],
  },
];

if (typeof module !== 'undefined') module.exports = SAMPLE_DECKS;
