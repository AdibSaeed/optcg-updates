// ============================================================================
// Renderer UI: home / deck builder / lobby / game board.
// The host also runs the Game engine in this process; the guest is a thin
// client that renders views and answers choice requests.
// ============================================================================
'use strict';

const DB = require('./data/cards.json');
const SAMPLE_DECKS = require('./data/decks.js');
const { Game, validateDeck } = require('./engine/engine.js');
const EFFECTS = require('./engine/registry.js'); // OP01 hand-scripted + auto-compiled sets
const net = require('./net.js');
const { createBot } = require('./bot.js');
const { createTutorial } = require('./tutorial.js');
const CONFIG = require('./config.js');
const { createCollection } = require('./collection.js');
const SND = require('./sound.js');
const updater = require('./updater.js');

const CARDS = {};
for (const c of DB) CARDS[c.code] = c;
const COLL = createCollection(DB);
const FLAGS = EFFECTS.__flags || {};
const UNLOCKED = new Set(CONFIG.UNLOCKED_SETS || ['OP01']);
const setLocked = (id) => !UNLOCKED.has(id);

// SERVER-AUTHORITATIVE collections: when logged in, every economy action is a
// server request and the local module only mirrors the result. Editing local
// files can no longer grant cards or Berries.
function svrBridge() {
  const u = loggedInUser(), t = localStorage.getItem('optcg_token');
  return (m) => accountRequest({ ...m, username: u, token: t }, 'coll');
}
async function pushColl() { /* no longer used — the server owns the data */ }
async function pullColl() {
  if (!loggedInUser() || !relayUrl() || !localStorage.getItem('optcg_token')) return;
  try {
    const r = await svrBridge()({ t: 'svrColl' });
    if (r.ok) COLL.attachServer(svrBridge(), r.data);
  } catch {}
}

// small themed icon for buttons/headers
const icon = (name, cls = '') => h('img', { class: `bicon ${cls}`, src: `assets/icons/${name}.svg`, draggable: 'false' });

// ------------------------------------------------------------------- state
let myName = localStorage.getItem('optcg_name') || 'Pirate';
let role = null;            // 'host' | 'guest'
let hostConn = null;        // net.host handle
let guestConn = null;       // net.join handle
let game = null;            // host only
let lastGuestInfo = null;   // {name, deck} for rematches
let myDeck = null;

let TUT = null;             // active tutorial director
let DRAG = null;            // current drag payload {type:'hand'|'don', iid?}
let ATKDRAG = null;         // Hearthstone-style attack drag {srcIid, x0, y0, x, y, active}
let FX_LOCK = false;        // true while a battle animation plays (defer re-renders)
let justDragged = 0;        // timestamp of last completed attack drag (suppresses click)
const PLAY_ANIMS = new Map(); // iid -> timestamp; entrance-animate renders within the window
let MYMAT = localStorage.getItem('optcg_mat2') || ''; // playmat file name ('' = first available)
let OPPMAT = null;          // opponent's mat {name, dataURL} — sent over the wire

// ---- playmats: real playmat images dropped into src/assets/playmats/
const fs = require('fs');
const path = require('path');
const PLAYMAT_DIR = path.join(__dirname, 'assets', 'playmats');
function matsList() {
  try { return fs.readdirSync(PLAYMAT_DIR).filter((f) => /\.(png|jpe?g|webp)$/i.test(f)).sort(); }
  catch { return []; }
}
function matPath(name) { return `assets/playmats/${encodeURIComponent(name)}`; }
/** My mat resolved to a CSS url — chosen file, else first bundled mat, else null. */
function myMatUrl() {
  const list = matsList();
  if (MYMAT && list.includes(MYMAT)) return matPath(MYMAT);
  return list.length ? matPath(list[0]) : null;
}
function myMatName() {
  const list = matsList();
  return MYMAT && list.includes(MYMAT) ? MYMAT : (list[0] || null);
}
/** Mat as a data URL so the opponent sees it without owning the file (≤12MB). */
function myMatData() {
  const name = myMatName();
  if (!name) return null;
  try {
    const buf = fs.readFileSync(path.join(PLAYMAT_DIR, name));
    if (buf.length > 12 * 1024 * 1024) return null;
    const mime = /\.png$/i.test(name) ? 'image/png' : /\.webp$/i.test(name) ? 'image/webp' : 'image/jpeg';
    return `data:${mime};base64,${buf.toString('base64')}`;
  } catch { return null; }
}
/** Opponent's mat url: local copy if we have the same file, else their sent data, else our default. */
function oppMatUrl() {
  if (OPPMAT && OPPMAT.name && matsList().includes(OPPMAT.name)) return matPath(OPPMAT.name);
  if (OPPMAT && OPPMAT.dataURL) return OPPMAT.dataURL;
  return myMatUrl();
}
let PEER_GONE = false;      // opponent left after the game ended (no rematch possible)
let OPP_DC = false;         // opponent disconnected mid-game (waiting for reconnect)
let LASTJOIN = null;        // guest: {raw, deck} for auto-reconnect
let RECON = null;           // guest reconnect loop state
let CUR_ROOM = null;        // active room code (for server-validated rewards)
let TIMER_END = null;       // when the visible countdown expires (local clock)
let V = null;               // latest view
let ASK = null;             // pending ask request
let SEL = new Set();        // current target/card selection
let WAITING = null;         // opponent-is-choosing banner
let ATTACKER = null;        // iid currently choosing an attack target
let LOGS = [];
let OVER = null;            // {winner, reason, iWon}

const $app = document.getElementById('app');
const $modal = document.getElementById('modal-root');
const $toast = document.getElementById('toast-root');

// ------------------------------------------------------------------ helpers
function h(tag, attrs = {}, ...children) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === 'class') el.className = v;
    else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
    else if (k === 'style') el.style.cssText = v;
    else el.setAttribute(k, v);
  }
  for (const c of children.flat()) {
    if (c == null) continue;
    el.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
  }
  return el;
}
function toast(msg, cls = '') {
  const t = h('div', { class: `toast ${cls}` }, msg);
  $toast.appendChild(t);
  setTimeout(() => t.remove(), 3200);
}
function closeMenu() { document.querySelectorAll('.cardmenu').forEach((m) => m.remove()); }
document.addEventListener('click', (e) => { if (!e.target.closest('.cardmenu') && !e.target.closest('.card')) closeMenu(); });

const HOLO_RARITIES = new Set(['R', 'SR', 'L', 'SEC']);

function cardEl(code, opts = {}) {
  const def = CARDS[code];
  const el = h('div', { class: `card ${opts.class || ''}`, style: opts.cw ? `--cw:${opts.cw}px` : '' });
  const img = h('img', { src: def.image, alt: def.name, draggable: 'false' });
  img.addEventListener('error', () => { if (img.src !== def.imageUrl) img.src = def.imageUrl; }, { once: true });
  el.appendChild(img);
  // every card tilts in 3D toward the pointer; rare cards additionally get
  // the holofoil refraction + glare (hover-only, like tilting a real foil)
  if (HOLO_RARITIES.has(def.rarity)) {
    el.classList.add('holo-card');
    el.appendChild(h('div', { class: 'holo' }));
  }
  el.addEventListener('mousemove', (e) => {
    const r = el.getBoundingClientRect();
    const px = (e.clientX - r.left) / r.width, py = (e.clientY - r.top) / r.height;
    el.style.setProperty('--mx', `${px * 100}%`);
    el.style.setProperty('--my', `${py * 100}%`);
    el.style.setProperty('--bgx', `${(1 - px) * 100}%`);
    el.style.setProperty('--bgy', `${(1 - py) * 100}%`);
    el.style.setProperty('--ry', `${(px - 0.5) * 14}deg`);
    el.style.setProperty('--rx', `${(0.5 - py) * 10}deg`);
  });
  el.addEventListener('mouseleave', () => {
    for (const v of ['--mx', '--my', '--bgx', '--bgy', '--rx', '--ry']) el.style.removeProperty(v);
  });
  if (opts.badges) for (const b of opts.badges) el.appendChild(b);
  el.addEventListener('mouseenter', () => scheduleBigPreview(el, code));
  el.addEventListener('mouseleave', hideBigPreview);
  if (opts.onclick) el.addEventListener('click', (e) => { e.stopPropagation(); opts.onclick(e); });
  if (opts.dragData) makeDraggable(el, opts.dragData);
  if (opts.dropTypes) makeDropTarget(el, opts.dropTypes, opts.onDrop);
  return el;
}
function makeDraggable(el, dragData) {
  el.setAttribute('draggable', 'true');
  el.addEventListener('dragstart', (e) => {
    DRAG = dragData;
    el.classList.add('dragging');
    if (e.dataTransfer) { e.dataTransfer.effectAllowed = 'move'; try { e.dataTransfer.setData('text/plain', 'x'); } catch {} }
  });
  el.addEventListener('dragend', () => {
    DRAG = null;
    el.classList.remove('dragging');
    document.querySelectorAll('.dropok').forEach((x) => x.classList.remove('dropok'));
  });
}
function makeDropTarget(el, types, onDrop) {
  el.addEventListener('dragover', (e) => {
    if (DRAG && types.includes(DRAG.type)) { e.preventDefault(); el.classList.add('dropok'); }
  });
  el.addEventListener('dragleave', () => el.classList.remove('dropok'));
  el.addEventListener('drop', (e) => {
    e.preventDefault();
    el.classList.remove('dropok');
    if (DRAG && types.includes(DRAG.type)) { const d = DRAG; DRAG = null; onDrop(d); }
  });
}
// Official-style card back. If the user drops a real scan into
// src/assets/cardback.(png|jpg|webp) it is used automatically instead.
const BACK_SRC = (() => {
  for (const ext of ['png', 'jpg', 'jpeg', 'webp']) {
    try { if (fs.existsSync(path.join(__dirname, 'assets', `cardback.${ext}`))) return `assets/cardback.${ext}`; } catch {}
  }
  return 'assets/cardback-builtin.svg';
})();
function cardBack(opts = {}) {
  return h('div', { class: `cardback ${opts.class || ''}`, style: opts.cw ? `--cw:${opts.cw}px` : '' },
    h('img', { src: BACK_SRC, draggable: 'false' }));
}
// Hearthstone-style hover preview: after a short hover, a large copy of the
// card pops up next to it (never under the pointer, never interactive).
const HOVER_DELAY_MS = 1000;
let hoverTimer = null;
function hideBigPreview() {
  clearTimeout(hoverTimer);
  hoverTimer = null;
  const bp = document.getElementById('bigpreview');
  if (bp) bp.remove();
}
function scheduleBigPreview(anchor, code) {
  clearTimeout(hoverTimer);
  hoverTimer = setTimeout(() => {
    if (DRAG || ATKDRAG || !document.body.contains(anchor)) return;
    showBigPreview(anchor, code);
  }, HOVER_DELAY_MS);
}
function showBigPreview(anchor, code) {
  hideBigPreview();
  const def = CARDS[code];
  if (!def) return;
  const bits = [`${def.type} · ${def.colors.join('/')}`];
  if (def.cost != null) bits.push(`Cost ${def.cost}`);
  if (def.power != null) bits.push(`Power ${def.power}`);
  if (def.counter) bits.push(`Counter +${def.counter}`);
  if (def.attribute) bits.push(def.attribute);
  const bp = h('div', { class: 'bigpreview', id: 'bigpreview' },
    h('img', { src: def.image }),
    h('div', { class: 'bp-head' }, h('b', {}, def.name), h('span', { class: 'dim' }, ` — ${bits.join(' · ')}`)),
    def.text ? h('div', { class: 'bp-text' }, def.text) : null,
  );
  document.body.appendChild(bp);
  const r = anchor.getBoundingClientRect();
  const bw = bp.offsetWidth, bh = bp.offsetHeight;
  let left = r.right + 16;
  if (left + bw > window.innerWidth - 8) left = r.left - bw - 16;
  if (left < 8) left = Math.min(window.innerWidth - bw - 8, Math.max(8, r.left + r.width / 2 - bw / 2));
  const top = Math.max(8, Math.min(window.innerHeight - bh - 8, r.top + r.height / 2 - bh / 2));
  bp.style.left = `${left}px`;
  bp.style.top = `${top}px`;
}
document.addEventListener('mousedown', hideBigPreview, true);
document.addEventListener('dragstart', hideBigPreview, true);

// ------------------------------------------------------------- deck storage
function savedDecks() { try { return JSON.parse(localStorage.getItem('optcg_decks') || '[]'); } catch { return []; } }
function storeDecks(d) { localStorage.setItem('optcg_decks', JSON.stringify(d)); }

function pickDeckModal(onPick) {
  const saved = savedDecks().map((d) => ({ ...d, saved: true }));
  const myStarter = SAMPLE_DECKS.filter((d) => d.leader === COLL.starterLeader() && !saved.some((s) => s.name === d.name));
  const all = [...saved, ...myStarter];
  const grid = h('div', { class: 'deckpickgrid' });
  for (const d of all) {
    const err = validateDeck(DB, d);
    grid.appendChild(h('div', {
      class: `deckpick ${err ? 'illegal' : ''}`,
      onclick: () => {
        if (err) { toast(`Deck not legal: ${err}`); return; }
        $modal.innerHTML = '';
        onPick({ leader: d.leader, cards: [...d.cards] });
      },
    },
      cardEl(d.leader, { cw: 168 }),
      h('div', { class: 'dp-name' }, d.name),
      err ? h('div', { class: 'dp-warn' }, '⚠ not legal') : null,
    ));
  }
  if (all.length === 0) {
    grid.appendChild(h('div', { class: 'dim', style: 'padding:30px;text-align:center' },
      'No decks yet — build one in the Deck Builder first.'));
  }
  $modal.innerHTML = '';
  $modal.appendChild(h('div', { class: 'modal-overlay' }, h('div', { class: 'modal' },
    h('div', { class: 'mtitle' }, 'Choose your deck'),
    grid,
    h('div', { class: 'mbtns' }, h('button', { onclick: () => { $modal.innerHTML = ''; } }, 'Cancel')),
  )));
}

// ---------------------------------------------------------------- accounts
function accountRequest(msg, replyType) {
  return new Promise((resolve, reject) => {
    const url = relayUrl();
    if (!url) return reject(new Error('Set the game server address first (bottom of the home screen).'));
    const WS = require('ws');
    const ws = new WS(url);
    const to = setTimeout(() => { try { ws.close(); } catch {} reject(new Error('Server did not respond.')); }, 10000);
    ws.on('open', () => ws.send(JSON.stringify(msg)));
    ws.on('message', (d) => {
      try {
        const m = JSON.parse(d.toString());
        if (m.t === replyType) { clearTimeout(to); ws.close(); resolve(m); }
      } catch {}
    });
    ws.on('error', (e) => { clearTimeout(to); reject(new Error('Could not reach the server: ' + e.message)); });
  });
}
function loggedInUser() { return localStorage.getItem('optcg_user') || null; }
function setLoggedIn(username) {
  if (username) { localStorage.setItem('optcg_user', username); myName = username; localStorage.setItem('optcg_name', username); }
  else { localStorage.removeItem('optcg_user'); localStorage.removeItem('optcg_token'); COLL.detachServer(); }
  showHome();
}

function accountModal() {
  let tab = loggedInUser() ? 'account' : 'login';
  const wrap = h('div', { class: 'modal', style: 'min-width:420px' });
  function fld(placeholder, type = 'text') { return h('input', { placeholder, type, style: 'width:100%' }); }
  function render() {
    wrap.innerHTML = '';
    const user = loggedInUser();
    if (tab === 'account' && user) {
      wrap.append(
        h('div', { class: 'mtitle' }, `Logged in as ${user}`),
        h('div', { class: 'dim', style: 'font-size:13px' }, 'Your username is your player name in games.'),
        h('div', { class: 'mbtns' },
          h('button', { onclick: () => { setLoggedIn(null); $modal.innerHTML = ''; toast('Logged out.', 'info'); } }, 'Log out'),
          h('button', { onclick: () => { $modal.innerHTML = ''; } }, 'Close')),
      );
      return;
    }
    const tabs = h('div', { class: 'mbtns' },
      h('button', { class: tab === 'login' ? 'primary' : '', onclick: () => { tab = 'login'; render(); } }, 'Log in'),
      h('button', { class: tab === 'register' ? 'primary' : '', onclick: () => { tab = 'register'; render(); } }, 'Create account'),
      h('button', { class: tab === 'forgot' ? 'primary' : '', onclick: () => { tab = 'forgot'; render(); } }, 'Forgot?'),
    );
    const err = h('div', { class: 'validmsg bad' });
    const busy = (b, btn) => { btn.disabled = b; btn.textContent = b ? '…' : btn.dataset.label; };
    if (tab === 'login') {
      const u = fld('Username'), p = fld('Password', 'password');
      const go = h('button', { class: 'primary', 'data-label': 'Log in' }, 'Log in');
      go.addEventListener('click', async () => {
        busy(true, go);
        try {
          const r = await accountRequest({ t: 'login', username: u.value, password: p.value }, 'auth');
          if (r.ok) { localStorage.setItem('optcg_token', r.token || ''); await pullColl(); setLoggedIn(r.username); $modal.innerHTML = ''; toast(`Ahoy, ${r.username}!`, 'info'); }
          else err.textContent = r.why;
        } catch (e) { err.textContent = e.message; }
        busy(false, go);
      });
      wrap.append(h('div', { class: 'mtitle' }, 'Account'), tabs, u, p, err, h('div', { class: 'mbtns' }, go, h('button', { onclick: () => { $modal.innerHTML = ''; } }, 'Cancel')));
    } else if (tab === 'register') {
      const u = fld('Username (3–20 characters)'), e2 = fld('Email — used only to recover your account'), p = fld('Password (6+ characters)', 'password');
      const go = h('button', { class: 'primary', 'data-label': 'Create account' }, 'Create account');
      go.addEventListener('click', async () => {
        busy(true, go);
        try {
          const r = await accountRequest({ t: 'register', username: u.value, email: e2.value, password: p.value }, 'auth');
          if (r.ok) { localStorage.setItem('optcg_token', r.token || ''); await pullColl(); setLoggedIn(r.username); $modal.innerHTML = ''; toast(`Welcome aboard, ${r.username}!`, 'info'); }
          else err.textContent = r.why;
        } catch (e3) { err.textContent = e3.message; }
        busy(false, go);
      });
      wrap.append(h('div', { class: 'mtitle' }, 'Create account'), tabs, u, e2, p, err, h('div', { class: 'mbtns' }, go, h('button', { onclick: () => { $modal.innerHTML = ''; } }, 'Cancel')));
    } else {
      const e2 = fld('Your account email');
      const code = fld('6-digit code from the email');
      const np = fld('New password (6+ characters)', 'password');
      const send1 = h('button', { 'data-label': 'Email me a code' }, 'Email me a code');
      const go = h('button', { class: 'primary', 'data-label': 'Reset password' }, 'Reset password');
      send1.addEventListener('click', async () => {
        busy(true, send1);
        try {
          const r = await accountRequest({ t: 'recoverRequest', email: e2.value }, 'recover');
          if (r.ok) { err.className = 'validmsg good'; err.textContent = 'Sent! The email contains your username and a reset code.'; }
          else err.textContent = r.why;
        } catch (e3) { err.textContent = e3.message; }
        busy(false, send1);
      });
      go.addEventListener('click', async () => {
        busy(true, go);
        try {
          const r = await accountRequest({ t: 'recoverConfirm', email: e2.value, code: code.value, newPassword: np.value }, 'recover');
          if (r.ok) { setLoggedIn(r.username); $modal.innerHTML = ''; toast(`Password changed — welcome back, ${r.username}!`, 'info'); }
          else err.textContent = r.why;
        } catch (e3) { err.textContent = e3.message; }
        busy(false, go);
      });
      wrap.append(h('div', { class: 'mtitle' }, 'Recover account'), tabs,
        h('div', { class: 'dim', style: 'font-size:12.5px' }, 'You\'ll get an email with your username and a reset code (requires the server owner to have email configured).'),
        e2, h('div', { class: 'mbtns' }, send1), code, np, err,
        h('div', { class: 'mbtns' }, go, h('button', { onclick: () => { $modal.innerHTML = ''; } }, 'Cancel')));
    }
  }
  render();
  $modal.innerHTML = '';
  $modal.appendChild(h('div', { class: 'modal-overlay' }, wrap));
}

// ================================================================== screens
function showHome() {
  role = null; V = null; ASK = null; OVER = null; LOGS = []; TUT = null; OPPMAT = null; PEER_GONE = false; OPP_DC = false;
  if (RECON) { RECON.stopped = true; RECON = null; }
  if (hostConn) { hostConn.close(); hostConn = null; }
  if (guestConn) { guestConn.close(); guestConn = null; }
  game = null;
  $modal.innerHTML = '';
  document.getElementById('tut-root').innerHTML = '';

  const user = loggedInUser();
  if (user) myName = user;
  const nameIn = h('input', { value: myName, placeholder: 'Your name', maxlength: '20', ...(user ? { disabled: '' } : {}) });
  nameIn.addEventListener('input', () => { myName = nameIn.value || 'Pirate'; localStorage.setItem('optcg_name', myName); });
  const addrIn = h('input', { placeholder: 'Room code (e.g. KQ4Z) — or an IP for LAN play', value: localStorage.getItem('optcg_lastaddr') || '' });

  $app.innerHTML = '';
  $app.appendChild(h('div', { class: 'home' },
    h('div', { class: 'logo' },
      icon('jolly', 'authlogo'),
      h('h1', {}, 'ONE PIECE CARD GAME'),
      h('div', { class: 'sub' }, 'OP-01 · ROMANCE DAWN · ONLINE'),
    ),
    h('div', { class: 'row', style: 'align-items:center;gap:10px' },
      h('span', { class: 'dim' }, 'Name'), nameIn,
      h('div', { class: 'pill berrypill' }, icon('berry'), h('b', {}, String(COLL.berries())), ' Berries'),
      h('button', { style: 'padding:6px 10px', onclick: (e) => { const m = SND.toggle(); e.currentTarget.textContent = m ? 'Sound: off' : 'Sound: on'; } }, SND.muted ? 'Sound: off' : 'Sound: on'),
    ),
    h('div', { class: 'menu' },
      h('button', { class: 'primary', onclick: () => pickDeckModal((d) => startHostingOnline(d)) }, icon('helm'), 'Host Online — get a room code'),
      h('div', { class: 'row' },
        addrIn,
        h('button', {
          onclick: () => {
            const raw = addrIn.value.trim();
            if (!raw) { toast('Enter a room code (or an IP for LAN play) first.'); return; }
            localStorage.setItem('optcg_lastaddr', raw);
            pickDeckModal((d) => startJoining(raw, d));
          },
        }, icon('ship'), 'Join'),
      ),
      h('button', { onclick: () => pickDeckModal((d) => startBotMatch(d)) }, icon('bot'), 'Play vs Bot'),
      h('button', { onclick: startTutorial }, icon('hat'), 'Tutorial — learn the game'),
      h('button', { onclick: showPacksScreen }, icon('chest'), `Open Packs${COLL.packsLeftToday() > 0 ? ` — ${COLL.packsLeftToday()} free!` : ''}`),
      h('button', { onclick: showCollection }, icon('compass'), 'Collection'),
      h('button', { onclick: showBuilder }, icon('cards'), 'Deck Builder'),
      h('button', { onclick: pickMatModal }, icon('compass'), 'Playmat'),
      h('button', { onclick: () => (relayUrl() ? accountModal() : toast('Set SERVER_URL in src/config.js to enable accounts.', 'info')) },
        icon('jolly'), user ? user : 'Account'),
      h('button', { onclick: () => pickDeckModal((d) => startHosting(d)), style: 'font-size:13px;opacity:.8' }, icon('anchor'), 'Host on LAN / VPN (no server)'),
    ),
  ));
}

function pickMatModal() {
  const list = matsList();
  const setMat = (name) => {
    MYMAT = name;
    localStorage.setItem('optcg_mat2', name);
    $modal.innerHTML = '';
    toast(`Playmat: ${name.replace(/\.[^.]+$/, '')}`, 'info');
    showHome();
  };
  const grid = h('div', { class: 'matgrid' });
  for (const name of list) {
    grid.appendChild(h('div', {
      class: `matthumb ${myMatName() === name ? 'selected' : ''}`,
      onclick: () => setMat(name),
    },
      h('img', { src: matPath(name), draggable: 'false' }),
      h('div', { class: 'matname' }, name.replace(/\.[^.]+$/, '')),
    ));
  }
  $modal.innerHTML = '';
  $modal.appendChild(h('div', { class: 'modal-overlay', onclick: (e) => { if (e.target.classList.contains('modal-overlay')) $modal.innerHTML = ''; } },
    h('div', { class: 'modal' },
      h('div', { class: 'mtitle' }, 'Choose your playmat'),
      list.length ? grid : h('div', { class: 'dim', style: 'padding:20px;text-align:center;max-width:520px' },
        'No playmats found. Drop playmat images (.png / .jpg / .webp) into the "src/assets/playmats" folder inside the game folder — search online for "one piece playmat" to find the official arts — then reopen this menu.'),
      h('div', { class: 'mbtns' },
        h('button', { onclick: () => { $modal.innerHTML = ''; } }, 'Close')),
    )));
}

// ------------------------------------------------------------------ hosting
function handleGuestMsg(msg) {
  if (msg.t === 'hello') {
    // reconnection into a running game: resync instead of starting over
    if (game && !game.over) {
      OPP_DC = false;
      game.setTimersPaused(false);
      hostConn.sendToGuest({ t: 'mat', matName: myMatName(), matData: myMatData() });
      hostConn.sendToGuest({ t: 'logsync', lines: game.logLines.slice(-120) });
      game.pushState();
      if (game.pendingReq && game.pendingReq.pid === 1) hostConn.sendToGuest({ t: 'ask', req: game.pendingReq.req });
      toast('Your friend reconnected!', 'info');
      renderGame();
      return;
    }
    const err = validateDeck(DB, msg.deck);
    if (err) { hostConn.sendToGuest({ t: 'reject', why: err }); return; }
    // anti-cheat: when they're logged in, confirm with the server that they
    // actually own every card in this deck
    if (msg.username && relayUrl()) {
      accountRequest({ t: 'verifyDeck', username: msg.username, leader: msg.deck.leader, deck: msg.deck.cards }, 'deckCheck')
        .then((r) => {
          if (!r.ok) {
            hostConn.sendToGuest({ t: 'reject', why: `deck ownership check failed (${r.why || 'cards not owned'})` });
            toast(`Rejected ${msg.name}'s deck — ${r.why || 'they do not own those cards.'}`, 'info');
            return;
          }
          finishHello();
        })
        .catch(() => finishHello()); // server unreachable: let friends play
      const finishHello = () => {
        lastGuestInfo = { name: (msg.name || 'Guest').slice(0, 20), deck: msg.deck };
        OPPMAT = msg.matName ? { name: msg.matName, dataURL: msg.matData || null } : null;
        hostConn.sendToGuest({ t: 'mat', matName: myMatName(), matData: myMatData() });
        launchGame();
      };
      return;
    }
    lastGuestInfo = { name: (msg.name || 'Guest').slice(0, 20), deck: msg.deck };
    OPPMAT = msg.matName ? { name: msg.matName, dataURL: msg.matData || null } : null;
    hostConn.sendToGuest({ t: 'mat', matName: myMatName(), matData: myMatData() });
    launchGame();
  } else if (game && ['action', 'choice', 'concede'].includes(msg.t)) {
    game.onMessage(1, msg);
  } else if (msg.t === 'wantRematch') {
    toast(`${lastGuestInfo ? lastGuestInfo.name : 'Opponent'} wants a rematch!`, 'info');
  }
}
function onGuestGone(rewait) {
  if (game && !game.over) { OPP_DC = true; game.setTimersPaused(true); toast('Your friend disconnected — the game is paused while they reconnect.', 'info'); renderGame(); }
  else if (game && game.over) { PEER_GONE = true; renderGame(); }
  else rewait();
}

function startHosting(deck) {
  myDeck = deck;
  role = 'host';
  try {
    hostConn = net.host(net.DEFAULT_PORT, {
      onGuestMessage: handleGuestMsg,
      onGuestLeft: () => onGuestGone(renderWaitingForGuest),
      onError: (e) => toast(`Server error: ${e.message}`),
    });
  } catch (e) {
    toast(`Could not start server: ${e.message}`);
    return;
  }
  renderWaitingForGuest();
}

// ---- online play through the relay server (room codes, no IPs)
function relayUrl() {
  let u = (CONFIG.SERVER_URL || localStorage.getItem('optcg_relay') || '').trim();
  if (!u) return null;
  if (!/^wss?:\/\//i.test(u)) {
    u = (/^(localhost|127\.|192\.168\.|10\.)/.test(u) ? 'ws://' : 'wss://') + u.replace(/^https?:\/\//i, '');
  }
  return u;
}
function startHostingOnline(deck) {
  const url = relayUrl();
  if (!url) { toast('Set the game server address first (bottom of the home screen).'); return; }
  myDeck = deck;
  role = 'host';
  let roomCode = null;
  hostConn = net.hostViaRelay(url, {
    onCode: (code) => { roomCode = code; CUR_ROOM = code; renderWaitingOnline(code); },
    onGuestMessage: handleGuestMsg,
    onGuestConnected: () => {},
    onGuestLeft: () => onGuestGone(() => renderWaitingOnline(roomCode)),
    onError: (e) => toast(`Online error: ${e.message}`),
    onClose: () => { if (role === 'host' && !game) { toast('Server connection closed.'); showHome(); } },
  }, loggedInUser());
  renderWaitingOnline(null);
}
function renderWaitingOnline(code) {
  $app.innerHTML = '';
  $app.appendChild(h('div', { class: 'waitscreen' },
    h('div', { class: 'pulse' }, icon('helm', 'bigicon')),
    h('h2', {}, code ? 'Room ready — waiting for your friend…' : 'Contacting server…'),
    code ? h('div', { class: 'roomcode' }, code) : null,
    code ? h('div', { class: 'ipbox dim' }, 'Tell your friend to click Join and enter this room code. That\'s it — no IP addresses needed.') : null,
    h('button', { onclick: showHome }, 'Cancel'),
  ));
}
function renderWaitingForGuest() {
  const ips = net.localIPs();
  $app.innerHTML = '';
  $app.appendChild(h('div', { class: 'waitscreen' },
    h('div', { class: 'pulse' }, icon('anchor', 'bigicon')),
    h('h2', {}, `Hosting on port ${net.DEFAULT_PORT} — waiting for your friend…`),
    h('div', { class: 'ipbox' },
      h('div', {}, 'Tell them to Join using one of these addresses:'),
      ...ips.map((ip) => h('div', {}, h('b', { style: 'color:var(--gold);user-select:text' }, ip))),
      h('div', { class: 'dim', style: 'margin-top:8px;font-size:13px' },
        'Over the internet use your Tailscale/VPN IP (100.x…), or forward TCP port 7457 on your router and share your public IP.'),
    ),
    h('button', { onclick: showHome }, 'Cancel'),
  ));
}
function launchGame() {
  OVER = null; LOGS = []; ASK = null; WAITING = null; ATTACKER = null; SEL.clear(); PEER_GONE = false; OPP_DC = false;
  game = new Game(DB, EFFECTS, [myDeck, lastGuestInfo.deck], {
    send: (pid, msg) => { if (pid === 0) handleGameMsg(msg); else hostConn.sendToGuest(msg); },
    names: [myName, lastGuestInfo.name],
    timers: { turn: 90, ask: 45 },
  });
  renderGame();
  game.start().catch((e) => { console.error(e); toast(`Engine error: ${e.message}`); });
}

// ------------------------------------------------------------------ joining
function startJoining(raw, deck) {
  myDeck = deck;
  role = 'guest';
  LASTJOIN = { raw, deck };
  const isRoomCode = /^[a-z0-9]{4,6}$/i.test(raw) && !raw.includes('.');
  CUR_ROOM = isRoomCode ? raw.toUpperCase() : null;
  $app.innerHTML = '';
  $app.appendChild(h('div', { class: 'waitscreen' },
    h('div', { class: 'pulse' }, icon('ship', 'bigicon')),
    h('h2', {}, isRoomCode ? `Joining room ${raw.toUpperCase()}…` : `Connecting to ${raw}…`),
    h('button', { onclick: showHome }, 'Cancel'),
  ));
  const sendHello = () => guestConn.send({ t: 'hello', name: myName, username: loggedInUser() || null, deck: myDeck, matName: myMatName(), matData: myMatData() });
  const onMessage = (msg) => {
    if (msg.t === 'reject') { toast(`Host rejected your deck: ${msg.why}`); showHome(); return; }
    handleGameMsg(msg);
  };
  const onClose = (why) => {
    if (role !== 'guest') return;
    if (OVER) { PEER_GONE = true; renderGame(); }       // stay on the result screen, but say so
    else if (V) showReconnectScreen();                   // mid-game: try to get back in
    else { toast(why || 'Connection closed.'); showHome(); }
  };
  if (isRoomCode) {
    const url = relayUrl();
    if (!url) { toast('Set the game server address first (bottom of the home screen).'); showHome(); return; }
    guestConn = net.joinViaRelay(url, raw.toUpperCase(), {
      onOpen: sendHello, onMessage, onClose,
      onError: (e) => toast(`Could not join: ${e.message}`),
    }, loggedInUser());
  } else {
    const [addr, portS] = raw.split(':');
    const port = parseInt(portS) || net.DEFAULT_PORT;
    guestConn = net.join(addr, port, {
      onOpen: sendHello, onMessage, onClose,
      onError: () => toast('Could not connect — check the address and that your friend is hosting.'),
    });
  }
}

// ------------------------------------------------------------- bot match
function pickDifficulty(cb) {
  const mk = (level, label, desc) => h('button', {
    style: 'display:block;width:100%;text-align:left', class: level === 'normal' ? 'primary' : '',
    onclick: () => { $modal.innerHTML = ''; cb(level); },
  }, h('b', {}, label), h('div', { class: 'dim', style: 'font-size:12px;font-weight:400' }, desc));
  $modal.innerHTML = '';
  $modal.appendChild(h('div', { class: 'modal-overlay' }, h('div', { class: 'modal', style: 'min-width:380px' },
    h('div', { class: 'mtitle' }, 'Bot difficulty'),
    mk('easy', 'Easy', 'Plays casually, never counters or blocks — good for learning.'),
    mk('normal', 'Normal', 'Trades into your characters, counters when it matters.'),
    mk('hard', 'Hard', 'Spreads DON!!, blocks and counters aggressively.'),
    h('div', { class: 'mbtns' }, h('button', { onclick: () => { $modal.innerHTML = ''; } }, 'Cancel')),
  )));
}
function startBotMatch(deck, opts = {}) {
  if (!opts.level && !opts.botDelay) { pickDifficulty((level) => startBotMatch(deck, { ...opts, level })); return; }
  myDeck = deck;
  role = 'host';
  OVER = null; LOGS = []; ASK = null; WAITING = null; ATTACKER = null; SEL.clear(); TUT = null;
  OPPMAT = null;
  const pool = SAMPLE_DECKS.filter((d) => d.leader !== deck.leader);
  const botDeck = pool[Math.floor(Math.random() * pool.length)] || SAMPLE_DECKS[0];
  let botHandler = null;
  game = new Game(DB, EFFECTS, [
    { leader: deck.leader, cards: [...deck.cards] },
    { leader: botDeck.leader, cards: [...botDeck.cards] },
  ], {
    send: (pid, msg) => (pid === 0 ? handleGameMsg(msg) : botHandler && botHandler(msg)),
    names: [myName, `Bot (${botDeck.name.split(' (')[0]})`],
  });
  botHandler = createBot((m) => game.onMessage(1, m), { delay: opts.botDelay ?? 500, level: opts.level || 'normal' });
  renderGame();
  game.start().catch((e) => { console.error(e); toast(`Engine error: ${e.message}`); });
}

// -------------------------------------------------------------- tutorial
function startTutorial() {
  role = 'host';
  OVER = null; LOGS = []; ASK = null; WAITING = null; ATTACKER = null; SEL.clear();
  TUT = createTutorial({
    Game, DB, EFFECTS,
    playerName: myName,
    toPlayer: (msg) => handleGameMsg(msg),
    showStep: renderTutBar,
    hint: (m) => toast(m, 'info'),
    onFinish: () => { document.getElementById('tut-root').innerHTML = ''; toast('Free play — beat the bot!', 'info'); },
  });
  game = TUT.start();
  renderGame();
}

function renderTutBar(step) {
  const root = document.getElementById('tut-root');
  root.innerHTML = '';
  const bits = [
    h('div', { class: 'tuthead' }, icon('hat'), ` Tutorial — step ${step.idx}/${step.total}`),
    h('div', { class: 'tuttext' }, step.text),
  ];
  const btns = h('div', { class: 'tutbtns' });
  if (step.next) btns.appendChild(h('button', { class: 'primary', onclick: () => TUT && TUT.next() }, 'Next ▸'));
  if (step.finish) btns.appendChild(h('button', { class: 'primary', onclick: () => TUT && TUT.finishFreePlay() }, icon('swords'), 'Keep playing'));
  btns.appendChild(h('button', { onclick: () => { if (confirm('Leave the tutorial?')) showHome(); } }, 'Exit tutorial'));
  bits.push(btns);
  root.appendChild(h('div', { class: 'tutbar' }, ...bits));
}

// ------------------------------------------------------------- reconnect
function showReconnectScreen() {
  if (RECON) return;
  RECON = { tries: 0, stopped: false };
  const status = h('div', { class: 'dim' }, 'Connection lost — reconnecting…');
  $modal.innerHTML = '';
  $app.innerHTML = '';
  $app.appendChild(h('div', { class: 'waitscreen' },
    h('div', { class: 'pulse' }, icon('helm', 'bigicon')),
    h('h2', {}, 'Reconnecting to the game'),
    status,
    h('button', {
      onclick: () => { RECON.stopped = true; RECON = null; showHome(); },
    }, 'Give up'),
  ));
  const attempt = () => {
    if (!RECON || RECON.stopped) return;
    RECON.tries++;
    if (RECON.tries > 30) { status.textContent = 'Could not reconnect — the host may have closed the game.'; return; }
    status.textContent = `Reconnecting… attempt ${RECON.tries}`;
    try { if (guestConn) guestConn.close(); } catch {}
    const raw = LASTJOIN.raw;
    const isRoomCode = /^[a-z0-9]{4,6}$/i.test(raw) && !raw.includes('.');
    const sendHello = () => guestConn.send({ t: 'hello', name: myName, deck: LASTJOIN.deck, matName: myMatName(), matData: myMatData() });
    const onMessage = (msg) => {
      if (RECON) { RECON.stopped = true; RECON = null; }   // any game traffic = we're back
      handleGameMsg(msg);
    };
    const retry = () => { if (RECON && !RECON.stopped) setTimeout(attempt, 4000); };
    if (isRoomCode) {
      guestConn = net.joinViaRelay(relayUrl(), raw.toUpperCase(), {
        onOpen: sendHello, onMessage,
        onClose: () => { if (RECON) retry(); else if (V && !OVER) showReconnectScreen(); },
        onError: () => {},
      }, loggedInUser());
    } else {
      const [addr, portS] = raw.split(':');
      guestConn = net.join(addr, parseInt(portS) || net.DEFAULT_PORT, {
        onOpen: sendHello, onMessage,
        onClose: () => { if (RECON) retry(); else if (V && !OVER) showReconnectScreen(); },
        onError: () => {},
      });
    }
  };
  attempt();
}

// -------------------------------------------------------------- game events
function handleGameMsg(msg) {
  switch (msg.t) {
    case 'state':
      V = msg.view;
      TIMER_END = msg.view.timerMs != null ? Date.now() + msg.view.timerMs : (ASK && ASK.timeLimitMs ? TIMER_END : null);
      if (!ASK) SEL.clear();
      if (OVER && !msg.view.over) { OVER = null; LOGS = []; } // rematch started
      if (!FX_LOCK) renderGame();
      break;
    case 'ask':
      ASK = msg.req; SEL.clear(); WAITING = null;
      if (msg.req.timeLimitMs) TIMER_END = Date.now() + msg.req.timeLimitMs;
      if (!FX_LOCK) renderGame();
      break;
    case 'waiting': WAITING = msg.for; if (!FX_LOCK) renderGame(); break;
    case 'fx':
      if (msg.kind === 'clash') { SND.play('clash'); runClashFx(msg); }
      else if (msg.kind === 'toTrash') { SND.play('ko'); runTrashFx(msg); }
      else if (msg.kind === 'play') { SND.play('play'); PLAY_ANIMS.set(msg.iid, Date.now()); }
      else if (msg.kind === 'draw') { SND.play('draw'); runDrawFx(msg); }
      else if (msg.kind === 'damage') { SND.play('damage'); runDamageFx(msg); }
      break;
    case 'mat': OPPMAT = msg.matName ? { name: msg.matName, dataURL: msg.matData || null } : null; if (V && !FX_LOCK) renderGame(); break;
    case 'logsync': LOGS = msg.lines || []; renderLog(); break;
    case 'log': LOGS.push(msg.msg); renderLog(); break;
    case 'nope': toast(msg.why); break;
    case 'gameover': {
      const iWon = (role === 'host' && msg.winner === 0) || (role === 'guest' && msg.winner === 1);
      OVER = { ...msg, iWon };
      SND.play(iWon ? 'win' : 'lose');
      // Berries for playing (not tutorials, not instant concedes)
      if (!TUT && (msg.turns || 0) >= 6) {
        const isBot = role === 'host' && !hostConn;
        if (loggedInUser() && relayUrl()) {
          // server-validated rewards — the server checks the room really happened
          const claim = isBot ? { t: 'svrClaimBot', won: iWon } : { t: 'svrClaimMatch', room: CUR_ROOM, won: iWon };
          svrBridge()(claim).then((r) => {
            if (r.ok && r.earned) {
              COLL.attachServer(svrBridge(), r.data);
              SND.play('coin');
              toast(`+${r.earned} Berries!`, 'info');
            } else if (r.why) toast(r.why, 'info');
          }).catch(() => {});
        } else {
          const amount = isBot ? (iWon ? 50 : 25) : (iWon ? 100 : 50);
          COLL.addBerries(amount);
          setTimeout(() => { SND.play('coin'); toast(`+${amount} Berries!`, 'info'); }, 900);
        }
      }
      ASK = null; renderGame(); break;
    }
  }
}
function sendGame(m) {
  if (TUT && !TUT.isFinished()) {
    const r = TUT.filterPlayerMsg(m);
    if (r !== true) { toast(r, 'info'); return; }
  }
  if (role === 'host') game.onMessage(0, m);
  else if (guestConn) guestConn.send(m);
}
function answer(value) {
  if (!ASK) return;
  const m = { t: 'choice', id: ASK.id, value };
  // Tutorial gating must happen while the prompt is still alive, so a blocked
  // choice keeps its prompt on screen.
  if (TUT && !TUT.isFinished()) {
    const r = TUT.filterPlayerMsg(m);
    if (r !== true) { toast(r, 'info'); return; }
  }
  ASK = null; SEL.clear();
  $modal.innerHTML = '';
  if (role === 'host') game.onMessage(0, m);
  else if (guestConn) guestConn.send(m);
  renderGame();
}

// =============================================================== game render
function renderGame() {
  if (!V) return;
  closeMenu();
  $app.innerHTML = '';

  const sidebar = h('div', { class: 'sidebar' },
    h('div', { class: 'sidetitle' }, 'BATTLE LOG'),
    h('div', { class: 'logpanel', id: 'logpanel' }),
  );

  const board = h('div', { class: 'board' },
    renderSide(V.opp, false),
    renderCenter(),
    renderPrompt(),
    renderSide(V.you, true),
    renderHand(),
  );

  $app.appendChild(h('div', { class: 'gamewrap' }, sidebar, board));
  renderLog();
  renderAskModal();
  if (OVER) renderGameOver();
}

function renderLog() {
  const lp = document.getElementById('logpanel');
  if (!lp) return;
  lp.innerHTML = '';
  const recent = LOGS.slice(-80);
  recent.forEach((m, i) => lp.appendChild(h('div', { class: i >= recent.length - 4 ? 'recent' : '' }, m)));
  lp.scrollTop = lp.scrollHeight;
}

function instBadges(inst) {
  const badges = [];
  if (inst.power != null) {
    const base = (inst.basePower || 0);
    const cls = inst.power > base ? 'buffed' : inst.power < base ? 'debuffed' : '';
    badges.push(h('div', { class: `badge power ${cls}` }, String(inst.power)));
  }
  if (inst.don > 0) badges.push(h('div', { class: 'badge don' }, `⬤${inst.don}`));
  if (inst.kws && inst.kws.length) badges.push(h('div', { class: 'badge kw' }, inst.kws.map((k) => k === 'Double Attack' ? 'DA' : k === 'CanAttackActive' ? 'AA' : k).join('·')));
  return badges;
}

function isAskTarget(iid) {
  return ASK && ASK.kind === 'targets' && ASK.options.some((o) => o.iid === iid);
}

function boardCard(inst, mine) {
  const isLeader = (mine ? V.you : V.opp).leader.iid === inst.iid;
  const classes = [];
  if (inst.rested) classes.push('rested');
  if (isAskTarget(inst.iid)) classes.push(SEL.has(inst.iid) ? 'selected' : 'selectable');
  if (ATTACKER === inst.iid) classes.push('attacker-glow');
  if (V.battle && V.battle.attackerIid === inst.iid) classes.push('attacker-glow');
  // the card under attack gets an unmistakable pulsing red glow
  if (V.battle && V.battle.targetIid === inst.iid) classes.push('defending');
  const canAttackNow = mine && V.canAct && !ASK && !inst.rested && !inst.cannotAttack
    && (isLeader || inst.playedTurn !== V.turn.n || inst.kws.includes('Rush'));
  if (canAttackNow) classes.push('can-attack');
  const el = cardEl(inst.code, {
    class: classes.join(' '),
    badges: instBadges(inst),
    onclick: (e) => onBoardCardClick(inst, mine, e),
    // dragging a DON!! card onto your own Leader/Character gives it to them
    dropTypes: mine ? ['don'] : undefined,
    onDrop: mine ? () => { SND.play('don'); sendGame({ t: 'action', a: 'attachDon', iid: inst.iid }); } : undefined,
  });
  el.dataset.iid = inst.iid;
  // several state pushes happen in quick succession when a card is played;
  // keep animating on every re-render inside the window so it isn't cut short
  const playedAt = PLAY_ANIMS.get(inst.iid);
  if (playedAt !== undefined) {
    if (Date.now() - playedAt < 700) el.classList.add('just-played');
    else PLAY_ANIMS.delete(inst.iid);
  }
  // Hearthstone-style: press and drag your attacker onto a target
  if (canAttackNow) {
    el.addEventListener('mousedown', (e) => {
      if (e.button !== 0) return;
      e.preventDefault();
      const r = el.getBoundingClientRect();
      ATKDRAG = { srcIid: inst.iid, x0: r.left + r.width / 2, y0: r.top + r.height / 2, x: e.clientX, y: e.clientY, active: false };
    });
  }
  return el;
}

// ------------------------------------------------------ attack drag + arrow
function markAttackTargets(on) {
  document.querySelectorAll('.oppside .card').forEach((el) => el.classList.remove('atk-target'));
  if (!on || !V) return;
  const ids = new Set([V.opp.leader.iid, ...V.opp.chars.filter((c) => c.rested).map((c) => c.iid)]);
  document.querySelectorAll('.oppside .card').forEach((el) => {
    if (ids.has(parseInt(el.dataset.iid))) el.classList.add('atk-target');
  });
}
function removeArrow() {
  const svg = document.getElementById('atk-arrow');
  if (svg) svg.remove();
}
function drawArrow() {
  const NS = 'http://www.w3.org/2000/svg';
  let svg = document.getElementById('atk-arrow');
  if (!svg) {
    svg = document.createElementNS(NS, 'svg');
    svg.id = 'atk-arrow';
    const path = document.createElementNS(NS, 'path');
    path.id = 'atk-path';
    const head = document.createElementNS(NS, 'polygon');
    head.id = 'atk-head';
    head.setAttribute('points', '0,-11 22,0 0,11');
    svg.appendChild(path);
    svg.appendChild(head);
    document.body.appendChild(svg);
  }
  const { x0, y0, x, y } = ATKDRAG;
  const lift = Math.min(120, Math.hypot(x - x0, y - y0) * 0.25);
  const mx = (x0 + x) / 2, my = (y0 + y) / 2 - lift;
  document.getElementById('atk-path').setAttribute('d', `M${x0},${y0} Q${mx},${my} ${x},${y}`);
  const ang = (Math.atan2(y - my, x - mx) * 180) / Math.PI;
  document.getElementById('atk-head').setAttribute('transform', `translate(${x},${y}) rotate(${ang})`);
}
document.addEventListener('mousemove', (e) => {
  if (!ATKDRAG) return;
  ATKDRAG.x = e.clientX; ATKDRAG.y = e.clientY;
  if (!ATKDRAG.active && Math.hypot(e.clientX - ATKDRAG.x0, e.clientY - ATKDRAG.y0) > 14) {
    ATKDRAG.active = true;
    closeMenu();
    markAttackTargets(true);
  }
  if (ATKDRAG.active) drawArrow();
});
document.addEventListener('mouseup', (e) => {
  if (!ATKDRAG) return;
  const d = ATKDRAG;
  ATKDRAG = null;
  removeArrow();
  markAttackTargets(false);
  if (!d.active) return; // it was just a click — the click handler opens the menu
  justDragged = Date.now();
  const t = e.target.closest && e.target.closest('.oppside .card');
  if (t && t.dataset.iid && V) {
    const tiid = parseInt(t.dataset.iid);
    sendGame({ t: 'action', a: 'attack', iid: d.srcIid, targetIid: V.opp.leader.iid === tiid ? 'leader' : tiid });
  }
});
window.addEventListener('blur', () => { ATKDRAG = null; removeArrow(); markAttackTargets(false); });

// -------------------------------------------------------- battle clash FX
function runClashFx(fx) {
  const a = document.querySelector(`.card[data-iid="${fx.attackerIid}"]`);
  const t = document.querySelector(`.card[data-iid="${fx.targetIid}"]`);
  if (!a || !t) return;
  FX_LOCK = true;
  const ar = a.getBoundingClientRect(), tr = t.getBoundingClientRect();
  const dx = (tr.left + tr.width / 2) - (ar.left + ar.width / 2);
  const dy = (tr.top + tr.height / 2) - (ar.top + ar.height / 2);
  const abase = a.classList.contains('rested') ? ' rotate(90deg) scale(.86)' : '';
  const tbase = t.classList.contains('rested') ? ' rotate(90deg) scale(.86)' : '';
  a.style.zIndex = '40';
  a.animate([
    { transform: `translate(0,0)${abase}` },
    { transform: `translate(${dx * 0.12}px,${dy * 0.12}px)${abase} `, offset: 0.25 },
    { transform: `translate(${dx * 0.88}px,${dy * 0.88}px)${abase}`, offset: 0.5 },
    { transform: `translate(0,0)${abase}` },
  ], { duration: 560, easing: 'cubic-bezier(.5,0,.3,1)' });
  setTimeout(() => {
    t.animate([
      { transform: `translate(0,0)${tbase}` },
      { transform: `translate(-8px,3px)${tbase}` },
      { transform: `translate(8px,-3px)${tbase}` },
      { transform: `translate(-5px,1px)${tbase}` },
      { transform: `translate(0,0)${tbase}` },
    ], { duration: 340, easing: 'ease-out' });
    const fl = h('div', { class: `impact ${fx.hit ? 'hit' : 'miss'}` });
    t.appendChild(fl);
    setTimeout(() => fl.remove(), 450);
  }, 270);
  setTimeout(() => { FX_LOCK = false; renderGame(); }, 720);
}

function myPid() { return role === 'guest' ? 1 : 0; }

/** Fly a face-down card between two on-screen elements. */
function flyCard(fromEl, toEl, { w = 64, dur = 480, spin = 160 } = {}) {
  if (!fromEl || !toEl) return;
  const fr = fromEl.getBoundingClientRect(), tr = toEl.getBoundingClientRect();
  const clone = cardBack({ cw: w });
  clone.style.cssText += `position:fixed;left:${fr.left + fr.width / 2 - w / 2}px;top:${fr.top + fr.height / 2 - (w * 1.4) / 2}px;z-index:96;pointer-events:none;`;
  document.body.appendChild(clone);
  const dx = (tr.left + tr.width / 2) - (fr.left + fr.width / 2);
  const dy = (tr.top + tr.height / 2) - (fr.top + fr.height / 2);
  clone.animate([
    { transform: 'translate(0,0) rotate(0deg) scale(1)', opacity: 1 },
    { transform: `translate(${dx}px,${dy}px) rotate(${spin}deg) scale(.55)`, opacity: .15 },
  ], { duration: dur, easing: 'cubic-bezier(.3,.1,.55,1)' }).onfinish = () => clone.remove();
}
function runDrawFx(fx) {
  const side = fx.pid === myPid() ? '.myside' : '.oppside';
  const from = document.querySelector(`${side} .deckpill`);
  const to = fx.pid === myPid() ? document.querySelector('.handrow') : document.querySelector(`${side} .opphandrow`);
  for (let i = 0; i < (fx.n || 1); i++) setTimeout(() => flyCard(from, to), i * 120);
}
function runDamageFx(fx) {
  const side = fx.pid === myPid() ? '.myside' : '.oppside';
  const from = document.querySelector(`${side} .lifepill`);
  const to = fx.banish
    ? document.querySelector(`${side} .trashpill`)
    : (fx.pid === myPid() ? document.querySelector('.handrow') : document.querySelector(`${side} .opphandrow`));
  flyCard(from, to, { w: 72, spin: fx.banish ? 300 : 120 });
  // the hit leader flashes red
  const lead = document.querySelector(`${side} .leaderzone .card`);
  if (lead) {
    const fl = h('div', { class: 'impact hit' });
    lead.appendChild(fl);
    setTimeout(() => fl.remove(), 450);
  }
}

// Card flies off the board into its owner's trash pile, shrinking and spinning.
function runTrashFx(fx) {
  const el = document.querySelector(`.card[data-iid="${fx.iid}"]`);
  if (!el) return;
  const r = el.getBoundingClientRect();
  const sideSel = fx.pid === myPid() ? '.myside' : '.oppside';
  const pill = document.querySelector(`${sideSel} .trashpill`);
  const pr = pill ? pill.getBoundingClientRect()
    : { left: window.innerWidth - 120, top: fx.pid === myPid() ? window.innerHeight - 60 : 30, width: 0, height: 0 };
  const clone = el.cloneNode(true);
  clone.classList.remove('rested', 'can-attack', 'selectable', 'atk-target', 'playable', 'attacker-glow');
  clone.style.cssText = `position:fixed;left:${r.left}px;top:${r.top}px;width:${r.width}px;height:${r.height}px;margin:0;z-index:95;pointer-events:none;`;
  document.body.appendChild(clone);
  el.style.visibility = 'hidden';
  const dx = (pr.left + pr.width / 2) - (r.left + r.width / 2);
  const dy = (pr.top + pr.height / 2) - (r.top + r.height / 2);
  setTimeout(() => {
    const anim = clone.animate([
      { transform: 'translate(0,0) scale(1) rotate(0deg)', opacity: 1 },
      { transform: `translate(${dx * 0.25}px,${dy * 0.25 - 40}px) scale(.9) rotate(60deg)`, opacity: 1, offset: 0.35 },
      { transform: `translate(${dx}px,${dy}px) scale(.1) rotate(320deg)`, opacity: .2 },
    ], { duration: 640, easing: 'cubic-bezier(.45,0,.75,.6)' });
    anim.onfinish = () => clone.remove();
  }, fx.delay || 60);
}

function donCardEl(rested, draggable) {
  const el = h('div', { class: `doncard ${rested ? 'rested' : ''} ${draggable ? 'grab' : ''}` },
    h('div', { class: 'donface' }, 'DON!!'));
  if (draggable) makeDraggable(el, { type: 'don' });
  el.title = 'DON!! — drag onto your Leader or a Character for +1000 power on your turn';
  return el;
}

function donRow(side, mine) {
  const row = h('div', { class: 'donrow' });
  const canDrag = mine && V.canAct && !ASK;
  for (let i = 0; i < side.donActive; i++) row.appendChild(donCardEl(false, canDrag));
  for (let i = 0; i < side.donRested; i++) row.appendChild(donCardEl(true, false));
  if (side.donDeck > 0) row.appendChild(h('div', { class: 'dondeck' }, `+${side.donDeck}`));
  if (side.donActive + side.donRested === 0 && side.donDeck === 0) row.appendChild(h('span', { class: 'dim', style: 'font-size:11px' }, 'no DON!!'));
  return row;
}

function onBoardCardClick(inst, mine, e) {
  if (Date.now() - justDragged < 350) return; // an attack drag just ended — not a click
  closeMenu();
  // answering a target-selection ask
  if (ASK && ASK.kind === 'targets' && isAskTarget(inst.iid)) {
    if (SEL.has(inst.iid)) SEL.delete(inst.iid); else SEL.add(inst.iid);
    if (SEL.size >= ASK.max) { answer([...SEL]); return; }
    renderGame();
    return;
  }
  if (ASK) return;
  // choosing an attack target
  if (ATTACKER != null && !mine) {
    const t = ATTACKER; ATTACKER = null;
    sendGame({ t: 'action', a: 'attack', iid: t, targetIid: V.opp.leader.iid === inst.iid ? 'leader' : inst.iid });
    renderGame();
    return;
  }
  if (!mine || !V.canAct) return;
  // my card: action menu
  const menu = h('div', { class: 'cardmenu', style: `left:${Math.min(e.clientX, window.innerWidth - 180)}px;top:${Math.min(e.clientY, window.innerHeight - 180)}px` });
  if (!inst.rested) {
    menu.appendChild(h('button', {
      onclick: () => { closeMenu(); ATTACKER = inst.iid; toast('Choose an attack target (their Leader or a rested Character).', 'info'); renderGame(); },
    }, 'Attack'));
  }
  if (V.you.donActive > 0) {
    menu.appendChild(h('button', { onclick: () => { closeMenu(); sendGame({ t: 'action', a: 'attachDon', iid: inst.iid }); } }, 'Give 1 DON!!'));
  }
  if (inst.hasActivate) {
    menu.appendChild(h('button', { onclick: () => { closeMenu(); sendGame({ t: 'action', a: 'activate', iid: inst.iid }); } }, 'Activate ability'));
  }
  menu.appendChild(h('button', { onclick: closeMenu }, 'Cancel'));
  document.body.appendChild(menu);
}

function trashModal(side) {
  const cards = side.trash;
  $modal.innerHTML = '';
  $modal.appendChild(h('div', { class: 'modal-overlay', onclick: (e) => { if (e.target.classList.contains('modal-overlay')) $modal.innerHTML = ''; } },
    h('div', { class: 'modal' },
      h('div', { class: 'mtitle' }, `${side.name}'s Trash (${cards.length})`),
      h('div', { class: 'cardgrid' }, cards.length ? cards.map((c) => cardEl(c.code, { cw: 110 })) : [h('div', { class: 'dim' }, 'Empty')]),
      h('div', { class: 'mbtns' }, h('button', { onclick: () => { $modal.innerHTML = ''; } }, 'Close')),
    )));
}

function renderSide(side, mine) {
  const info = h('div', { class: 'zoneinfo' },
    h('div', { class: 'pill lifepill' }, h('span', { class: 'heart' }, '\u25CF'), h('b', {}, String(side.lifeCount)), ' Life'),
    h('div', { class: 'pill deckpill' }, h('b', {}, String(side.deckCount)), ' Deck'),
    h('div', { class: 'pill click trashpill', onclick: () => trashModal(side) }, h('b', {}, String(side.trash.length)), ' Trash'),
    mine ? null : h('div', { class: 'pill' }, h('b', {}, String(side.handCount)), ' Hand'),
    h('div', { class: 'pill' }, h('b', {}, side.name)),
  );
  const chars = h('div', { class: 'charzone' },
    ...side.chars.map((c) => boardCard(c, mine)),
    ...Array(Math.max(0, 5 - side.chars.length)).fill(0).map(() => h('div', { class: 'slot' })),
  );
  const stageEl = side.stage
    ? cardEl(side.stage.code, { cw: 84, class: 'stagecard' })
    : h('div', { class: 'slot', style: '--cw:84px' });
  if (side.stage) stageEl.dataset.iid = side.stage.iid;
  const field = h('div', { class: `fieldrow ${mine ? 'myfield' : ''}` },
    h('div', { class: 'leaderzone' }, boardCard(side.leader, mine), stageEl),
    chars,
  );
  // playmat: each player's chosen real playmat art under their board
  const matUrl = mine ? myMatUrl() : oppMatUrl();
  if (matUrl) {
    field.style.backgroundImage =
      `linear-gradient(rgba(11,16,30,.45), rgba(11,16,30,.55)), url("${matUrl}")`;
  }
  if (mine) {
    // dropping a hand card anywhere on your board plays it
    makeDropTarget(field, ['hand'], (d) => sendGame({ t: 'action', a: 'playCard', iid: d.iid }));
  }
  const mid = mine
    ? h('div', { class: 'spacer' })
    : h('div', { class: 'opphandrow' }, ...Array(side.handCount).fill(0).map(() => cardBack()));
  const bar = h('div', { class: 'side-row' }, donRow(side, mine), mid, info);
  return h('div', { class: mine ? 'myside' : 'oppside' }, mine ? [field, bar] : [bar, field]);
}

function renderCenter() {
  const mine = V.yourTurn;
  const phaseName = { refresh: 'Refresh', draw: 'Draw', don: 'DON!!', main: 'Main Phase', end: 'End', setup: 'Setup' }[V.turn.phase] || V.turn.phase;
  const bits = [
    h('div', { class: `turnbanner ${mine ? 'mine' : ''}` },
      V.turn.phase === 'setup' ? 'Setting up…' : `Turn ${V.turn.n} — ${mine ? 'YOUR TURN' : `${V.opp.name}'s turn`} · ${phaseName}`),
  ];
  bits.push(h('div', { class: 'timerchip', id: 'timerchip' }));
  if (V.battle) {
    bits.push(h('div', { class: 'battlebanner' }, `${V.battle.attackerPower} vs ${V.battle.targetPower}`));
  }
  if (WAITING && !OPP_DC) bits.push(h('div', { class: 'dim' }, `Waiting for ${WAITING}…`));
  if (OPP_DC) {
    bits.push(h('div', { class: 'battlebanner' }, 'Friend disconnected — game paused while they reconnect'));
  }
  const btns = h('div', { class: 'actionbtns' });
  if (V.canAct && !ASK) {
    btns.appendChild(h('button', { class: 'primary', onclick: () => sendGame({ t: 'action', a: 'endTurn' }) }, 'End Turn'));
  }
  if (ATTACKER != null) {
    btns.appendChild(h('button', { onclick: () => { ATTACKER = null; renderGame(); } }, 'Cancel attack'));
  }
  if (OPP_DC && role === 'host' && game && !game.over) {
    btns.appendChild(h('button', {
      class: 'danger',
      onclick: () => { if (confirm('End the game? Your friend has not reconnected.')) { OPP_DC = false; game.gameOver(0, 'opponent left'); } },
    }, 'End game'));
  }
  if (!OVER) {
    btns.appendChild(h('button', { class: 'danger', onclick: () => { if (confirm('Concede the game?')) sendGame({ t: 'concede' }); } }, 'Concede'));
  }
  return h('div', { class: 'centerbar' }, ...bits, h('div', { class: 'spacer' }), btns);
}

function renderHand() {
  const row = h('div', { class: 'handrow' });
  for (const c of V.you.hand || []) {
    const def = CARDS[c.code];
    const badges = [h('div', { class: 'badge cost' }, String(c.cost))];
    if (def.counter) badges.push(h('div', { class: 'badge power' }, `+${def.counter}`));
    const canPlay = V.canAct && !ASK && c.cost <= V.you.donActive && c.playable !== false && def.type !== 'Leader';
    row.appendChild(cardEl(c.code, {
      cw: 122,
      class: canPlay ? 'playable' : '',
      badges,
      dragData: canPlay ? { type: 'hand', iid: c.iid } : undefined,
      onclick: () => {
        if (V.canAct && !ASK && !canPlay && def.type !== 'Leader') {
          if (c.playable === false) toast(`${def.name} is a [Counter] Event — you use it while defending, not in your main phase.`, 'info');
          else toast(`${def.name} costs ${c.cost} — you have ${V.you.donActive} active DON!!.`, 'info');
        }
      },
    }));
  }
  return row;
}

// ---------------------------------------------------------------- prompt bar
function renderPrompt() {
  if (!ASK) {
    if (WAITING) {
      return h('div', { class: 'promptbar' }, h('div', { class: 'ptitle dim' }, `${WAITING} is choosing…`));
    }
    return h('div', { class: 'promptbar hidden' });
  }
  const bar = h('div', { class: 'promptbar' });
  bar.appendChild(h('div', { class: 'ptitle' }, ASK.title || 'Choose'));
  switch (ASK.kind) {
    case 'yesno':
      bar.appendChild(h('button', { class: 'primary', onclick: () => answer(true) }, 'Yes'));
      bar.appendChild(h('button', { onclick: () => answer(false) }, 'No'));
      break;
    case 'targets': {
      bar.appendChild(h('span', { class: 'dim' }, `— click highlighted cards (${SEL.size}/${ASK.max})`));
      if (SEL.size >= ASK.min) {
        bar.appendChild(h('button', { class: 'primary', onclick: () => answer([...SEL]) },
          SEL.size === 0 ? 'Skip' : `Confirm (${SEL.size})`));
      }
      break;
    }
    case 'counter': {
      for (const o of ASK.options) {
        const def = CARDS[o.code];
        bar.appendChild(h('button', {
          onclick: () => answer({ iid: o.iid, use: o.use }),
        }, `${def.name} ${o.label}`));
      }
      bar.appendChild(h('button', { class: 'primary', onclick: () => answer(null) }, 'Pass'));
      break;
    }
    case 'number': {
      for (let i = ASK.min; i <= ASK.max; i++) {
        bar.appendChild(h('button', { class: i === ASK.max ? 'primary' : '', onclick: () => answer(i) }, String(i)));
      }
      break;
    }
    default:
      bar.appendChild(h('span', { class: 'dim' }, '(see window)'));
  }
  return bar;
}

// -------------------------------------------------------------- ask modals
function renderAskModal() {
  $modal.innerHTML = '';
  if (!ASK) return;
  const mk = (children) => {
    $modal.appendChild(h('div', { class: 'modal-overlay' }, h('div', { class: 'modal' }, ...children)));
  };

  if (ASK.kind === 'cards') {
    const grid = h('div', { class: 'cardgrid' });
    const okBtn = h('button', { class: 'primary' }, 'OK');
    const refresh = () => {
      okBtn.textContent = SEL.size === 0 ? (ASK.min === 0 ? 'Skip' : 'OK') : `OK (${SEL.size})`;
      okBtn.disabled = SEL.size < ASK.min;
      grid.querySelectorAll('.card').forEach((el) => {
        el.classList.toggle('selected', SEL.has(parseInt(el.dataset.iid)));
      });
    };
    for (const c of ASK.cards) {
      const el = cardEl(c.code, {
        cw: 130,
        onclick: () => {
          if (SEL.has(c.iid)) SEL.delete(c.iid);
          else { if (SEL.size >= ASK.max) return; SEL.add(c.iid); }
          refresh();
        },
      });
      el.dataset.iid = c.iid;
      grid.appendChild(el);
    }
    okBtn.addEventListener('click', () => answer([...SEL]));
    mk([h('div', { class: 'mtitle' }, ASK.title || 'Choose cards'), grid, h('div', { class: 'mbtns' }, okBtn)]);
    refresh();
    return;
  }

  if (ASK.kind === 'trigger') {
    mk([
      h('div', { class: 'mtitle' }, ASK.title),
      h('div', { class: 'cardgrid' }, cardEl(ASK.card.code, { cw: 220 })),
      h('div', { class: 'mbtns' },
        h('button', { class: 'primary', onclick: () => answer(true) }, 'Activate Trigger'),
        h('button', { onclick: () => answer(false) }, 'Add to hand'),
      ),
    ]);
    return;
  }

  if (ASK.kind === 'order') {
    const pool = [...ASK.cards];
    const ordered = [];
    const poolGrid = h('div', { class: 'cardgrid' });
    const orderGrid = h('div', { class: 'cardgrid' });
    const okBtn = h('button', { class: 'primary', disabled: 'true' }, 'OK');
    const refresh = () => {
      poolGrid.innerHTML = ''; orderGrid.innerHTML = '';
      for (const c of pool) poolGrid.appendChild(cardEl(c.code, { cw: 110, onclick: () => { ordered.push(c); pool.splice(pool.indexOf(c), 1); refresh(); } }));
      ordered.forEach((c, i) => {
        const el = cardEl(c.code, { cw: 90 });
        el.appendChild(h('div', { class: 'badge cost' }, String(i + 1)));
        orderGrid.appendChild(el);
      });
      okBtn.disabled = pool.length > 0;
    };
    okBtn.addEventListener('click', () => answer(ordered.map((c) => c.iid)));
    mk([
      h('div', { class: 'mtitle' }, ASK.title),
      h('div', { class: 'dim', style: 'text-align:center' }, 'Click cards in the order to place them (1 = placed first / nearest the top of the pile)'),
      poolGrid,
      h('div', { class: 'col' }, h('h3', {}, 'Chosen order'), orderGrid),
      h('div', { class: 'mbtns' },
        h('button', { onclick: () => { pool.push(...ordered.splice(0)); refresh(); } }, 'Reset'), okBtn),
    ]);
    refresh();
    return;
  }

  if (ASK.kind === 'arrange') {
    const pool = [...ASK.cards];
    const top = [], bottom = [];
    let dest = 'top';
    const poolGrid = h('div', { class: 'cardgrid' });
    const topGrid = h('div', { class: 'cardgrid' });
    const botGrid = h('div', { class: 'cardgrid' });
    const okBtn = h('button', { class: 'primary', disabled: 'true' }, 'OK');
    const topBtn = h('button', { class: 'primary', onclick: () => { dest = 'top'; refresh(); } }, 'Placing: TOP');
    const botBtn = h('button', { onclick: () => { dest = 'bottom'; refresh(); } }, 'Placing: BOTTOM');
    const refresh = () => {
      topBtn.className = dest === 'top' ? 'primary' : '';
      botBtn.className = dest === 'bottom' ? 'primary' : '';
      poolGrid.innerHTML = ''; topGrid.innerHTML = ''; botGrid.innerHTML = '';
      for (const c of pool) poolGrid.appendChild(cardEl(c.code, { cw: 100, onclick: () => { (dest === 'top' ? top : bottom).push(c); pool.splice(pool.indexOf(c), 1); refresh(); } }));
      top.forEach((c, i) => { const el = cardEl(c.code, { cw: 80 }); el.appendChild(h('div', { class: 'badge cost' }, String(i + 1))); topGrid.appendChild(el); });
      bottom.forEach((c, i) => { const el = cardEl(c.code, { cw: 80 }); el.appendChild(h('div', { class: 'badge cost' }, String(i + 1))); botGrid.appendChild(el); });
      okBtn.disabled = pool.length > 0;
    };
    okBtn.addEventListener('click', () => answer({ top: top.map((c) => c.iid), bottom: bottom.map((c) => c.iid) }));
    mk([
      h('div', { class: 'mtitle' }, ASK.title),
      h('div', { class: 'mbtns' }, topBtn, botBtn),
      poolGrid,
      h('div', { class: 'cols' },
        h('div', { class: 'col', style: 'flex:1' }, h('h3', {}, 'TOP of deck (1 = topmost)'), topGrid),
        h('div', { class: 'col', style: 'flex:1' }, h('h3', {}, 'BOTTOM of deck'), botGrid),
      ),
      h('div', { class: 'mbtns' },
        h('button', { onclick: () => { pool.push(...top.splice(0), ...bottom.splice(0)); refresh(); } }, 'Reset'), okBtn),
    ]);
    refresh();
    return;
  }

  if (ASK.kind === 'pickIndex') {
    const ex = new Set(ASK.exclude || []);
    const grid = h('div', { class: 'cardgrid' });
    for (let i = 0; i < ASK.count; i++) {
      const b = cardBack({ cw: 100 });
      if (ex.has(i)) { b.style.opacity = '.25'; }
      else { b.style.cursor = 'pointer'; b.addEventListener('click', () => answer(i)); }
      grid.appendChild(b);
    }
    mk([h('div', { class: 'mtitle' }, ASK.title), grid]);
    return;
  }

  if (ASK.kind === 'info') {
    mk([
      h('div', { class: 'mtitle' }, ASK.title),
      h('div', { class: 'cardgrid' }, (ASK.cards || []).map((c) => cardEl(c.code, { cw: 160 }))),
      h('div', { class: 'mbtns' }, h('button', { class: 'primary', onclick: () => answer(true) }, 'OK')),
    ]);
    return;
  }
}

// -------------------------------------------------------------- game over
function renderGameOver() {
  let rematchBtn;
  if (TUT || (role === 'host' && !hostConn)) {
    // bot match / tutorial free play
    const deck = myDeck;
    rematchBtn = h('button', {
      class: 'primary',
      onclick: () => (deck ? startBotMatch(deck) : startTutorial()),
    }, icon('swords'), 'Play Again');
  } else if (role === 'host') {
    rematchBtn = h('button', { class: 'primary', onclick: () => { if (hostConn && hostConn.hasGuest() && lastGuestInfo) launchGame(); else toast('Your friend is no longer connected.'); } }, icon('swords'), 'Play Again');
  } else {
    rematchBtn = h('button', { class: 'primary', onclick: () => { sendGame({ t: 'wantRematch' }); toast('Rematch request sent — waiting for host…', 'info'); } }, icon('swords'), 'Ask for Rematch');
  }
  const isNetGame = !TUT && (role === 'guest' || !!hostConn);
  const wrap = h('div', { class: 'gameover-wrap' },
    h('div', { class: `go-big ${OVER.iWon ? 'win' : 'lose'}` }, OVER.iWon ? 'VICTORY' : 'DEFEAT'),
    h('div', { class: 'go-box' },
      h('div', { class: 'go-reason' }, OVER.reason),
      PEER_GONE && isNetGame ? h('div', { class: 'go-reason', style: 'color:var(--red)' }, 'Your friend has left — no rematch this time.') : null,
      h('div', { class: 'go-btns' },
        PEER_GONE && isNetGame ? null : rematchBtn,
        h('button', { onclick: showHome }, 'Exit to Menu')),
    ),
  );
  $modal.innerHTML = '';
  $modal.appendChild(h('div', { class: 'modal-overlay' }, wrap));
}

// ============================================================= deck builder
// ---------------------------------------------------------- card inspector
function inspectCard(code) {
  const def = CARDS[code];
  const holo = HOLO_RARITIES.has(def.rarity);
  let rx = -4, ry = 8, dragging = false, lx = 0, ly = 0;
  const card = h('div', { class: `inspect-card ${holo ? 'holo-card' : ''}` },
    h('img', { src: def.image, draggable: 'false' }),
    holo ? h('div', { class: 'holo' }) : null);
  const apply = () => {
    card.style.transform = `perspective(1500px) rotateX(${rx}deg) rotateY(${ry}deg)`;
    if (holo) {
      card.style.setProperty('--bgx', `${50 - ry * 2.4}%`);
      card.style.setProperty('--bgy', `${50 + rx * 2.4}%`);
      card.style.setProperty('--mx', `${50 + ry * 2}%`);
      card.style.setProperty('--my', `${50 - rx * 2}%`);
    }
  };
  apply();
  card.addEventListener('mousedown', (e) => { e.preventDefault(); dragging = true; lx = e.clientX; ly = e.clientY; });
  const move = (e) => {
    if (!dragging) return;
    ry = Math.max(-55, Math.min(55, ry + (e.clientX - lx) * 0.35));
    rx = Math.max(-45, Math.min(45, rx - (e.clientY - ly) * 0.35));
    lx = e.clientX; ly = e.clientY;
    apply();
  };
  const up = () => { dragging = false; };
  document.addEventListener('mousemove', move);
  document.addEventListener('mouseup', up);
  const close = () => {
    document.removeEventListener('mousemove', move);
    document.removeEventListener('mouseup', up);
    $modal.innerHTML = '';
  };
  card.addEventListener('dblclick', () => { rx = 0; ry = 0; apply(); });
  SND.play('flip');
  $modal.innerHTML = '';
  $modal.appendChild(h('div', { class: 'modal-overlay', onclick: (e) => { if (e.target.classList.contains('modal-overlay')) close(); } },
    h('div', { class: 'inspector' },
      card,
      h('div', { class: 'dim', style: 'text-align:center;font-size:13px' }, 'Drag to rotate · double-click to reset'),
      h('div', { class: 'mbtns' }, h('button', { onclick: close }, 'Close')),
    )));
}

// ------------------------------------------------------ collection & packs
// --------------------------------------------------------------- packs page
function showPacksScreen() {
  let setIdx = 0;

  function render() {
    $app.innerHTML = '';
    const left = COLL.packsLeftToday();
    const setInfo = COLL.SETS[setIdx];
    const locked = setLocked(setInfo.id);
    const packSrc = `assets/packs/${setInfo.id}.webp`;

    const packImg = h('img', { class: 'bigpack-img', src: packSrc, draggable: 'false' });
    const packWrap = h('div', { class: `bigpack ${locked ? 'locked' : ''}` }, packImg);
    if (locked) packWrap.appendChild(h('div', { class: 'cs-title cs-onpack' }, 'COMING SOON'));

    const arrows = (d) => h('button', {
      class: 'packarrow',
      onclick: () => { setIdx = (setIdx + d + COLL.SETS.length) % COLL.SETS.length; render(); },
    }, d < 0 ? '\u2039' : '\u203A');

    const status = locked
      ? h('div', { class: 'dim' }, 'This set will be released in a future update.')
      : h('div', { class: 'dim' }, left > 0
        ? `Click the pack to open it — ${left} free pack${left === 1 ? '' : 's'} left today`
        : `No free packs left today — click to buy one for ${COLL.PACK_COST} Berries`);

    if (!locked) {
      packWrap.classList.add('openable');
      packWrap.addEventListener('click', () => {
        const paid = COLL.packsLeftToday() === 0;
        if (paid && COLL.berries() < COLL.PACK_COST) { toast(`Not enough Berries — a pack costs ${COLL.PACK_COST}.`, 'info'); return; }
        if (paid && !confirm(`No free packs left — buy this pack for ${COLL.PACK_COST} Berries?`)) return;
        startRip(setInfo.id, paid);
      }, { once: true });
    }

    $app.appendChild(h('div', { class: 'topbar' },
      h('button', { onclick: showHome }, '\u2190 Back'),
      h('h2', {}, 'Booster Packs'),
      h('span', { class: 'spacer' }),
      h('div', { class: 'pill berrypill' }, icon('berry'), h('b', {}, String(COLL.berries())), ' Berries'),
      h('span', { class: `count-num ${left > 0 ? 'good' : ''}` }, `${left} free left`),
    ));
    $app.appendChild(h('div', { class: 'packstage', id: 'packstage' },
      h('div', { class: 'packrow' }, arrows(-1), packWrap, arrows(1)),
      h('div', { class: 'packsetname' }, `${setInfo.id} — ${setInfo.name}`),
      status,
    ));
  }

  // ---- Pocket-style rip: glow seam, curling strip, flash, cards burst out
  function startRip(setId, paid) {
    const stage = document.getElementById('packstage');
    const packSrc = `assets/packs/${setId}.webp`;
    stage.innerHTML = '';
    const packImg = h('img', { class: 'bigpack-img', src: packSrc, draggable: 'false' });
    const strip = h('div', { class: 'pack-strip2', style: `background-image:url('${packSrc}')` });
    const seam = h('div', { class: 'tearglow' });
    seam.style.opacity = '0';
    const pack = h('div', { class: 'bigpack ripmode' }, packImg, strip, seam);
    stage.append(
      h('div', { class: 'packrow' }, pack),
      h('div', { class: 'dim', id: 'riphint' }, 'Hold the top edge and tear across'),
      h('div', { class: 'mbtns' }, h('button', { onclick: render }, 'Put it back')),
    );

    let ripping = false, progress = 0, lastSparkX = 0, done = false;
    const setMask = (p) => {
      const m = `linear-gradient(90deg, transparent 0%, transparent ${p * 100}%, black ${Math.min(100, p * 100 + 3)}%)`;
      strip.style.webkitMaskImage = m; strip.style.maskImage = m;
      strip.style.transform = `rotate(${p * -4}deg) translateY(${p * -10}px) skewY(${p * -2}deg)`;
      packImg.style.clipPath = p > 0 ? `inset(${13.2 * Math.min(1, p * 1.35)}% 0 0 0)` : '';
      seam.style.opacity = p > 0 && p < 0.97 ? '1' : '0';
      seam.style.left = `${p * 100}%`;
    };
    const spark = (x, y) => {
      const s = h('div', { class: 'ripspark' });
      s.style.left = `${x}px`; s.style.top = `${y}px`;
      document.body.appendChild(s);
      s.animate([
        { transform: 'translate(0,0) scale(1)', opacity: 1 },
        { transform: `translate(${(Math.random() - 0.5) * 60}px,${-20 - Math.random() * 40}px) scale(.2)`, opacity: 0 },
      ], { duration: 420 + Math.random() * 200, easing: 'ease-out' }).onfinish = () => s.remove();
    };
    strip.addEventListener('mousedown', (e) => { e.preventDefault(); ripping = true; lastSparkX = e.clientX; });
    const onMove = (e) => {
      if (!ripping || done) return;
      const r = strip.getBoundingClientRect();
      progress = Math.max(progress, Math.min(1, (e.clientX - r.left) / r.width));
      setMask(progress);
      if (Math.abs(e.clientX - lastSparkX) > 26) {
        SND.play('rip');
        for (let i = 0; i < 3; i++) spark(e.clientX, r.top + r.height);
        lastSparkX = e.clientX;
      }
      if (progress >= 0.97) finishRip();
    };
    const onUp = () => {
      if (done) return;
      ripping = false;
      if (progress > 0 && progress < 0.97) { progress = 0; setMask(0); strip.style.transform = ''; }
    };
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
    const cleanup = () => { document.removeEventListener('mousemove', onMove); document.removeEventListener('mouseup', onUp); };

    async function finishRip() {
      done = true;
      cleanup();
      const res = await COLL.openPack(setId, { paid });
      if (res.err) {
        render();
        toast(res.err === 'berries' ? 'Not enough Berries.' : res.err === 'daily' ? 'No packs left today.' : res.err, 'info');
        return;
      }
      if (paid) SND.play('coin');
      SND.play('ripEnd');
      seam.style.opacity = '0';
      const pr = pack.getBoundingClientRect();
      // strip tears away
      strip.animate([
        { transform: 'rotate(-4deg) translate(0,-10px)', opacity: 1 },
        { transform: 'rotate(-30deg) translate(220px,-240px)', opacity: 0 },
      ], { duration: 500, easing: 'cubic-bezier(.2,.6,.4,1)' }).onfinish = () => strip.remove();
      // golden flash from the opened pack
      const flash = h('div', { class: 'packflash' });
      flash.style.left = `${pr.left + pr.width / 2}px`;
      flash.style.top = `${pr.top + pr.height * 0.2}px`;
      document.body.appendChild(flash);
      flash.animate([
        { transform: 'translate(-50%,-50%) scale(.2)', opacity: 0 },
        { transform: 'translate(-50%,-50%) scale(1.6)', opacity: .95, offset: .3 },
        { transform: 'translate(-50%,-50%) scale(2.6)', opacity: 0 },
      ], { duration: 750, easing: 'ease-out' }).onfinish = () => flash.remove();
      setTimeout(() => {
        pack.animate([{ transform: 'translateY(0)', opacity: 1 }, { transform: 'translateY(90px) scale(.92)', opacity: 0 }], { duration: 420, easing: 'ease-in' })
          .onfinish = () => showReveal(res, { x: pr.left + pr.width / 2, y: pr.top + pr.height * 0.35 });
      }, 380);
    }
  }

  // cards burst out of the pack, land face-down, then flip
  function showReveal(res, origin) {
    const stage = document.getElementById('packstage');
    const newSet = new Set(res.newOnes);
    const hitSet = new Set(res.hits || []);
    let revealed = 0;
    const doneBtn = h('button', { class: 'primary', disabled: 'true' }, 'Add to collection');
    doneBtn.addEventListener('click', render);
    const revealAll = h('button', {}, 'Reveal all');
    const grid = h('div', { class: 'cardgrid' });
    const slots = res.cards.map((code) => {
      const slot = h('div', { class: 'packslot' });
      const back = cardBack({ cw: 124 });
      back.style.cursor = 'pointer';
      const reveal = () => {
        if (!back.parentNode) return;
        const hit = hitSet.has(code);
        SND.play(hit ? 'rare' : 'flip');
        const el = cardEl(code, { cw: 124, class: `just-played ${hit ? 'hitcard' : ''}` });
        if (newSet.has(code)) el.appendChild(h('div', { class: 'newtag' }, 'NEW'));
        slot.replaceChild(el, back);
        revealed++;
        if (revealed >= res.cards.length) { doneBtn.disabled = false; revealAll.disabled = true; }
      };
      back.addEventListener('click', reveal);
      slot.reveal = reveal;
      slot.appendChild(back);
      return slot;
    });
    revealAll.addEventListener('click', () => slots.forEach((s, i) => setTimeout(() => s.reveal(), i * 130)));
    stage.innerHTML = '';
    stage.append(
      h('div', { class: 'dim', style: 'text-align:center' }, 'Click the cards to flip them!'),
      grid,
      h('div', { class: 'mbtns' }, revealAll, doneBtn),
    );
    slots.forEach((s) => grid.appendChild(s));
    // burst: each card flies from the opened pack to its slot
    slots.forEach((s, i) => {
      const r = s.getBoundingClientRect();
      const dx = origin.x - (r.left + r.width / 2);
      const dy = origin.y - (r.top + r.height / 2);
      s.animate([
        { transform: `translate(${dx}px,${dy}px) scale(.25) rotate(${(Math.random() - 0.5) * 40}deg)`, opacity: 0 },
        { transform: 'translate(0,0) scale(1) rotate(0)', opacity: 1 },
      ], { duration: 460, delay: i * 55, easing: 'cubic-bezier(.2,.8,.3,1.1)', fill: 'backwards' });
    });
  }

  render();
}

// ---------------------------------------------------------- collection page
function showCollection() {
  let setFilter = 'OP01';
  let ownedOnly = true;
  let sellMode = false;

  function render() {
    $app.innerHTML = '';
    const setSel = h('select', {}, ...COLL.SETS.map((s) => h('option', { value: s.id, ...(s.id === setFilter ? { selected: '' } : {}) }, `${s.id} — ${s.name}${setLocked(s.id) ? '  (coming soon)' : ''}`)));
    setSel.addEventListener('change', () => { setFilter = setSel.value; render(); });
    const ownedChk = h('button', { onclick: () => { ownedOnly = !ownedOnly; render(); } }, ownedOnly ? 'Showing: owned cards' : 'Showing: all cards');
    const sellBtn = h('button', { class: sellMode ? 'primary' : '', onclick: () => { sellMode = !sellMode; render(); } },
      icon('berry'), sellMode ? 'Done selling' : 'Sell duplicates');
    const extras = COLL.extrasValue(4);
    const sellAllBtn = h('button', {
      ...(extras.count === 0 ? { disabled: '' } : {}),
      onclick: async () => {
        if (!confirm(`Sell all ${extras.count} duplicates beyond 4 copies for ${extras.value} Berries?`)) return;
        const earned = await COLL.sellAllExtras(4);
        SND.play('coin');
        toast(`Sold duplicates for ${earned} Berries!`, 'info');
        render();
      },
    }, `Sell ALL extras (keep 4) — +${extras.value}`);

    const grid = h('div', { class: 'grid', style: 'padding:10px' });
    const owned = COLL.ownedMap();
    let shown = 0;
    if (setLocked(setFilter)) {
      grid.appendChild(h('div', { class: 'comingsoon' },
        h('img', { src: `assets/packs/${setFilter}.webp`, draggable: 'false' }),
        h('div', { class: 'cs-title' }, 'COMING SOON'),
        h('div', { class: 'dim' }, `${COLL.SETS.find((s) => s.id === setFilter).name} will be released in a future update — stay tuned!`)));
      shown = 1;
    }
    for (const def of DB) {
      if (setLocked(setFilter)) break;
      if (def.set !== setFilter) continue;
      const n = owned[def.code] || 0;
      if ((ownedOnly || sellMode) && n === 0) continue;
      if (sellMode && n <= 1) continue;
      shown++;
      const badges = [h('div', { class: 'badge don' }, `\u00D7${n}`)];
      if (FLAGS[def.code] === 'manual' || FLAGS[def.code] === 'partial') badges.push(h('div', { class: 'badge kw', title: 'Effect not fully automated' }, '\u26A0'));
      const el = cardEl(def.code, { cw: 128, badges, class: n === 0 ? 'unowned' : '', onclick: () => { if (!sellMode) inspectCard(def.code); } });
      if (sellMode) {
        const cell = h('div', { class: 'sellcell' }, el,
          h('button', {
            class: 'sellbtn',
            onclick: async () => {
              const earned = await COLL.sell(def.code, 1);
              if (earned) { SND.play('coin'); toast(`Sold ${def.name} for ${earned} Berries.`, 'info'); }
              render();
            },
          }, `Sell 1 — +${COLL.sellPrice(def.code)}`));
        grid.appendChild(cell);
      } else {
        grid.appendChild(el);
      }
    }
    if (!shown) grid.appendChild(h('div', { class: 'dim', style: 'padding:30px' }, sellMode ? 'No duplicates to sell in this set.' : 'No cards here yet — open some packs!'));

    $app.appendChild(h('div', { class: 'topbar' },
      h('button', { onclick: showHome }, '\u2190 Back'),
      h('h2', {}, 'Collection'),
      h('span', { class: 'dim' }, `${COLL.totalOwned()} cards owned`),
      h('span', { class: 'spacer' }),
      h('div', { class: 'pill berrypill' }, icon('berry'), h('b', {}, String(COLL.berries())), ' Berries'),
      sellMode ? sellAllBtn : null,
      sellBtn,
    ));
    $app.appendChild(h('div', { class: 'builder' },
      h('div', { class: 'gallery' },
        h('div', { class: 'filters' }, setSel, ownedChk,
          h('span', { class: 'dim', style: 'font-size:12px' }, sellMode ? 'You always keep at least 1 copy of every card.' : 'Click a card to inspect it. Cards marked \u26A0 play as stats + keywords.')),
        grid,
      ),
    ));
  }
  render();
}

// Hearthstone-style deck collection: your decks as leader-art tiles, a New
// Deck flow that starts from picking a Leader, then the editor.
function showBuilder() {
  $app.innerHTML = '';
  const shelf = h('div', { class: 'deckshelf' });
  shelf.appendChild(h('div', { class: 'decktile dt-new', onclick: pickLeaderScreen },
    h('div', { class: 'dt-plus' }, '+'), h('div', { class: 'dt-name' }, 'New Deck')));
  const mine = savedDecks();
  for (const d of mine) {
    const ld = CARDS[d.leader];
    const tile = h('div', {
      class: 'decktile',
      style: ld ? `background-image: linear-gradient(rgba(10,14,26,.15), rgba(10,14,26,.5)), url('${ld.image}')` : '',
      onclick: () => openDeckEditor(d),
    },
      h('div', { class: 'dt-name' }, d.name),
      h('button', {
        class: 'dt-del',
        onclick: (e) => {
          e.stopPropagation();
          if (!confirm(`Delete "${d.name}"?`)) return;
          storeDecks(savedDecks().filter((x) => x.name !== d.name));
          showBuilder();
        },
      }, '\u00D7'));
    shelf.appendChild(tile);
  }
  const shelf2 = h('div', { class: 'deckshelf' });
  const recs = SAMPLE_DECKS.filter((d) => d.leader === COLL.starterLeader());
  for (const d of recs) {
    const ld = CARDS[d.leader];
    shelf2.appendChild(h('div', {
      class: 'decktile dt-rec',
      style: `background-image: linear-gradient(rgba(10,14,26,.15), rgba(10,14,26,.55)), url('${ld.image}')`,
      onclick: () => openDeckEditor({ name: d.name, leader: d.leader, cards: [...d.cards] }),
    }, h('div', { class: 'dt-name' }, d.name)));
  }
  $app.appendChild(h('div', { class: 'topbar' },
    h('button', { onclick: showHome }, '← Back'),
    h('h2', {}, 'My Decks'),
    h('span', { class: 'dim' }, mine.length ? `${mine.length} deck${mine.length > 1 ? 's' : ''}` : 'No decks yet — click New Deck!'),
  ));
  $app.appendChild(h('div', { class: 'shelfwrap' },
    shelf,
    recs.length ? h('div', { class: 'shelfhead' }, 'YOUR STARTER DECK — open it to customize a copy') : null,
    shelf2,
  ));
}

function pickLeaderScreen() {
  $app.innerHTML = '';
  const grid = h('div', { class: 'leaderpick' });
  // build with Leaders you own; before choosing a starter, the OP-01 eight are trials
  let leaders = DB.filter((c) => c.type === 'Leader' && !setLocked(c.set) && COLL.owned(c.code) > 0);
  if (!leaders.length) leaders = DB.filter((c) => c.type === 'Leader' && c.set === 'OP01');
  for (const def of leaders) {
    grid.appendChild(cardEl(def.code, {
      cw: 210,
      onclick: () => openDeckEditor({ name: `${def.name} Deck`, leader: def.code, cards: [] }),
    }));
  }
  $app.appendChild(h('div', { class: 'topbar' },
    h('button', { onclick: showBuilder }, '← Back'),
    h('h2', {}, 'Choose your Leader'),
    h('span', { class: 'dim' }, 'Leaders from your collection — open packs to find more. Colors decide which cards the deck may contain.'),
  ));
  $app.appendChild(grid);
}

function openDeckEditor(initial) {
  let deck = { name: initial.name || 'My Deck', leader: initial.leader, cards: [...(initial.cards || [])] };
  let filters = { color: '', type: '', search: '', cost: '' };

  function counts() {
    const m = {};
    for (const c of deck.cards) m[c] = (m[c] || 0) + 1;
    return m;
  }
  function validity() {
    if (!deck.leader) return 'Pick a Leader card.';
    return validateDeck(DB, deck);
  }

  function addCard(code) {
    const def = CARDS[code];
    const leader = CARDS[deck.leader];
    if (!def.colors.every((c) => leader.colors.includes(c))) { toast(`${def.name} doesn't match your Leader's colors.`); return; }
    const n = counts()[code] || 0;
    const own = COLL.owned(code);
    if (n >= own) { toast(own === 0 ? `You don't own ${def.name} yet — open packs to find it!` : `You only own ${own} cop${own === 1 ? 'y' : 'ies'} of ${def.name}.`); return; }
    if (n >= 4 && code !== 'OP01-075') { toast('Max 4 copies.'); return; }
    if (deck.cards.length >= 50) { toast('Deck already has 50 cards.'); return; }
    deck.cards.push(code);
    render();
  }
  function removeCard(code) {
    const i = deck.cards.indexOf(code);
    if (i >= 0) deck.cards.splice(i, 1);
    render();
  }

  function render() {
    $app.innerHTML = '';
    const searchIn = h('input', { placeholder: 'Search name/text…', value: filters.search, style: 'width:200px' });
    searchIn.addEventListener('input', () => { filters.search = searchIn.value; renderGrid(); });
    const colorSel = h('select', {},
      h('option', { value: '' }, 'All colors'),
      ...['Red', 'Green', 'Blue', 'Purple'].map((c) => h('option', { value: c, ...(filters.color === c ? { selected: '' } : {}) }, c)));
    colorSel.addEventListener('change', () => { filters.color = colorSel.value; renderGrid(); });
    const typeSel = h('select', {},
      h('option', { value: '' }, 'All types'),
      ...['Leader', 'Character', 'Event'].map((c) => h('option', { value: c, ...(filters.type === c ? { selected: '' } : {}) }, c)));
    typeSel.addEventListener('change', () => { filters.type = typeSel.value; renderGrid(); });
    const costSel = h('select', {},
      h('option', { value: '' }, 'Any cost'),
      ...[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((c) => h('option', { value: String(c), ...(filters.cost === String(c) ? { selected: '' } : {}) }, `Cost ${c}`)));
    costSel.addEventListener('change', () => { filters.cost = costSel.value; renderGrid(); });

    const grid = h('div', { class: 'grid', id: 'bgrid' });

    function renderGrid() {
      grid.innerHTML = '';
      const cs = counts();
      const q = filters.search.toLowerCase();
      const leader = CARDS[deck.leader];
      for (const def of DB) {
        // Hearthstone-style: only cards this Leader can actually run
        if (setLocked(def.set)) continue;
        if (def.type === 'Leader') continue;
        if (!def.colors.every((c) => leader.colors.includes(c))) continue;
        if (filters.color && !def.colors.includes(filters.color)) continue;
        if (filters.type && def.type !== filters.type) continue;
        if (filters.cost !== '' && String(def.cost ?? '') !== filters.cost) continue;
        if (q && !(`${def.name} ${def.text} ${def.types.join(' ')}`.toLowerCase().includes(q))) continue;
        const n = cs[def.code] || 0;
        const own = COLL.owned(def.code);
        const badges = [];
        if (n > 0) badges.push(h('div', { class: 'badge don' }, `×${n}`));
        if (own > 0) badges.push(h('div', { class: 'badge power' }, `own ${own}`));
        if (FLAGS[def.code] === 'manual' || FLAGS[def.code] === 'partial') badges.push(h('div', { class: 'badge kw', title: 'Effect not fully automated' }, '⚠'));
        const el = cardEl(def.code, { cw: 128, badges, class: own === 0 ? 'unowned' : '', onclick: () => addCard(def.code) });
        el.addEventListener('contextmenu', (e) => { e.preventDefault(); removeCard(def.code); });
        grid.appendChild(el);
      }
    }

    // deck pane
    const nameIn = h('input', { value: deck.name, style: 'width:100%' });
    nameIn.addEventListener('input', () => { deck.name = nameIn.value; });
    const list = h('div', { class: 'decklist' });
    const cs = counts();
    {
      const ld = CARDS[deck.leader];
      list.appendChild(h('div', { class: `deckrow c-${ld.colors[0]}`, onmouseenter: (e) => scheduleBigPreview(e.currentTarget, ld.code), onmouseleave: hideBigPreview },
        h('span', { class: 'cnt' }, 'L'), h('b', {}, ld.name), h('span', { class: 'dim' }, ` ${ld.colors.join('/')} Leader`)));
    }
    const uniq = [...new Set(deck.cards)].sort((a, b) => (CARDS[a].cost - CARDS[b].cost) || a.localeCompare(b));
    for (const code of uniq) {
      const def = CARDS[code];
      list.appendChild(h('div', {
        class: `deckrow c-${def.colors[0]}`,
        onmouseenter: (e) => scheduleBigPreview(e.currentTarget, code),
        onmouseleave: hideBigPreview,
        onclick: () => removeCard(code),
      },
        h('span', { class: 'cnt' }, `×${cs[code]}`),
        h('span', { class: 'cost' }, String(def.cost)),
        h('span', {}, def.name),
        h('span', { class: 'spacer' }),
        h('span', { class: 'dim' }, def.type === 'Event' ? 'EV' : ''),
      ));
    }
    const err = validity();
    const vmsg = h('div', { class: `validmsg ${err ? 'bad' : 'good'}` }, err || '✓ Deck is legal — save it and set sail!');

    const saveBtn = h('button', {
      class: 'primary',
      onclick: () => {
        const e2 = validity();
        if (e2) { toast(e2); return; }
        const all = savedDecks().filter((d) => d.name !== deck.name);
        all.push({ name: deck.name, leader: deck.leader, cards: [...deck.cards] });
        storeDecks(all);
        toast(`Saved "${deck.name}" (${all.length} deck${all.length > 1 ? 's' : ''} stored).`, 'info');
      },
    }, 'Save');
    const autoBtn = h('button', {
      onclick: () => {
        if (!deck.leader) { toast('Pick a Leader first, then Auto-build.'); return; }
        const rec = SAMPLE_DECKS.find((d) => d.leader === deck.leader);
        if (rec) {
          const pool = {};
          const cards = [];
          for (const code of rec.cards) {
            pool[code] = (pool[code] || 0) + 1;
            if (pool[code] <= COLL.owned(code)) cards.push(code);
          }
          // top up with owned color-matching cards if the collection is missing some
          if (cards.length < 50) {
            const leader = CARDS[deck.leader];
            const cnt = {};
            for (const c of cards) cnt[c] = (cnt[c] || 0) + 1;
            for (const def of DB) {
              if (cards.length >= 50) break;
              if (def.type === 'Leader' || !def.colors.every((col) => leader.colors.includes(col))) continue;
              while (cards.length < 50 && (cnt[def.code] || 0) < Math.min(4, COLL.owned(def.code))) {
                cnt[def.code] = (cnt[def.code] || 0) + 1;
                cards.push(def.code);
              }
            }
          }
          deck = { name: deck.name, leader: deck.leader, cards };
          toast(cards.length < 50 ? `Built ${cards.length}/50 — open packs to complete it.` : `Loaded the recommended list for ${CARDS[deck.leader].name}.`, 'info');
        } else {
          // no curated list: greedy-fill with color-matching cards, cheap first
          const leader = CARDS[deck.leader];
          const pool = DB.filter((c) => c.type !== 'Leader' && c.colors.every((col) => leader.colors.includes(col)))
            .sort((a, b) => (a.cost || 0) - (b.cost || 0));
          const cards = [];
          for (const def of pool) {
            for (let i = 0; i < 4 && cards.length < 50; i++) cards.push(def.code);
            if (cards.length >= 50) break;
          }
          deck = { name: deck.name, leader: deck.leader, cards };
          toast('Auto-built a deck from your Leader\'s colors.', 'info');
        }
        render();
      },
    }, 'Auto-build');
    const exportBtn = h('button', {
      onclick: () => {
        navigator.clipboard.writeText(btoa(JSON.stringify({ name: deck.name, leader: deck.leader, cards: deck.cards })));
        toast('Deck code copied to clipboard — send it to your friend!', 'info');
      },
    }, 'Export');
    const importBtn = h('button', {
      onclick: () => {
        const code = prompt('Paste a deck code:');
        if (!code) return;
        try {
          const d = JSON.parse(atob(code.trim()));
          if (!d.leader || !Array.isArray(d.cards)) throw new Error();
          deck = { name: d.name || 'Imported Deck', leader: d.leader, cards: d.cards };
          render();
        } catch { toast('Invalid deck code.'); }
      },
    }, 'Import');

    $app.appendChild(h('div', { class: 'topbar' },
      h('button', { onclick: showBuilder }, '← My Decks'),
      h('h2', {}, CARDS[deck.leader].name),
      h('span', { class: 'dim' }, 'Click a card to add · right-click to remove'),
      h('span', { class: 'spacer' }),
      h('span', { class: `count-num ${deck.cards.length === 50 ? 'good' : ''}` }, `${deck.cards.length}/50`),
    ));
    $app.appendChild(h('div', { class: 'builder' },
      h('div', { class: 'gallery' },
        h('div', { class: 'filters' }, searchIn, colorSel, typeSel, costSel),
        grid,
      ),
      h('div', { class: 'deckpane' },
        nameIn, list, vmsg,
        h('div', { style: 'display:flex;gap:6px;flex-wrap:wrap' }, saveBtn, autoBtn, exportBtn, importBtn),
      ),
    ));
    renderGrid();
  }
  render();
}

// ----------------------------------------------------------- test hooks
window.__optcg = {
  startBotGame: () => startBotMatch({ leader: SAMPLE_DECKS[0].leader, cards: [...SAMPLE_DECKS[0].cards] }, { botDelay: 25 }),
  startTutorial, showBuilder, showHome, showPacksScreen, showCollection,
  tut: () => TUT,
  state: () => ({ hasV: !!V, askKind: ASK ? ASK.kind : null, over: !!OVER, canAct: !!(V && V.canAct), logs: LOGS.length }),
};

// ---------------------------------------------------------- auth + starter
function showAuth() {
  $app.innerHTML = '';
  $modal.innerHTML = '';
  const card = h('div', { class: 'authcard' });
  let tab = 'login';
  function fld(placeholder, type = 'text') { return h('input', { placeholder, type, style: 'width:100%' }); }
  function render() {
    card.innerHTML = '';
    const tabs = h('div', { class: 'mbtns' },
      h('button', { class: tab === 'login' ? 'primary' : '', onclick: () => { tab = 'login'; render(); } }, 'Log in'),
      h('button', { class: tab === 'register' ? 'primary' : '', onclick: () => { tab = 'register'; render(); } }, 'Create account'),
      h('button', { class: tab === 'forgot' ? 'primary' : '', onclick: () => { tab = 'forgot'; render(); } }, 'Forgot?'),
    );
    const err = h('div', { class: 'validmsg bad' });
    if (tab === 'login') {
      const u = fld('Username'), p = fld('Password', 'password');
      const go = h('button', { class: 'primary' }, 'Log in');
      go.addEventListener('click', async () => {
        go.disabled = true;
        try {
          const r = await accountRequest({ t: 'login', username: u.value, password: p.value }, 'auth');
          if (r.ok) { localStorage.setItem('optcg_user', r.username); localStorage.setItem('optcg_token', r.token || ''); myName = r.username; localStorage.setItem('optcg_name', r.username); await pullColl(); boot(); return; }
          err.textContent = r.why;
        } catch (e) { err.textContent = e.message; }
        go.disabled = false;
      });
      card.append(tabs, u, p, err, h('div', { class: 'mbtns' }, go));
    } else if (tab === 'register') {
      const u = fld('Username (3–20 characters)'), e2 = fld('Email — used only to recover your account'), p = fld('Password (6+ characters)', 'password');
      const go = h('button', { class: 'primary' }, 'Create account');
      go.addEventListener('click', async () => {
        go.disabled = true;
        try {
          const r = await accountRequest({ t: 'register', username: u.value, email: e2.value, password: p.value }, 'auth');
          if (r.ok) { localStorage.setItem('optcg_user', r.username); localStorage.setItem('optcg_token', r.token || ''); myName = r.username; localStorage.setItem('optcg_name', r.username); await pullColl(); boot(); return; }
          err.textContent = r.why;
        } catch (e3) { err.textContent = e3.message; }
        go.disabled = false;
      });
      card.append(tabs, u, e2, p, err, h('div', { class: 'mbtns' }, go));
    } else {
      const e2 = fld('Your account email'), code = fld('6-digit code from the email'), np = fld('New password', 'password');
      const send1 = h('button', {}, 'Email me a code');
      const go = h('button', { class: 'primary' }, 'Reset password');
      send1.addEventListener('click', async () => {
        try {
          const r = await accountRequest({ t: 'recoverRequest', email: e2.value }, 'recover');
          err.className = r.ok ? 'validmsg good' : 'validmsg bad';
          err.textContent = r.ok ? 'Sent! The email contains your username and a reset code.' : r.why;
        } catch (e3) { err.textContent = e3.message; }
      });
      go.addEventListener('click', async () => {
        try {
          const r = await accountRequest({ t: 'recoverConfirm', email: e2.value, code: code.value, newPassword: np.value }, 'recover');
          if (r.ok) { localStorage.setItem('optcg_user', r.username); localStorage.setItem('optcg_token', r.token || ''); myName = r.username; await pullColl(); boot(); return; }
          err.textContent = r.why;
        } catch (e3) { err.textContent = e3.message; }
      });
      card.append(tabs, e2, h('div', { class: 'mbtns' }, send1), code, np, err, h('div', { class: 'mbtns' }, go));
    }
    card.append(h('button', {
      class: 'guestlink',
      onclick: () => { localStorage.removeItem('optcg_user'); boot(true); },
    }, 'Play offline as guest'));
  }
  render();
  $app.appendChild(h('div', { class: 'authpage' },
    h('div', { class: 'logo' },
      icon('jolly', 'authlogo'),
      h('h1', {}, 'ONE PIECE CARD GAME'),
      h('div', { class: 'sub' }, 'LOG IN TO SET SAIL'),
    ),
    card,
  ));
}

function showStarterScreen() {
  $app.innerHTML = '';
  const grid = h('div', { class: 'leaderpick' });
  for (const d of SAMPLE_DECKS) {
    const el = cardEl(d.leader, {
      cw: 210,
      onclick: async () => {
        if (!confirm(`Start your journey with ${CARDS[d.leader].name}? You receive their complete 50-card deck.`)) return;
        const okd = await COLL.chooseStarter(d.leader, d.cards);
        if (okd === false) { toast('Could not claim the starter — try again.', 'info'); return; }
        const all = savedDecks().filter((x) => x.name !== d.name);
        all.push({ name: d.name, leader: d.leader, cards: [...d.cards] });
        storeDecks(all);
        toast(`Welcome aboard! The "${d.name}" deck and all its cards are yours.`, 'info');
        showHome();
      },
    });
    grid.appendChild(el);
  }
  $app.appendChild(h('div', { class: 'topbar' },
    h('h2', {}, 'Choose your first crew'),
    h('span', { class: 'dim' }, 'You receive this Leader\'s complete deck — every card goes into your collection. Open daily packs to grow it!'),
  ));
  $app.appendChild(grid);
}

function boot(skipAuth = false) {
  if (!skipAuth && relayUrl() && !loggedInUser()) { showAuth(); return; }
  if (!COLL.starterChosen()) { showStarterScreen(); return; }
  showHome();
}

// ------------------------------------------------------------- auto-update
async function maybeOfferUpdate() {
  try {
    const info = await updater.checkForUpdate();
    if (!info) return;
    $modal.innerHTML = '';
    const status = h('div', { class: 'dim' }, `You have ${updater.localVersion()} — version ${info.version} is out.`);
    const go = h('button', { class: 'primary' }, 'Update now');
    go.addEventListener('click', async () => {
      go.disabled = true;
      status.textContent = 'Downloading update…';
      try {
        await updater.installUpdate();
        status.textContent = 'Update installed — restarting…';
        setTimeout(() => require('electron').ipcRenderer.send('relaunch'), 800);
      } catch (e) {
        status.textContent = `Update failed: ${e.message}`;
        go.disabled = false;
      }
    });
    $modal.appendChild(h('div', { class: 'modal-overlay' }, h('div', { class: 'modal', style: 'min-width:400px' },
      h('div', { class: 'mtitle' }, 'Update available'),
      status,
      info.notes ? h('div', { class: 'dim', style: 'font-size:13px' }, String(info.notes)) : null,
      h('div', { class: 'mbtns' }, go, h('button', { onclick: () => { $modal.innerHTML = ''; } }, 'Later')),
    )));
  } catch {}
}

// visible decision countdown (the engine enforces the real limit host-side)
let timerWarned = false;
setInterval(() => {
  const el = document.getElementById('timerchip');
  if (!el) return;
  if (!TIMER_END || OVER) { el.textContent = ''; el.className = 'timerchip'; timerWarned = false; return; }
  const s = Math.max(0, Math.ceil((TIMER_END - Date.now()) / 1000));
  el.textContent = `${s}s`;
  el.className = `timerchip ${s <= 10 ? 'urgent' : ''}`;
  if (s === 10 && !timerWarned) { timerWarned = true; SND.play('click'); }
  if (s > 10) timerWarned = false;
}, 300);

// ------------------------------------------------------------------- boot
boot();
setTimeout(maybeOfferUpdate, 2000);
