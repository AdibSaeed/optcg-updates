// A heuristic opponent for "Play vs Bot" mode (and post-tutorial free play).
// It receives the same messages a remote guest would and answers with
// actions/choices. Not a genius, but it plays real One Piece TCG:
// curve out, give spare DON!! to attackers, attack for value, counter and
// block when it actually matters.
'use strict';

const path = require('path');
const DB = require(path.join(__dirname, 'data', 'cards.json'));
const CARDS = {};
for (const c of DB) CARDS[c.code] = c;

function createBot(send, opts = {}) {
  const delay = opts.delay ?? 450; // small pause so moves are watchable
  const level = opts.level || 'normal'; // 'easy' | 'normal' | 'hard'
  let view = null;
  let plannedAttacks = [];
  let phase = 'play';           // play -> don -> attack -> end (per turn)
  let actionsThisTurn = 0;
  let thinking = false;

  const act = (m) => send({ t: 'action', ...m });

  function oppRestedTargets() {
    return view.opp.chars.filter((c) => c.rested);
  }

  function nextMove() {
    const v = view;
    actionsThisTurn++;
    if (actionsThisTurn > 40) return act({ a: 'endTurn' });

    if (phase === 'play') {
      const playable = (v.you.hand || [])
        .filter((c) => CARDS[c.code].type === 'Character' && c.cost <= v.you.donActive)
        .sort((a, b) => (level === 'easy' ? Math.random() - 0.5 : b.cost - a.cost));
      if (playable.length && v.you.chars.length < 5) return act({ a: 'playCard', iid: playable[0].iid });
      phase = 'don';
    }

    if (phase === 'don') {
      if (level !== 'easy' && v.you.donActive > 0 && v.you.leader.don < 2) return act({ a: 'attachDon', iid: v.you.leader.iid });
      if (level === 'hard' && v.you.donActive > 0) {
        // spread remaining DON!! onto the strongest character that can attack
        const c = v.you.chars.filter((x) => !x.rested && x.don < 2).sort((a, b) => b.power - a.power)[0];
        if (c) return act({ a: 'attachDon', iid: c.iid });
      }
      phase = 'attack';
      // plan attacks once: every usable attacker
      plannedAttacks = [v.you.leader, ...v.you.chars]
        .filter((c) => !c.rested && !c.cannotAttack)
        .filter((c) => c.iid === v.you.leader.iid || c.playedTurn !== v.turn.n || c.kws.includes('Rush'))
        .map((c) => c.iid);
    }

    if (phase === 'attack') {
      while (plannedAttacks.length) {
        const iid = plannedAttacks.shift();
        const a = iid === v.you.leader.iid ? v.you.leader : v.you.chars.find((c) => c.iid === iid);
        if (!a || a.rested) continue;
        if (level === 'easy') {
          // easy bots just swing at the leader
          if (a.power >= v.opp.leader.power) return act({ a: 'attack', iid, targetIid: 'leader' });
          continue;
        }
        // best target: highest-cost rested character we can KO, else their leader
        const koable = oppRestedTargets()
          .filter((t) => a.power >= t.power)
          .sort((x, y) => (CARDS[y.code].cost || 0) - (CARDS[x.code].cost || 0));
        if (koable.length && (CARDS[koable[0].code].cost || 0) >= (level === 'hard' ? 2 : 3)) {
          return act({ a: 'attack', iid, targetIid: koable[0].iid });
        }
        if (a.power >= v.opp.leader.power) return act({ a: 'attack', iid, targetIid: 'leader' });
        if (koable.length) return act({ a: 'attack', iid, targetIid: koable[0].iid });
      }
      phase = 'end';
    }
    return act({ a: 'endTurn' });
  }

  function choose(req) {
    switch (req.kind) {
      case 'yesno': return true;                     // keep hand / pay useful costs
      case 'trigger': return true;                   // free value
      case 'number': return req.max;
      case 'info': return true;
      case 'order': return req.cards.map((c) => c.iid);
      case 'arrange': return { top: req.cards.map((c) => c.iid), bottom: [] };
      case 'pickIndex': {
        const ex = new Set(req.exclude || []);
        for (let i = 0; i < req.count; i++) if (!ex.has(i)) return i;
        return 0;
      }
      case 'targets': {
        if (req.tag === 'block' && req.meta) {
          if (level === 'easy') return [];
          const life = view ? view.you.lifeCount : 5;
          const threshold = level === 'hard' ? 3 : 2;
          if (req.meta.targetIsLeader && (life <= threshold || (life <= threshold + 1 && req.meta.atk >= 7000))) {
            return [req.options[0].iid];
          }
          return [];
        }
        return req.options.slice(0, req.max).map((o) => o.iid);
      }
      case 'cards': return req.cards.slice(0, Math.max(req.min, Math.min(req.cards.length, req.max))).map((c) => c.iid);
      case 'counter': {
        if (level === 'easy') return null;
        const m = req.meta || {};
        if (m.def > m.atk) return null; // already safe
        const worthIt = m.targetIsLeader
          ? (view && view.you.lifeCount <= (level === 'hard' ? 4 : 3))
          : (CARDS[m.targetCode] && (CARDS[m.targetCode].cost || 0) >= (level === 'hard' ? 3 : 4));
        if (!worthIt) return null;
        const need = m.atk - m.def; // counter must push def strictly above atk? def+X >= atk still loses ties for defender... attacker wins ties, so need def+X > atk, i.e. X >= need+1000 steps
        const handCounters = req.options
          .filter((o) => o.use === 'counter')
          .map((o) => ({ o, val: CARDS[o.code].counter || 0 }))
          .sort((a, b) => a.val - b.val);
        const pick = handCounters.find((c) => m.def + c.val > m.atk);
        if (pick) return { iid: pick.o.iid, use: 'counter' };
        return null; // can't flip the battle with one card — save resources
      }
      default: return null;
    }
  }

  return function onMsg(msg) {
    if (msg.t === 'state') {
      view = msg.view;
      if (msg.view.turn.phase === 'refresh' || !msg.view.yourTurn) {
        phase = 'play'; actionsThisTurn = 0;
      }
      if (msg.view.canAct && !thinking) {
        thinking = true;
        setTimeout(() => { thinking = false; if (view.canAct) nextMove(); }, delay);
      }
    } else if (msg.t === 'ask') {
      setTimeout(() => send({ t: 'choice', id: msg.req.id, value: choose(msg.req) }), Math.min(delay, 400));
    } else if (msg.t === 'nope') {
      // a planned move was illegal — fall through to end phase logic
      setTimeout(() => { if (view && view.canAct) { phase = 'attack'; nextMove(); } }, 100);
    }
  };
}

module.exports = { createBot };
