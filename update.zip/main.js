const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');

ipcMain.on('relaunch', () => { app.relaunch(); app.exit(0); });

function createWindow() {
  const win = new BrowserWindow({
    width: 1680,
    height: 1000,
    minWidth: 1200,
    minHeight: 780,
    title: 'One Piece TCG — Romance Dawn',
    backgroundColor: '#0d1220',
    webPreferences: {
      // Node integration is enabled so the renderer can run the game engine
      // and the ws server/client directly. Fine for a two-friend LAN/VPN game.
      nodeIntegration: true,
      contextIsolation: false
    }
  });
  win.setMenuBarVisibility(false);
  if (!process.env.UITEST && !process.env.SMOKE) win.maximize();
  win.loadFile(path.join(__dirname, 'src', 'index.html'));

  // UITEST=1 → inject test/uitest.driver.js into the renderer, which clicks
  // through the deck builder and a full bot game; exits 0 on PASS.
  if (process.env.UITEST) {
    const fs = require('fs');
    const driver = fs.readFileSync(path.join(__dirname, 'test', process.env.UITEST_DRIVER || 'uitest.driver.js'), 'utf8');
    win.webContents.on('console-message', (_e, _level, message) => {
      console.log(`[renderer] ${message}`);
      if (message.includes('[uitest] PASS')) setTimeout(() => app.exit(0), 300);
      if (message.includes('[uitest] FAIL')) setTimeout(() => app.exit(1), 300);
    });
    win.webContents.on('render-process-gone', (_e, d) => { console.log('[renderer crashed]', d.reason); app.exit(1); });
    win.webContents.once('did-finish-load', () => {
      win.webContents.executeJavaScript(driver).catch((e) => { console.error('driver error', e); app.exit(1); });
    });
    setTimeout(() => { console.log('[uitest] TIMEOUT'); app.exit(1); }, 150000);
  }

  // SMOKE=1 npm start → print renderer console to terminal and quit after 6s
  // (used to verify the app boots cleanly on this machine).
  if (process.env.SMOKE) {
    win.webContents.on('console-message', (_e, level, message) => {
      console.log(`[renderer:${level}] ${message}`);
    });
    win.webContents.on('render-process-gone', (_e, d) => { console.log('[renderer crashed]', d.reason); app.exit(1); });
    setTimeout(() => { console.log('[smoke] ok, quitting'); app.exit(0); }, 6000);
  }
}

app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
